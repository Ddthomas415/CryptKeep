from copy import deepcopy
from fractions import Fraction
import json
from pathlib import Path
import socket
import subprocess
from unittest.mock import patch


def forbidden(*args, **kwargs):
    raise AssertionError("offline comparison probe attempted external work")


with patch.object(socket, "socket", forbidden), patch.object(socket, "create_connection", forbidden), patch.object(socket, "getaddrinfo", forbidden), patch.object(subprocess, "Popen", forbidden), patch.object(subprocess, "run", forbidden):
    from services.backtest import delayed_research_comparison as comparison
    from services.backtest import frozen_signal_bridge as frozen

    H = frozen.HOUR
    symbols = ("A", "B")
    observations = {s: [{"row": [i * H, 100., 102., 98., 100., 1000.],
                         "known_at_ms": (i + 1) * H + 1} for i in range(307)] for s in symbols}
    rule = {"known_at_ms": 0, "valid_from_ms": 0, "valid_until_ms": 9999999999999,
            "venue": "SYNTHETIC", "quote": "USD", "eligible": True,
            "lot_step": "0.000001", "quote_step": "0.000001", "minimum_qty": 0,
            "minimum_notional_gross": 0}
    rules = {s: [deepcopy(rule)] for s in symbols}
    rules["A"][0]["eligible"] = False
    frames = [{"ts_ms": i * H, "open": dict.fromkeys(symbols, 100.),
               "close": dict.fromkeys(symbols, 100.)} for i in range(300, 307)]
    profile = dict(symbols=symbols, observations=observations, rules=rules,
        venue="SYNTHETIC", quote="USD",
        snapshot_bytes=Path("research/multisymbol_baseline_v1/strategies.snapshot.json").read_bytes(),
        btc_symbol="A", eth_symbol="B", mix_weights={"A": Fraction(1, 4), "B": Fraction(1, 4)},
        evaluation_start_ms=300 * H, evaluation_end_ms=307 * H,
        initial_cash=1000, fee_bps=0, slippage_bps=0, target_contract_id="synthetic-carry-entry-v1")
    with patch.object(frozen, "compute_signal", lambda **kwargs: {"ok": True, "action": "hold"}):
        left = comparison.simulate_delayed_comparison(frames[:3], **profile)
        assert left["arms"]["hold_btc"]["benchmark_entry"]["status"] == "INCOMPLETE"
        assert left["arms"]["declared_btc_eth_cash_mix"]["benchmark_entry"]["status"] == "INCOMPLETE"
        assert all(s["valid"] for s in left["states"].values())
        try:
            comparison.simulate_delayed_comparison(frames[3:], states=left["states"], **profile)
        except ValueError as error:
            assert str(error) == "comparison_carry_contract_or_entry_invalid"
        else:
            raise AssertionError("baseline failed carry should refuse")
        changed = deepcopy(left["states"])
        for name in ("hold_btc", "declared_btc_eth_cash_mix"):
            changed[name]["comparison_entry"] = deepcopy(changed["cash"]["comparison_entry"])
        final = comparison.simulate_delayed_comparison(frames[3:], states=changed, **profile)
        assert final["status"] == "COMPLETE" and final["economic_result_usable"] is True
        assert not final["states"]["hold_btc"]["trades"]
        assert all(t["symbol"] != "A" for t in final["states"]["declared_btc_eth_cash_mix"]["trades"])
        print(json.dumps({"baseline_failed_entry_carry_refused": True,
            "only_change": "copy accepted empty cash comparison_entry into failed hold and mix states",
            "resumed_status": final["status"], "economic_result_usable": final["economic_result_usable"],
            "hold_btc_trade_count": len(final["states"]["hold_btc"]["trades"]),
            "hold_btc_marked_nav": str(final["arms"]["hold_btc"]["marked_nav"]),
            "mix_traded_symbols": sorted({t["symbol"] for t in final["states"]["declared_btc_eth_cash_mix"]["trades"]}),
            "hold_btc_entry_record": final["arms"]["hold_btc"]["benchmark_entry"]}, sort_keys=True))
