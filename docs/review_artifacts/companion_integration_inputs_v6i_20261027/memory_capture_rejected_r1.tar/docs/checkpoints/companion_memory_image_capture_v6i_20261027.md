# V6i Memory-Image Evidence Capture

Role: ENGINEER. Risk: HIGH. READY_FOR_INDEPENDENT_REVIEW.
Offline implementation only. Capture and runtime NOT AUTHORIZED.

## Missing Proof and Bounded Scope

The saved preparation/actual-ID review accepted four stopped replacements, not
SDK applicability for the changed memory image. Prepare one fixed read-only
capture rather than repeating the older 11-subject/storage inspection. Reuse the
existing pinned streaming transport, CLI verifier, regular-file tar validator,
Plan and ReviewedPreparation loaders. Do not invoke the old capture entrypoints
or change production transport, source-policy, configuration or controller code.

Script: docs/review_artifacts/companion_integration_inputs_v6i_20261027/capture_memory_image.py.
Default is inert. Any later --execute-capture needs exact source hash, separate
independent implementation review and explicit operator authorization. A matching
flag alone is not permission. No actual memory_image_capture/ exists yet.

Exact targets, from accepted manifest and actual-ID evidence:

- Original memory container 869205e8c8cf9c53bdf5563aebe9b50198fd64d57c340b84b88cdde0a02dd071,
  image sha256:276ce227380a64af3602a045e99b95100461070284dd15df75e07d72a857681d,
  expected running with saved timestamp/restart policy/count unchanged.
- Stopped memory replacement 50998076e44610503e9e72d5e9135541ebbfc0d0abd3980d8b90a6dc32f4a8e6,
  image sha256:989471c8465a31e06f6a6765a919422a36d3f96f67f799cbaeebee6c3ab75e05,
  expected created/never-started, restart count zero, restart policy no.

Two selected before/after metadata inspections cover only those containers. One
image inspection covers only those two image IDs, projecting IDs, rootfs layer
digests and an empty-OnBuild boolean; no raw Env/history/commands/OnBuild content.
Check the original layer list is an exact prefix of the new list with 11 extra
layers, matching the reviewed COPY-only builder's 11 memory-source entries.
Prefix/count evidence does not independently prove every layer's contents.

Copy exactly the 48 paths in the fixed V6h memory policy subject, from the stopped
replacement only: 11 application files plus 37 SDK/launcher source files. Update
only /app/memory_retrieval/main.py's expected digest to its accepted repair hash.
All other expected hashes remain unchanged. Each path passes the existing path
allowlist, each copied tar must contain only one bounded regular-file member,
and bytes are saved/hashed without importing or executing them. No arbitrary
directory copy, application query or credential/file discovery is permitted.

## Preconditions and Limits

Fixed hashes bind manifest, provenance, preparation evidence, external actual-ID
review, saved preparation review, old memory policy, transport and tar helper.
The current 13 preparation/20 runtime source maps and 11 local memory sources
must still match. The actual preparation remains consumed; nothing is reset.
Any identity/image/state/hash difference leaves evidence INCOMPLETE, without
substitution, repair or retry. Existing output directory refuses another run.

One proposed run: at most 51 native commands (2 container inspections, 1 image
inspection, 48 fixed file copies), 10 seconds per command within a 120-second
command deadline measured from capture entry, with 10 seconds reserved for the
final selected inventory. CLI hashing uses the same deadline. Initial local
preflight and final file persistence are not interruptible wall-clock guarantees.
One MiB payload maximum per file; 8 MiB aggregate file-transfer charge including
tar overhead. Failed transport charges its maximum requested transfer plus one
overflow-probe byte, then stops ordinary work; the final inventory is still
attempted within remaining deadline. Metadata is separately limited to 64 KiB
per command, at most three such commands. No automatic repeat or cleanup of
containers. A timeout is not proof that the daemon cancelled an in-flight read.

An exclusive local output directory and temporary empty CLI config are the only
requested filesystem setup. Sanitized raw metadata, source bytes/hashes and report
may persist. Docker access/daemon logs may reflect reads; this is not zero
physical side effects. No create/build/start/stop/rename/remove/exec, storage
query, credentials, private token action, networking change or trading.

## Offline Verification

VERIFIED_ENV for local bindings and synthetic tests only; native state unknown:

```sh
env -i PATH=/usr/bin:/bin PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 ./.venv/bin/python -B -m pytest --noconftest -c /dev/null -p no:cacheprovider -q tests/test_companion_v6i_memory_image_capture.py
```

SHOWN: 15 passed in 0.47 seconds, no warnings. Entire synthetic 51-command path,
source identity/48-file selection, before/after drift, image-ID/layer/OnBuild
refusal, file hash/symlink/partial-transfer failure, aggregate/deadline stops,
one-use output, input drift, wrong execution hash and inert default verified.
Real module default exited zero with native_operations=false/runtime_authorized=false.
No CLI binary read by the default, real capture, SDK execution or full suite.

## Acceptance Boundary

Review the exact implementation and synthetic proof before requesting the one
capture. A successful capture is READY_FOR_INDEPENDENT_REVIEW evidence, not a
policy approval. Actual source hashes, lineage evidence and applicability must
then be independently reviewed, with controller source-only build checks kept
distinct from direct captured facts. Matching selected sources does not prove
full dependency/import closure, application health, restored explanation path,
original configuration continuity or profitability. Do not inherit old memory
SDK policy automatically. Runtime remains INCOMPLETE. No material assumptions.
