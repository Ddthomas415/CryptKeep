# Cited precedent compatibility repair, October 25

Role: ENGINEER. Risk: HIGH. READY_FOR_INDEPENDENT_REVIEW.
Research runtime remains INCOMPLETE; no startup, deployment or query authorized.

## Objective and chosen contract

Repair the demonstrated offline guard mismatch after the failed V6f attempt,
without changing the frozen question, retrieval, archive, witnesses or verifier.
The actual missing response prose is not reconstructed; the unique runtime
trigger remains UNVERIFIED.

The existing research-only fallback contract must recognize its exact labelled
keyword passage once in current_cause before any new exemption applies. A past
or future field is exempted from the foreign-token scan only if its entire text
equals one unambiguous past_1/future_1 citation summary. That citation must match
a validated keyword citation's integer document ID, title, source, URL and
timestamp. Added text, nonexact titles, duplicate/missing/wrongly typed citations,
foreign-only titles or missing research metadata retain the existing rejection.
Unrelated past/future titles do not receive a general citation exemption.

This is classification of an exact repeated headline, not verification of its
truth, topical support, provenance or causal relevance. The independent archive/
body/lineage/witness checks remain necessary and unchanged. No new financial or
operational acceptance follows from client normalization.

## Changes and preservation

- dashboard/services/views/_shared_signals.py: one guarded extension to the
  existing foreign-asset check; no producer output, routing or fallback changes.
- tests/test_explain_cited_precedent.py: positive controls and adversarial cases
  through the real client normalizer and unchanged evidence checker, using pure
  extracted orchestrator functions and saved archive inputs, not app startup.
- docs/review_artifacts/companion_cited_precedent_repair_20261025/prechange.tar:
  exact pre-turn source; repair.diff records only this change, not older dirty
  worktree edits. Existing V6f receipts, diagnosis and acceptance are untouched.

Old hash-bound runtime packets and diagnostic-source snapshots now refer to the
old guard and must not be treated as current executable inputs. No packet,
reservation, prepared identity or operational receipt was reset or refreshed.

## Targeted proof

VERIFIED_ENV local Python/test execution only. Before the source patch, the new
test module produced 2 failed / 58 passed in 0.94 seconds. Both failures were the
positive past/future mixed-headline cases. The final module additionally includes
one synthetic case with the saved citation selection 5,47,18,5,26 and the existing
four witness approvals; no new approvals were invented.

Final command:

```sh
env PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 ./.venv/bin/python -B -m pytest -q -p no:cacheprovider tests/test_explain_cited_precedent.py tests/test_explain_headline_context.py tests/test_explain_asset_guard.py tests/test_explain_diagnostics.py tests/test_companion_evidence_checks.py
```

SHOWN: 292 passed in 11.28 seconds. This comprises 61 new cases plus the existing
guard, labelled-context, diagnostics and verifier cases. Negative coverage keeps
unsupported foreign assertions, altered bindings, duplicate citations, absent
context, model/live responses and false semantic/causal claims blocked.

The saved-selection fixture passes client and all five unchanged evidence
checks, but substitutes archived originals for a current DB read and explicit
no-market-data inputs for live collection. It is not runtime replay or fresh
installed-service proof. Socket/subprocess tripwires are active in the new tests.
Full suite not run. Source diff whitespace check passed.

## Handoff

Independent review must assess the exact source delta, before/after proof,
negative cases and real client/verifier boundary. Only that separate reviewer may
accept this high-risk offline repair. No further runtime attempt is part of this
scope; another operational attempt requires separately approved fresh inputs.
