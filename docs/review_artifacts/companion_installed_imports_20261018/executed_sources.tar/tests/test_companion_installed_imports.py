"""Synthetic ownership/cleanup and no-network import runner contracts."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import subprocess
import sys

import pytest

from scripts.research import prove_companion_installed_imports as proof

ROOT = Path(__file__).resolve().parents[1]


def test_wrong_runner_hash_never_calls_docker(tmp_path):
    calls = []
    with pytest.raises(ValueError, match="runner_identity"):
        proof.run(ROOT, tmp_path / "out", "0" * 64, runner=lambda *a, **k: calls.append(a))
    assert calls == []


@pytest.mark.parametrize("fault", [None, "volumes", "loader", "ownership", "timeout", "import", "final"])
def test_owned_isolated_four_image_import_check(tmp_path, monkeypatch, fault):
    baseline = json.loads((ROOT / proof.BASE).read_bytes())["targets"]
    originals = [{"id": r["id"], "image": r["image_id"], "state": "exited", "restarts": 0, "policy": "no"} for r in baseline]
    real_checked = proof.checked
    monkeypatch.setattr(proof, "checked", lambda p, h: b"fake-cli" if p == proof.CLI else real_checked(p, h))
    rows, calls, configurations = {}, [], {}
    original_reads = []
    def runner(argv, **kwargs):
        args = argv[5:]
        calls.append(args)
        assert kwargs["env"] == {"PATH": "/usr/bin:/bin"}
        assert 0 < kwargs["timeout"] <= 20
        rc, out, err = 0, b"", b""
        if args[:2] == ("image", "inspect"):
            out = json.dumps({"id": args[-1], "volumes": fault == "volumes",
                              "loader_env": [fault == "loader"]}).encode()
        elif args[:2] == ("container", "inspect"):
            if args[3] == proof.ORIGINAL_FORMAT:
                original_reads.append(True)
                current = originals if fault != "final" or len(original_reads) == 1 else []
                out = b"\n".join(json.dumps(r).encode() for r in current)
            elif args[-1] not in rows:
                rc, err = 1, b"No such container"
            else:
                row = dict(rows[args[-1]])
                if fault == "ownership":
                    row["attempt"] = "not-owned"
                out = json.dumps(row).encode()
        elif args[:2] == ("container", "create"):
            name = args[args.index("--name") + 1]
            label = args[args.index("--label") + 1].split("=", 1)[1]
            identity = f"{100 + len(rows):064x}"
            image = args[args.index("--entrypoint") + 2]
            rows[name] = {"id": identity, "name": "/" + name, "image": image, "state": "created", "exit": 0, "attempt": label}
            configurations[identity] = args
            out = identity.encode()
            assert "--pull=never" in args and "--read-only" in args and "--no-healthcheck" in args
            assert args[args.index("--network") + 1] == "none"
            assert args[args.index("--user") + 1] == "65534:65534"
            assert args[-5:-2] == ("-I", "-S", "-B")
            assert not any(arg in {"--publish", "--env-file", "--privileged", "--volumes-from"} for arg in args)
        elif args[:2] == ("container", "start"):
            row = next(r for r in rows.values() if r["id"] == args[-1])
            row["state"] = "running"
            if fault == "timeout":
                raise subprocess.TimeoutExpired("SYNTHETIC_PRIVATE", 1)
            row["state"] = "exited"
            create = configurations[row["id"]]
            module = create[-1]
            stage = create[create.index("--mount") + 1].split(",")[1].removeprefix("source=")
            p = Path(stage) / module / "main.py"
            payload = {"ok": fault != "import", "module": module, "python": [3, 11],
                       "denied": {"network": 0, "repository": 0}, "synthetic_settings": True,
                       "lifespan_run": False, "stage": "complete",
                       "loaded_sources": {module + "/main.py": hashlib.sha256(p.read_bytes()).hexdigest()}}
            if fault == "import":
                rc, row["exit"] = 1, 1
                payload.update(stage="application_import", failure_type="ModuleNotFoundError", missing_module="synthetic_missing")
            out = json.dumps(payload).encode()
        elif args[:2] == ("container", "stop"):
            next(r for r in rows.values() if r["id"] == args[-1])["state"] = "exited"
        elif args[:2] == ("container", "rm"):
            name = next(name for name, r in rows.items() if r["id"] == args[-1])
            assert rows[name]["state"] in {"created", "exited"}
            del rows[name]
        else:
            pytest.fail("unexpected operation")
        return SimpleNamespace(returncode=rc, stdout=out, stderr=err)
    report = proof.run(ROOT, tmp_path / "out", hashlib.sha256(Path(proof.__file__).read_bytes()).hexdigest(), runner=runner)
    assert (report["state"] == "READY_FOR_INDEPENDENT_REVIEW") == (fault is None)
    assert "SYNTHETIC_PRIVATE" not in json.dumps(report)
    original_ids = {r["id"] for r in baseline}
    assert all(c[-1] not in original_ids for c in calls if c[:2] in {("container", "start"), ("container", "stop"), ("container", "rm")})
    assert not any("--force" in c or "--volumes" in c or c[0] in {"build", "exec", "pull"} for c in calls)
    if fault is None:
        assert len(report["results"]) == len(report["removed"]) == 4 and not rows
    elif fault == "ownership":
        assert report["cleanup_incomplete"] and rows
        assert not any(c[:2] in {("container", "start"), ("container", "stop"), ("container", "rm")} for c in calls)
    elif fault == "timeout":
        assert not rows and len(report["removed"]) == 1
    elif fault == "import":
        assert report["diagnostics"][0]["missing_module"] == "synthetic_missing" and not rows


def test_payload_is_inert_on_unknown_module_and_reports_safe_missing_import(tmp_path):
    payload = ROOT / proof.PAYLOAD
    result = subprocess.run([sys.executable, "-I", "-S", "-B", str(payload), "audit_log"], cwd=tmp_path,
                            capture_output=True, timeout=20, env={"PATH": "/usr/bin:/bin"})
    report = json.loads(result.stdout)
    assert result.returncode == 1 and report["ok"] is False
    assert report["stage"] == "configuration_import" and report["missing_module"] == "shared"
    assert report["denied"] == {"network": 0, "repository": 0}
