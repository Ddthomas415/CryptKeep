"""Current-caller regression for reviewed October 0010; no network or private config."""
import ast
import importlib.util
import json
import os
import time
from pathlib import Path
from types import SimpleNamespace

import pytest

from services.market_data import tick_reader


@pytest.fixture
def snapshot(monkeypatch, tmp_path):
    path = tmp_path / "snapshot.json"
    now = int(time.time() * 1000)
    path.write_text(json.dumps({"ts_ms": now,
        "venues": {"coinbase": {"bid": 99, "ask": 101, "last": 100, "timestamp": now}},
        "ticks": [{"venue": "coinbase", "symbol": "BTC/USDT", "bid": 99, "ask": 101, "last": 100, "ts_ms": now}]}))
    getter = tick_reader.get_best_bid_ask_last
    if os.getenv("CBP_R4_BEFORE_ROOT"):
        before = Path(os.environ["CBP_R4_BEFORE_ROOT"]) / "services/market_data/tick_reader.py"
        spec = importlib.util.spec_from_file_location("r4_before_reader", before)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        module.LATEST = path
        getter = module.get_best_bid_ask_last
    monkeypatch.setattr(tick_reader, "LATEST", path)
    monkeypatch.setattr(tick_reader, "get_best_bid_ask_last", getter)
    return SimpleNamespace(path=path, now=now, getter=getter)


def test_exact_quote(snapshot):
    assert snapshot.getter("coinbase", "BTC/USDT") == {"ts_ms": snapshot.now, "bid": 99, "ask": 101, "last": 100}


@pytest.mark.parametrize("symbol", ["ADA/USD", "BTC/USD", "BTC/USDC", "ADA/EUR", "BTCUSDT", "USDT/BTC"])
def test_wrong_symbol_never_borrows_venue_quote(snapshot, symbol):
    assert snapshot.getter("coinbase", symbol) is None


@pytest.mark.parametrize("spelling", ["btc/usdt", " BTC-USDT ", "btc-usdt"])
def test_publisher_spelling_rule_is_reused(snapshot, spelling):
    # No venue fallback is available to disguise a failed normalization.
    payload = json.loads(snapshot.path.read_text())
    payload.pop("venues")
    snapshot.path.write_text(json.dumps(payload))
    assert snapshot.getter("COINBASE", spelling)["bid"] == 99


@pytest.mark.parametrize("ticks", [None, [], "invalid"])
def test_venue_only_or_invalid_tick_list_cannot_price_symbol(snapshot, ticks):
    payload = json.loads(snapshot.path.read_text())
    payload["ticks"] = ticks
    snapshot.path.write_text(json.dumps(payload))
    assert snapshot.getter("coinbase", "BTC/USDT") is None


@pytest.mark.parametrize("index", range(25))
def test_each_of_twenty_five_published_symbols_gets_its_own_quote(snapshot, index):
    ticks = [{"venue": "coinbase", "symbol": f"S{i}/USD", "bid": i + 1, "ask": i + 2,
              "last": i + 1.5, "ts_ms": snapshot.now} for i in range(25)]
    snapshot.path.write_text(json.dumps({"venues": {"coinbase": {"bid": -999}}, "ticks": ticks}))
    assert snapshot.getter("coinbase", f"s{index}-usd")["last"] == index + 1.5


def test_other_venue_and_broken_or_missing_snapshot_get_no_quote(snapshot):
    assert snapshot.getter("kraken", "BTC/USDT") is None
    snapshot.path.write_text("{broken")
    assert snapshot.getter("coinbase", "BTC/USDT") is None
    snapshot.path.unlink()
    assert snapshot.getter("coinbase", "BTC/USDT") is None


@pytest.fixture
def engine(snapshot, monkeypatch, tmp_path):
    from services.execution import paper_engine
    import storage.paper_trading_sqlite as store
    monkeypatch.setattr(store, "DB_PATH", tmp_path / "data" / "paper_trading.sqlite")
    monkeypatch.setattr(paper_engine, "get_best_bid_ask_last", snapshot.getter)
    monkeypatch.setattr(paper_engine, "_cfg", lambda: {"starting_cash_quote": 1000, "quote_currency": "USD",
        "enabled": True, "max_order_qty": 1e9, "fee_bps": 50, "slippage_bps": 0, "use_ccxt_fallback": False})
    if os.getenv("CBP_R4_BEFORE_ROOT"):
        before = Path(os.environ["CBP_R4_BEFORE_ROOT"]) / "services/execution/paper_engine.py"
        tree = ast.parse(before.read_text())
        cls = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == "PaperEngine")
        method = next(node for node in cls.body if isinstance(node, ast.FunctionDef) and node.name == "_price")
        namespace = {}
        exec(compile(ast.Module(body=[method], type_ignores=[]), str(before), "exec"), paper_engine.__dict__, namespace)
        monkeypatch.setattr(paper_engine.PaperEngine, "_price", namespace[method.name])
    eng = paper_engine.PaperEngine()
    monkeypatch.setattr(eng, "_pre_submit_gate", lambda **kw: (True, None))
    return eng


def test_real_paper_buy_cannot_fill_from_another_symbol(snapshot, engine):
    result = engine.submit_order(client_order_id="r4-direct", venue="coinbase", symbol="ADA/USD",
                                 side="buy", order_type="market", qty=1)
    assert result["ok"]
    assert engine.evaluate_open_orders()["filled"] == 0
    assert engine.db.list_fills() == [] and engine.cash_quote() == 1000


def test_real_paper_sell_waits_for_its_own_quote_then_fills(snapshot, engine):
    engine.db.upsert_position("ADA/USD", 1, 50, 0)
    engine.submit_order(client_order_id="r4-sell", venue="coinbase", symbol="ADA/USD",
                        side="sell", order_type="market", qty=1)
    assert engine.evaluate_open_orders()["filled"] == 0
    assert engine.db.get_position("ADA/USD")["qty"] == 1
    snapshot.path.write_text(json.dumps({"ticks": [{"venue": "coinbase", "symbol": "ADA/USD",
        "bid": 2, "ask": 2, "last": 2, "ts_ms": snapshot.now}]}))
    assert engine.evaluate_open_orders()["filled"] == 1
    assert engine.db.list_fills()[0]["price"] == 2


@pytest.mark.parametrize("failure", ["construction", "fetch"])
def test_unavailable_exchange_price_is_none_not_a_loop_crash(snapshot, engine, monkeypatch, failure):
    from services.execution import paper_engine
    closed = []
    class Exchange:
        def fetch_ticker(self, symbol):
            raise RuntimeError("synthetic fetch failure")
        def close(self):
            closed.append(True)
    def make(*a, **kw):
        if failure == "construction":
            raise RuntimeError("synthetic construction failure")
        return Exchange()
    monkeypatch.setattr(paper_engine, "make_exchange", make)
    engine.cfg["use_ccxt_fallback"] = True
    assert engine._price("coinbase", "ADA/USD") is None
    assert bool(closed) == (failure == "fetch")


def test_exchange_fallback_requests_same_symbol(snapshot, engine, monkeypatch):
    from services.execution import paper_engine
    asked = []
    class Exchange:
        def fetch_ticker(self, symbol):
            asked.append(symbol)
            return {"timestamp": snapshot.now, "bid": 2, "ask": 4, "last": 3}
        def close(self):
            pass
    monkeypatch.setattr(paper_engine, "make_exchange", lambda *a, **kw: Exchange())
    engine.cfg["use_ccxt_fallback"] = True
    assert engine._price("coinbase", "ADA/USD")["last"] == 3
    assert asked == ["ADA/USD"]


@pytest.mark.parametrize("side", ["buy", "sell"])
def test_live_local_gate_has_no_borrowed_price(snapshot, monkeypatch, side):
    from services.execution import _executor_shared
    monkeypatch.setattr(_executor_shared, "get_best_bid_ask_last", snapshot.getter)
    cfg = SimpleNamespace(exchange_id="coinbase", symbol="ADA/USD")
    assert _executor_shared._local_gate_price(cfg, side=side) is None


def test_shadow_does_not_record_a_borrowed_fill(snapshot, monkeypatch):
    from services.execution import _executor_submit
    monkeypatch.setattr(_executor_submit, "get_best_bid_ask_last", snapshot.getter)
    monkeypatch.setattr(_executor_submit, "_shadow_would_be_fill_exists", lambda *a: False)
    monkeypatch.setattr(_executor_submit, "_evidence_strategy_id_for_shadow", lambda row: "synthetic")
    cfg = SimpleNamespace(exchange_id="coinbase", symbol="ADA/USD")
    assert _executor_submit._record_shadow_would_be_fill(cfg, {"intent_id": "r4-shadow", "symbol": "ADA/USD",
        "side": "buy", "qty": 1}) == "missing_quote"


@pytest.mark.parametrize("strict", [False, True])
def test_unknown_quote_guard_policy_is_not_silently_changed(snapshot, monkeypatch, strict):
    from services.risk import market_quality_guard
    monkeypatch.setattr(market_quality_guard, "get_best_bid_ask_last", snapshot.getter)
    monkeypatch.setattr(market_quality_guard, "_cfg", lambda: {"enabled": True, "symbol_thresholds": {},
        "max_tick_age_sec": 600, "max_spread_bps": 500, "require_bid_ask": False, "block_when_unknown": strict})
    result = market_quality_guard.check("coinbase", "ADA/USD")
    assert result["reason"] == "no_quote_data" and result["ok"] is (not strict)
