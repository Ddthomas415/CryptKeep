from __future__ import annotations

from services.risk.exit_controls import evaluate_strategy_exit_stack

import json
import logging
import math
import os
import time
import uuid
from contextlib import nullcontext
from datetime import datetime, timezone
from typing import List, Optional

from services.admin.config_editor import ConfigLoadError, load_user_yaml
from services.logging.app_logger import get_logger
from services.market_data.multi_venue_view import best_venue
from services.market_data.local_data_reader import write_local_ohlcv_snapshot
from services.market_data.hourly_candle_quality import assess_hourly_candles
from services.market_data.paper_snapshot_quote import observe_paper_quote
from services.market_data.symbol_router import map_symbol, normalize_symbol, normalize_venue
from services.market_data.tick_reader import get_best_bid_ask_last, mid_price
from services.os.app_paths import ensure_dirs, runtime_dir
from services.risk.market_quality_guard import check as mq_check
from services.control.managed_component import clean_stale_lock_file
from services.security.exchange_factory import make_exchange
from services.strategies.config_tools import build_strategy_block
from services.strategies.presets import get_preset
from services.strategies.strategy_registry import compute_signal
from services.strategies.signal_input_capture import capture_es_inputs
from services.execution.runner_decision import (
    position_aware_signal_action, signal_transition, select_exit_decision,
)
from services.execution.paper_exit_accounting import PaperExitAccounting, make_event, scope_for
from services.strategies.market_context_capture import capture_call, start_capture
from services.strategies.strategy_selector import select_strategy
from services.risk.exposure_controls import build_risk_limits, summarize_exposure, evaluate_entry
from services.risk.kill_conditions import build_kill_limits, should_block_symbol, evaluate_risk_block_kill
from services.risk.position_scaling import build_scaling_limits, summarize_position_for_scaling, evaluate_scale_in
from services.risk.performance_kill import build_performance_limits, evaluate_exit_outcome, update_drawdown_state, evaluate_performance_kill
from services.validation.paper_multi_symbol_validation import collect_runtime_rows, validate_multi_symbol_state
from storage.intent_queue_sqlite import IntentQueueSQLite
from storage.paper_trading_sqlite import PaperTradingSQLite
from storage.strategy_state_sqlite import StrategyStateSQLite
from services.execution.startup_guard import StartupGuardError, require_known_flat_or_override
from services.execution.paper_exit_retry import POLICY as PAPER_EXIT_POLICY, service_pending_paper_exits
from services.strategies.crypto_edge_context import (
    DEFAULT_CONTEXT_SOURCE,
    DEFAULT_FUNDING_MAX_AGE_SEC,
    funding_context_from_crypto_edge_store,
)

FLAGS = runtime_dir() / "flags"
LOCKS = runtime_dir() / "locks"
SNAPSHOTS = runtime_dir() / "snapshots"
STOP_FILE = FLAGS / "strategy_runner.stop"
LOCK_FILE = LOCKS / "strategy_runner.lock"
STATUS_FILE = FLAGS / "strategy_runner.status.json"

_LOG = logging.getLogger(__name__)
TICK_SNAPSHOT_FILE = SNAPSHOTS / "system_status.latest.json"

_LOG = get_logger("execution.strategy_runner")

_STRATEGY_ALIASES = {
    "ema_cross": "ema_cross",
    "ema_crossover": "ema_cross",
    "ema_xover": "ema_cross",
    "ema_xover_v1": "ema_cross",
    "es_daily_trend_v1": "sma_200_trend",
    "sma_200_trend": "sma_200_trend",
    "mean_reversion": "mean_reversion_rsi",
    "mean_reversion_rsi": "mean_reversion_rsi",
    "breakout": "breakout_donchian",
    "breakout_donchian": "breakout_donchian",
    "donchian": "breakout_donchian",
    "pullback": "pullback_recovery",
    "pullback_recovery": "pullback_recovery",
    "momentum": "momentum",
    "volatility_reversal": "volatility_reversal",
    "gap_fill": "gap_fill",
    "breakout_volume": "breakout_volume",
    "funding_extreme": "funding_extreme",
}
_DEFAULT_PRESET_BY_STRATEGY = {
    "ema_cross": "ema_cross_default",
    "mean_reversion_rsi": "mean_reversion_default",
    "breakout_donchian": "breakout_default",
    "pullback_recovery": "pullback_recovery_default",
    "sma_200_trend": "es_daily_trend_v1",
    "momentum": "momentum_default",
    "volatility_reversal": "volatility_reversal_default",
    "gap_fill": "gap_fill_default",
    "breakout_volume": "breakout_volume_default",
    "funding_extreme": "funding_extreme_default",
}
_EMA_FIELDS = (
    "ema_fast",
    "ema_slow",
    "filter_window",
    "min_volatility_pct",
    "min_volume_ratio",
    "min_trend_efficiency",
    "min_cross_gap_pct",
)
_MEAN_REVERSION_FIELDS = (
    "rsi_len",
    "rsi_buy",
    "rsi_sell",
    "sma_len",
    "filter_window",
    "max_volatility_pct",
    "min_volume_ratio",
    "max_trend_efficiency",
    "max_sma_distance_pct",
    "require_reversal_confirmation",
)
_BREAKOUT_FIELDS = (
    "donchian_len",
    "filter_window",
    "min_volatility_pct",
    "min_volume_ratio",
    "min_trend_efficiency",
    "min_channel_width_pct",
    "breakout_buffer_pct",
    "require_directional_confirmation",
)

_PULLBACK_RECOVERY_FIELDS = (
    "fast_sma_period",
    "trend_sma_period",
    "rsi_period",
    "min_pullback_pct",
    "max_pullback_pct",
    "rsi_reentry_max",
    "rebound_confirm_pct",
    "trend_reclaim_tolerance_pct",
    "exit_rsi",
    "stop_below_trend_sma",
)

_MOMENTUM_FIELDS = (
    "min_change_pct",
    "max_rsi_entry",
    "rsi_exit",
    "sma_period",
    "rsi_period",
    "stop_below_sma",
)

_VOLATILITY_REVERSAL_FIELDS = (
    "rsi_len",
    "rsi_oversold",
    "rsi_exit",
    "sma_len",
    "min_dump_bars",
    "min_dump_pct",
    "max_volatility_pct",
    "min_volume_ratio",
    "require_volume_spike",
)

_GAP_FILL_FIELDS = (
    "rsi_len",
    "rsi_buy",
    "rsi_sell",
    "sma_len",
    "min_gap_pct",
    "gap_fill_target_pct",
    "min_volume_ratio",
)

_BREAKOUT_VOLUME_FIELDS = (
    "donchian_len",
    "sma_len",
    "filter_window",
    "min_volume_ratio",
    "min_volatility_pct",
    "min_trend_efficiency",
    "breakout_buffer_pct",
    "min_channel_width_pct",
    "require_close_above",
)

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _advance_held_bar_counter(
    *,
    bars_held: int,
    last_bar_ts: int,
    current_bar_ts: int,
) -> tuple[int, int, bool]:
    current = int(current_bar_ts or 0)
    previous = int(last_bar_ts or 0)
    count = max(0, int(bars_held or 0))
    if current <= 0:
        return count, previous, False
    if previous <= 0:
        return count, current, False
    if current > previous:
        return count + 1, current, True
    return count, previous, False


def _write_status(obj: dict) -> None:
    FLAGS.mkdir(parents=True, exist_ok=True)
    STATUS_FILE.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def _write_config_load_failed_status(
    exc: ConfigLoadError,
    *,
    status: str,
    loops: int | None = None,
    enqueued: int | None = None,
    cfg: dict | None = None,
    venue: str | None = None,
    symbol: str | None = None,
) -> None:
    payload: dict[str, object] = {
        "ok": False,
        "status": status,
        "reason": "config_load_failed",
        "error": f"config_load_failed:{type(exc).__name__}",
        "error_type": type(exc).__name__,
        "ts": _now(),
        "signal_action": "hold",
        "signal_reason": "config_load_failed",
    }
    if loops is not None:
        payload["loops"] = int(loops)
    if enqueued is not None:
        payload["enqueued_total"] = int(enqueued)
    if isinstance(cfg, dict):
        payload["strategy_id"] = cfg.get("strategy_id")
        payload["signal_source"] = cfg.get("signal_source")
    if venue:
        payload["venue"] = str(venue)
    if symbol:
        payload["symbol"] = str(symbol)
    _write_status(payload)


def _no_fresh_tick_note(*, stale_after_sec: float = 30.0) -> str:
    if not TICK_SNAPSHOT_FILE.exists():
        return "no_fresh_tick:snapshot_file_missing:start_tick_publisher"
    try:
        age_sec = max(0.0, time.time() - float(TICK_SNAPSHOT_FILE.stat().st_mtime))
    except Exception:
        age_sec = stale_after_sec + 1.0
    if age_sec > float(stale_after_sec):
        return "no_fresh_tick:snapshot_stale:publisher_stopped_or_network_blocked"
    try:
        snap = json.loads(TICK_SNAPSHOT_FILE.read_text(encoding="utf-8"))
    except Exception:
        return "no_fresh_tick:snapshot_unreadable:check_tick_publisher_output"
    ticks = snap.get("ticks")
    if not isinstance(ticks, list) or not ticks:
        return "no_fresh_tick:snapshot_has_no_ticks:check_venue_connectivity"
    return "no_fresh_tick:snapshot_present_but_symbol_missing:check_symbol_or_venue_mapping"

def _acquire_lock() -> bool:
    """Acquire the single-instance runner lock atomically.

    Reclaim only locks whose recorded PID is provably dead. Malformed or
    unreadable lock files fail closed, because stealing unattributable locks can
    create duplicate runners.
    """
    LOCKS.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps({"pid": os.getpid(), "ts": _now()}, indent=2) + "\n").encode("utf-8")
    for attempt in (1, 2):
        try:
            fd = os.open(str(LOCK_FILE), os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o644)
        except FileExistsError:
            if attempt == 1 and clean_stale_lock_file(LOCK_FILE):
                continue
            return False
        try:
            os.write(fd, payload)
        finally:
            os.close(fd)
        return True
    return False

def _release_lock() -> None:
    try:
        if LOCK_FILE.exists():
            LOCK_FILE.unlink()
    except Exception:
        pass

def request_stop() -> dict:
    ensure_dirs()
    FLAGS.mkdir(parents=True, exist_ok=True)
    STOP_FILE.write_text(_now() + "\n", encoding="utf-8")
    return {"ok": True, "stop_file": str(STOP_FILE)}


def _position_aware_signal_action(signal: dict, *, strategy_id: str, position_qty: float) -> str:
    return position_aware_signal_action(signal, strategy_id=strategy_id, position_qty=position_qty)


def _kill_remaining_loops(sdb, k_kill_remaining: str, k_kill_until: str, *, max_cooldown_loops: int) -> int:
    """Persist blocked evaluations, not a process-local absolute loop number.

    Reuse patch 0001's capped legacy conversion. Save the count before clearing
    the old key so an interrupted conversion repeats rather than loses a block.
    """
    longest = max(1, int(max_cooldown_loops)) - 1
    stored = max(0, int(str(sdb.get(k_kill_remaining) or "0").strip() or 0))
    remaining = min(stored, longest)
    legacy = int(str(sdb.get(k_kill_until) or "0").strip() or 0)
    if legacy > 0:
        remaining = max(remaining, min(legacy - 1, longest))
    if remaining != stored:
        sdb.set(k_kill_remaining, str(remaining))
    if legacy > 0:
        sdb.set(k_kill_until, "0")
    return remaining


def _open_strategy_intent_state(qdb, symbol: str) -> str:
    """Return open/none/unknown without a newest-row window."""
    try:
        return "open" if qdb.has_open_strategy_intent(symbol) else "none"
    except Exception:
        return "unknown"


def _cooldown_exit_quantity(cfg: dict, held: object) -> float | None:
    """Authorize only a finite, positive position-reducing cooldown exception."""
    proposed = held if bool(cfg.get("sell_full_position")) else cfg.get("qty")
    if isinstance(held, bool) or isinstance(proposed, bool):
        return None
    try:
        held_qty, qty = float(held), float(proposed)
    except (TypeError, ValueError, OverflowError):
        return None
    if not (math.isfinite(held_qty) and math.isfinite(qty)
            and 0.0 < qty <= held_qty):
        return None
    return qty


def _safe_positive_float(value: object, *, default: float) -> float:
    try:
        out = float(value)
    except Exception:
        return float(default)
    if not math.isfinite(out) or out < 0.0:
        return float(default)
    return out


def _cfg() -> dict:
    cfg = load_user_yaml(strict=True)
    s = cfg.get("strategy_runner") if isinstance(cfg.get("strategy_runner"), dict) else {}
    pf = cfg.get("preflight") if isinstance(cfg.get("preflight"), dict) else {}

    default_symbol = globals().get("DEFAULT_SYMBOL", "BTC/USD")
    pf_venues = pf.get("venues") if isinstance(pf.get("venues"), list) else []
    pf_symbols = pf.get("symbols") if isinstance(pf.get("symbols"), list) else []

    env_v = (os.environ.get("CBP_COMPONENT_VENUE") or os.environ.get("CBP_VENUE") or "").strip().lower()
    venue = str(env_v or s.get("venue") or (pf_venues[0] if pf_venues else "coinbase")).lower().strip()

    env_symbols_raw = os.environ.get("CBP_COMPONENT_SYMBOLS") or os.environ.get("CBP_SYMBOLS") or ""
    env_syms = [x.strip() for x in env_symbols_raw.split(",") if x.strip()]
    cfg_symbols = s.get("symbols") if isinstance(s.get("symbols"), list) else []
    symbols = (
        env_syms
        or [x for x in cfg_symbols if str(x).strip()]
        or [x for x in pf_symbols if str(x).strip()]
        or [str(s.get("symbol") or default_symbol).strip()]
    )
    symbols = [str(x).strip() for x in symbols if str(x).strip()]
    symbol = str(symbols[0] if symbols else default_symbol).strip()
    strategy_block, strategy_preset = _strategy_block_from_runner_cfg(s)
    env_min_bars_raw = str(os.environ.get("CBP_STRATEGY_MIN_BARS") or "").strip()
    env_min_bars = int(env_min_bars_raw) if env_min_bars_raw else 0
    min_bars_source = env_min_bars if env_min_bars > 0 else int(s.get("min_bars", 60) or 60)
    min_bars = max(int(min_bars_source), _required_history(strategy_block))
    allow_first_signal_trade = bool(s.get("allow_first_signal_trade", False))
    if str(os.environ.get("CBP_STRATEGY_ALLOW_FIRST_SIGNAL_TRADE", "")).strip().lower() in {"1", "true", "yes", "on"}:
        allow_first_signal_trade = True
    signal_source = str(
        os.environ.get("CBP_STRATEGY_SIGNAL_SOURCE")
        or s.get("signal_source")
        or "synthetic_mid_ohlcv"
    ).strip().lower() or "synthetic_mid_ohlcv"
    venue_candidates = s.get("venue_candidates") if isinstance(s.get("venue_candidates"), list) else []

    return {
        "enabled": bool(s.get("enabled", True)),
        **_resolved_exit_controls(s, strategy_block, strategy_preset),
        "strategy_id": str(strategy_block["name"]),
        "strategy": strategy_block,
        **({"paper_entry_sizing": s["paper_entry_sizing"]} if "paper_entry_sizing" in s else {}),
        **({"group_b_selection": s["group_b_selection"]} if "group_b_selection" in s else {}),
        **({"_paper_entry_policy": {
                "live_enabled": (cfg.get("execution") if isinstance(cfg.get("execution"), dict) else {}).get("live_enabled"),
                "armed": (cfg.get("live_execution") if isinstance(cfg.get("live_execution"), dict) else {}).get("armed"),
                **{key: (cfg.get("paper_trading") if isinstance(cfg.get("paper_trading"), dict) else {}).get(key) for key in (
                    "enabled", "quote_currency", "fee_bps", "slippage_bps",
                    "require_fresh_snapshot_quotes", "use_ccxt_fallback")},
            }} if "paper_entry_sizing" in s or "group_b_selection" in s else {}),
        "strategy_preset": str(strategy_preset),
        "venue": venue,
        "symbol": symbol,
        "symbols": symbols,
        "fast_n": int(s.get("fast_n", 12) or 12),
        "slow_n": int(s.get("slow_n", 26) or 26),
        "min_bars": int(min_bars),
        "max_bars": int(s.get("max_bars", 400) or 400),
        "loop_interval_sec": float(s.get("loop_interval_sec", 1.0) or 1.0),
        "qty": float(s.get("qty", 0.001) or 0.001),
        "order_type": str(s.get("order_type", "market") or "market").lower().strip(),
        "allow_first_signal_trade": allow_first_signal_trade,
        "use_ccxt_fallback": bool(s.get("use_ccxt_fallback", True)),
        "max_tick_age_sec": float(s.get("max_tick_age_sec", 5.0) or 5.0),
        "position_aware": bool(s.get("position_aware", True)),
        "sell_full_position": bool(s.get("sell_full_position", True)),
        "signal_source": signal_source,
        "auto_select_best_venue": bool(s.get("auto_select_best_venue", False)),
        "switch_only_when_blocked": bool(s.get("switch_only_when_blocked", True)),
        "venue_candidates": [str(v).lower().strip() for v in venue_candidates if str(v).strip()],
        "strategy_context_source": str(
            os.environ.get("CBP_STRATEGY_CONTEXT_SOURCE")
            or s.get("strategy_context_source")
            or DEFAULT_CONTEXT_SOURCE
        ).strip() or DEFAULT_CONTEXT_SOURCE,
        "strategy_context_symbol": str(
            os.environ.get("CBP_STRATEGY_CONTEXT_SYMBOL")
            or s.get("strategy_context_symbol")
            or symbol
        ).strip() or symbol,
        "strategy_context_venue": str(
            os.environ.get("CBP_STRATEGY_CONTEXT_VENUE")
            or s.get("strategy_context_venue")
            or venue
        ).strip() or venue,
        "strategy_context_db_path": str(
            os.environ.get("CBP_CRYPTO_EDGE_DB_PATH")
            or s.get("strategy_context_db_path")
            or ""
        ).strip(),
        "strategy_context_max_age_sec": _safe_positive_float(
            os.environ.get("CBP_STRATEGY_CONTEXT_MAX_AGE_SEC")
            or s.get("strategy_context_max_age_sec")
            or DEFAULT_FUNDING_MAX_AGE_SEC,
            default=DEFAULT_FUNDING_MAX_AGE_SEC,
        ),
    }


def _resolved_exit_controls(s: dict, block: dict, preset_name: str) -> dict:
    """Resolve only exit controls; never import unrelated preset risk policy."""
    if block.get("unsupported"):
        return {}
    keys = ("stop_loss_pct", "take_profit_pct", "trailing_stop_pct", "max_bars_hold")
    preset = get_preset(preset_name) or {}
    preset_strategy = preset.get("strategy") or {}
    if _canonical_strategy_name(preset_strategy.get("name")) != block.get("name"):
        raise ValueError("exit_policy_preset_identity_mismatch")
    values = {k: v for k, v in (preset.get("risk") or {}).items() if k in keys}
    nested = s.get("strategy") if isinstance(s.get("strategy"), dict) else {}
    local_name = nested.get("name", s.get("strategy_name", s.get("strategy_id")))
    # Unnamed settings cannot establish ownership during a managed override.
    owns_local = os.environ.get("CBP_STRATEGY_NAME") is None or (
        local_name is not None and _canonical_strategy_name(local_name) == block.get("name")
    )
    if owns_local:
        risk = s.get("risk", {})
        if not isinstance(risk, dict):
            raise ValueError("invalid_exit_risk_config")
        values.update({k: risk[k] for k in keys if k in risk})
        values.update({k: s[k] for k in keys if k in s})
    for key, value in values.items():
        try:
            number = float(value)
        except (TypeError, ValueError, OverflowError) as exc:
            raise ValueError(f"invalid_exit_control:{key}") from exc
        if isinstance(value, bool) or not math.isfinite(number) or number < 0:
            raise ValueError(f"invalid_exit_control:{key}")
        if key == "max_bars_hold" and not number.is_integer():
            raise ValueError(f"invalid_exit_control:{key}")
        values[key] = int(number) if key == "max_bars_hold" else number
    return values


def _configured_strategy_name(s: dict, nested: dict) -> tuple[object, bool]:
    env_name = os.environ.get("CBP_STRATEGY_NAME")
    if env_name is not None:
        return env_name, True
    if "name" in nested:
        return nested.get("name"), True
    if "strategy_name" in s:
        return s.get("strategy_name"), True
    if "strategy_id" in s:
        return s.get("strategy_id"), True
    return "ema_cross", False


def _canonical_strategy_name(raw: object) -> str | None:
    key = str(raw or "").strip().lower()
    if not key:
        return None
    return _STRATEGY_ALIASES.get(key)


def _unsupported_strategy_block(raw_name: object, nested: dict) -> dict:
    return {
        "name": str(raw_name or "").strip().lower(),
        "trade_enabled": bool(nested.get("trade_enabled", True)),
        "unsupported": True,
    }


def _legacy_strategy_params(s: dict, strategy_name: str) -> dict:
    params: dict = {}
    if strategy_name == "ema_cross":
        if "fast_n" in s:
            params["ema_fast"] = s.get("fast_n")
        if "slow_n" in s:
            params["ema_slow"] = s.get("slow_n")
        for field in _EMA_FIELDS[2:]:
            if field in s:
                params[field] = s.get(field)
        return params
    if strategy_name == "mean_reversion_rsi":
        for field in _MEAN_REVERSION_FIELDS:
            if field in s:
                params[field] = s.get(field)
        return params
    if strategy_name == "breakout_donchian":
        for field in _BREAKOUT_FIELDS:
            if field in s:
                params[field] = s.get(field)
        return params
    if strategy_name == "pullback_recovery":
        for field in _PULLBACK_RECOVERY_FIELDS:
            if field in s:
                params[field] = s.get(field)
        return params
    if strategy_name == "momentum":
        for field in _MOMENTUM_FIELDS:
            if field in s:
                params[field] = s.get(field)
        return params
    if strategy_name == "volatility_reversal":
        for field in _VOLATILITY_REVERSAL_FIELDS:
            if field in s:
                params[field] = s.get(field)
        return params
    if strategy_name == "gap_fill":
        for field in _GAP_FILL_FIELDS:
            if field in s:
                params[field] = s.get(field)
        return params
    if strategy_name == "breakout_volume":
        for field in _BREAKOUT_VOLUME_FIELDS:
            if field in s:
                params[field] = s.get(field)
        return params
    return params


def _strategy_block_from_runner_cfg(s: dict) -> tuple[dict, str]:
    nested = s.get("strategy") if isinstance(s.get("strategy"), dict) else {}
    raw_name, explicitly_configured = _configured_strategy_name(s, nested)
    strategy_name = _canonical_strategy_name(raw_name)
    if strategy_name is None:
        if explicitly_configured:
            preset_name = str(
                os.environ.get("CBP_STRATEGY_PRESET")
                or s.get("strategy_preset")
                or "unknown_strategy"
            ).strip() or "unknown_strategy"
            return _unsupported_strategy_block(raw_name, nested), preset_name
        strategy_name = "ema_cross"
    default_preset = _DEFAULT_PRESET_BY_STRATEGY[strategy_name]
    local_name = nested.get("name", s.get("strategy_name", s.get("strategy_id")))
    switched_strategy = (
        os.environ.get("CBP_STRATEGY_NAME") is not None
        and local_name is not None
        and _canonical_strategy_name(local_name) != strategy_name
    )
    preset_name = str(
        os.environ.get("CBP_STRATEGY_PRESET")
        or (None if switched_strategy else s.get("strategy_preset"))
        or default_preset
    ).strip() or default_preset
    preset = get_preset(preset_name) or get_preset(default_preset) or {}
    if preset_name != default_preset and not get_preset(preset_name):
        preset_name = default_preset

    merged = dict(preset.get("strategy") if isinstance(preset.get("strategy"), dict) else {})
    # A managed name override must not relabel another strategy's parameters.
    if not switched_strategy:
        merged.update(_legacy_strategy_params(s, strategy_name))
    for key, value in ({} if switched_strategy else nested).items():
        if key == "name" or value is None:
            continue
        merged[key] = value

    trade_enabled = bool(nested.get("trade_enabled", merged.get("trade_enabled", True)))
    strategy_block = build_strategy_block(
        name=strategy_name,
        trade_enabled=trade_enabled,
        params=merged,
    )
    return strategy_block, preset_name


def _signal_strategy_block_from_selected_name(selected_strategy: object, raw_strategy: dict) -> dict:
    strategy_name = _canonical_strategy_name(selected_strategy)
    if strategy_name is None:
        return _unsupported_strategy_block(selected_strategy, raw_strategy)

    selected_params = dict(raw_strategy)
    selected_params.pop("name", None)
    selected_params.pop("trade_enabled", None)
    return build_strategy_block(
        name=strategy_name,
        trade_enabled=bool(raw_strategy.get("trade_enabled", True)),
        params=selected_params,
    )


def _required_history(strategy_block: dict) -> int:
    if bool(strategy_block.get("unsupported")):
        return 5
    name = str(strategy_block.get("name") or "ema_cross")
    if name == "ema_cross":
        return max(
            int(strategy_block.get("ema_slow", 26) or 26) + 2,
            int(strategy_block.get("filter_window", 0) or 0) + 2,
            5,
        )
    if name == "mean_reversion_rsi":
        return max(
            int(strategy_block.get("rsi_len", 14) or 14) + 2,
            int(strategy_block.get("sma_len", 50) or 50) + 2,
            int(strategy_block.get("filter_window", 0) or 0) + 2,
            5,
        )
    if name == "breakout_donchian":
        return max(
            int(strategy_block.get("donchian_len", 20) or 20) + 2,
            int(strategy_block.get("filter_window", 0) or 0) + 2,
            5,
        )
    if name == "pullback_recovery":
        return max(
            int(strategy_block.get("fast_sma_period", 20) or 20) + 2,
            int(strategy_block.get("trend_sma_period", 50) or 50) + 5,
            int(strategy_block.get("rsi_period", 14) or 14) + 2,
            5,
        )
    if name == "sma_200_trend":
        return max(
            int(strategy_block.get("sma_period", 200) or 200) + 10,
            int(strategy_block.get("atr_period", 20) or 20) + 2,
        )
    return 5


def _synth_ohlcv(prices: List[float], *, ts_ms: int | None = None) -> list[list[float]]:
    clean = [float(x) for x in (prices or []) if isinstance(x, (int, float)) and math.isfinite(float(x))]
    if not clean:
        return []
    base_ts = int(ts_ms or int(time.time() * 1000)) - max(0, len(clean) - 1) * 1000
    rows: list[list[float]] = []
    prev = clean[0]
    for idx, close in enumerate(clean):
        open_px = prev if idx else close
        high = max(open_px, close)
        low = min(open_px, close)
        rows.append([base_ts + idx * 1000, open_px, high, low, close, 1.0])
        prev = close
    return rows


def _strategy_signal(cfg: dict, prices: List[float], *, ts_ms: int | None = None, observer=None,
                     input_observer=None) -> dict:
    rows = _synth_ohlcv(prices, ts_ms=ts_ms)
    if input_observer is not None:
        try:
            input_observer(rows)
        except Exception:
            pass
    return compute_signal(
        **({"observer": observer} if observer is not None else {}),
        cfg={"strategy": dict(cfg.get("strategy") or {})},
        symbol=str(cfg.get("symbol") or ""),
        ohlcv=rows,
    )


def _context_meta_from_result(result: dict) -> dict:
    return {
        "strategy_context_ok": bool(result.get("ok")),
        "strategy_context_reason": result.get("reason"),
        "strategy_context_source": result.get("source"),
        "strategy_context_symbol": result.get("symbol"),
        "strategy_context_venue": result.get("venue"),
        "strategy_context_capture_ts": result.get("capture_ts"),
        "strategy_context_snapshot_id": result.get("snapshot_id"),
    }


def _registry_signal_with_context(
    *,
    cfg: dict,
    strategy_block: dict,
    symbol: str,
    venue: str,
    ohlcv: list[list[float]],
    observer=None,
) -> dict:
    strategy_name = str(strategy_block.get("name") or "").strip()
    context = None
    context_meta: dict = {}
    if strategy_name == "funding_extreme":
        context_result = funding_context_from_crypto_edge_store(
            symbol=str(cfg.get("strategy_context_symbol") or symbol),
            venue=str(cfg.get("strategy_context_venue") or venue),
            source=str(cfg.get("strategy_context_source") or DEFAULT_CONTEXT_SOURCE),
            max_age_sec=float(cfg.get("strategy_context_max_age_sec") or DEFAULT_FUNDING_MAX_AGE_SEC),
            store_path=str(cfg.get("strategy_context_db_path") or ""),
        )
        context_meta = _context_meta_from_result(context_result)
        if bool(context_result.get("ok")):
            context = context_result.get("context")

    capture_extra = capture_es_inputs(
        strategy=strategy_block, symbol=symbol, venue=venue, ohlcv=ohlcv,
    )
    if capture_extra:
        strategy_block = dict(strategy_block)
        strategy_block["evidence_extra"] = {
            **(strategy_block.get("evidence_extra") or {}), **capture_extra,
        }
    kwargs = {
        "cfg": {"strategy": strategy_block},
        "symbol": symbol,
        "ohlcv": ohlcv,
    }
    if context is not None:
        kwargs["context"] = context
    if observer is not None:
        kwargs["observer"] = observer
    signal = compute_signal(**kwargs)
    if isinstance(signal, dict) and capture_extra:
        signal.update(capture_extra)
    if isinstance(signal, dict) and context_meta:
        signal.update({k: v for k, v in context_meta.items() if v is not None})
    return signal


def _public_ohlcv_timeframe(cfg: dict) -> str | None:
    source = str(cfg.get("signal_source") or "").strip().lower()
    if source.startswith("public_ohlcv_"):
        timeframe = source.removeprefix("public_ohlcv_").strip()
        return timeframe or None
    return None


def _sample_ohlcv_env_enabled() -> bool:
    return str(os.environ.get("CBP_USE_SAMPLE_OHLCV") or "").strip().lower() in {"1", "true", "yes", "on"}


def _public_ohlcv_evidence_extra(cfg: dict, timeframe: str, source_info: dict | None = None) -> dict:
    """
    Stamp OHLCV provenance from the actual data source reported by
    ``_fetch_public_ohlcv``, not from the env flag. The env claim is recorded
    alongside for auditability, and any disagreement between the env claim
    and the actual source sets ``ohlcv_source_mismatch`` (the runner holds
    the signal fail-closed on that flag).

    ``source_info=None`` preserves the legacy env-derived behavior for any
    caller without fetch-site truth; those labels are marked
    ``ohlcv_sample_mode_origin="env"`` so derived and claimed labels are
    distinguishable downstream.
    """
    env_sample_mode = _sample_ohlcv_env_enabled()
    out: dict[str, object] = {
        "ohlcv_timeframe": timeframe,
        "ohlcv_venue": str(cfg.get("venue") or ""),
        "ohlcv_symbol": str(cfg.get("symbol") or ""),
        "ohlcv_sample_mode_env": env_sample_mode,
    }
    if not isinstance(source_info, dict):
        out.update({
            "market_data_source": "sample_ohlcv" if env_sample_mode else "public_ohlcv",
            "ohlcv_sample_mode": env_sample_mode,
            "ohlcv_sample_mode_origin": "env",
        })
        return out

    actual_source = str(source_info.get("source") or "none")
    actual_sample = actual_source == "sample_ohlcv"
    out.update({
        "market_data_source": actual_source if actual_source in {"sample_ohlcv", "public_ohlcv"} else "unknown_ohlcv",
        "ohlcv_sample_mode": actual_sample,
        "ohlcv_sample_mode_origin": "source",
        "ohlcv_source_mismatch": bool(env_sample_mode != actual_sample or actual_source not in {"sample_ohlcv", "public_ohlcv"}),
    })
    if actual_sample:
        if source_info.get("sample_path"):
            out["ohlcv_sample_path"] = str(source_info.get("sample_path"))
        if bool(source_info.get("sample_fallback")):
            out["ohlcv_sample_fallback"] = True
    return out


def _market_quality_evidence_extra(venue: str, symbol: str) -> dict:
    out: dict[str, object] = {
        "market_quality_venue": str(venue or ""),
        "market_quality_symbol": str(symbol or ""),
    }
    try:
        quality = dict(mq_check(str(venue or ""), str(symbol or "")) or {})
    except Exception as exc:
        out["market_quality_ok"] = False
        out["market_quality_reason"] = f"error:{type(exc).__name__}"
        return out

    out["market_quality_ok"] = bool(quality.get("ok"))
    out["market_quality_reason"] = str(quality.get("reason") or "ok")

    field_map = {
        "bid": "market_bid",
        "ask": "market_ask",
        "last": "market_last",
        "price_used": "market_price_used",
        "age_sec": "market_age_sec",
        "max_spread_bps": "market_max_spread_bps",
        "max_tick_age_sec": "market_max_tick_age_sec",
        "spread_bps": "spread_bps",
    }
    for source_key, output_key in field_map.items():
        value = quality.get(source_key)
        if value is not None:
            out[output_key] = value
    return out


class _PublicOHLCVClients:
    """Single runner-owned clients; never shared with order execution."""

    def __init__(self):
        self._clients = {}

    def get(self, venue):
        if venue not in self._clients:
            self._clients[venue] = make_exchange(
                venue, {"apiKey": None, "secret": None}, enable_rate_limit=True
            )
        return self._clients[venue]

    def close(self):
        clients, self._clients = self._clients, {}
        for client in clients.values():
            try:
                if hasattr(client, "close"):
                    client.close()
            except Exception:
                _LOG.warning("ohlcv_client_close_failed", exc_info=True)


def _fetch_public_ohlcv(cfg: dict, *, clients=None, health=None) -> tuple[list[list[float]], dict]:
    """
    Fetch OHLCV rows and report the actual source that produced them.

    Returns ``(rows, source_info)`` where ``source_info`` carries the truth
    for evidence labeling: ``source`` is ``sample_ohlcv``/``public_ohlcv``/
    ``none``, plus ``sample_path``, ``sample_fallback``, ``row_count``, and
    the env claim at fetch time (``env_sample_mode``). Substrate: sample-mode
    provenance must agree with the actual data source, not the env flag.
    """
    env_sample_mode = _sample_ohlcv_env_enabled()
    source_info: dict[str, object] = {
        "source": "none",
        "sample_path": None,
        "sample_fallback": False,
        "row_count": 0,
        "env_sample_mode": env_sample_mode,
    }
    timeframe = _public_ohlcv_timeframe(cfg)
    if not timeframe:
        return [], source_info

    # In sample mode, skip live fetch entirely and go straight to sample data.
    if env_sample_mode:
        import json as _json
        raw_sym = str(cfg.get("symbol") or "BTC/USDT").replace("/", "_")
        sample = (
            __import__("pathlib").Path(__file__).parent.parent.parent
            / "sample_data" / "ohlcv" / f"{raw_sym}_{timeframe}.json"
        )
        if sample.exists():
            try:
                rows = _json.loads(sample.read_text())
                _LOG.info("ohlcv_sample_primary symbol=%s rows=%s", raw_sym, len(rows))
                result = [list(r) for r in rows if isinstance(r, list) and len(r) >= 6]
                _persist_public_ohlcv_snapshot(cfg, timeframe, result, source="sample_ohlcv")
                source_info.update({"source": "sample_ohlcv", "sample_path": str(sample), "row_count": len(result)})
                return result, source_info
            except Exception as _se:
                _LOG.warning("ohlcv_sample_read_failed: %s", _se)
        return [], source_info

    ex = None
    try:
        ex = (clients.get(cfg["venue"]) if clients is not None else
              make_exchange(cfg["venue"], {"apiKey": None, "secret": None}, enable_rate_limit=True))
        symbol = map_symbol(cfg["venue"], normalize_symbol(cfg["symbol"]))
        limit = max(int(cfg["min_bars"]), int(cfg["max_bars"]))
        with (health.attempt(ex) if health is not None else nullcontext()) as observation:
            rows = ex.fetch_ohlcv(symbol, timeframe=timeframe, limit=limit)
            result = [list(row) for row in list(rows or []) if isinstance(row, (list, tuple)) and len(row) >= 6]
            if observation is not None:
                observation.success = bool(result)
        if result:
            _persist_public_ohlcv_snapshot(cfg, timeframe, result, source="public_ohlcv")
            source_info.update({"source": "public_ohlcv", "row_count": len(result)})
            return result, source_info
    except Exception as _fetch_err:
        _LOG.warning("ohlcv_live_fetch_failed venue=%s symbol=%s timeframe=%s err=%s",
                     cfg.get("venue"), cfg.get("symbol"), timeframe, _fetch_err)
    finally:
        try:
            if clients is None and ex is not None and hasattr(ex, "close"):
                ex.close()
        except Exception:
            pass

    # Fallback: use sample OHLCV data for paper/dev mode.
    # Only activates when CBP_USE_SAMPLE_OHLCV=1 (set in paper runner for dev).
    # NOTE: with the sample-primary branch above, this fallback is only
    # reachable if the env flag flips mid-call; kept defensively and tagged
    # truthfully so any rows it ever produces are labeled sample+fallback.
    if _sample_ohlcv_env_enabled():
        import json as _json
        raw_sym = str(cfg.get("symbol") or "BTC/USDT").replace("/", "_")
        sample = (
            __import__("pathlib").Path(__file__).parent.parent.parent
            / "sample_data" / "ohlcv" / f"{raw_sym}_{timeframe}.json"
        )
        if sample.exists():
            try:
                rows = _json.loads(sample.read_text())
                _LOG.info("ohlcv_sample_fallback symbol=%s rows=%s", raw_sym, len(rows))
                result = [list(r) for r in rows if isinstance(r, list) and len(r) >= 6]
                _persist_public_ohlcv_snapshot(cfg, timeframe, result, source="sample_ohlcv")
                source_info.update({
                    "source": "sample_ohlcv",
                    "sample_path": str(sample),
                    "sample_fallback": True,
                    "row_count": len(result),
                    "env_sample_mode": True,
                })
                return result, source_info
            except Exception as _se:
                _LOG.warning("ohlcv_sample_read_failed: %s", _se)
        else:
            _LOG.warning("ohlcv_sample_not_found: %s", sample)
    return [], source_info


def _persist_public_ohlcv_snapshot(cfg: dict, timeframe: str, rows: list[list[float]], *, source: str = "unknown") -> None:
    if not rows:
        return
    venue = str(cfg.get("venue") or "").strip()
    symbol = str(cfg.get("symbol") or "").strip()
    if not venue or not symbol:
        return
    try:
        write_local_ohlcv_snapshot(venue, symbol, rows, timeframe=timeframe, source=source)
    except Exception as exc:
        _LOG.warning(
            "ohlcv_snapshot_write_failed venue=%s symbol=%s timeframe=%s err=%s",
            venue,
            symbol,
            timeframe,
            exc,
        )

def _fetch_mid(cfg: dict) -> Optional[tuple[float, int]]:
    q = get_best_bid_ask_last(cfg["venue"], cfg["symbol"])
    if q:
        m = mid_price(q)
        ts_ms = int(q.get("ts_ms") or 0)
        if m is None:
            return None
        age = (time.time() * 1000.0 - float(ts_ms)) / 1000.0 if ts_ms else 9999.0
        if age > float(cfg["max_tick_age_sec"]):
            return None
        return float(m), ts_ms
    if not cfg["use_ccxt_fallback"]:
        return None
    ex = None
    try:
        ex = make_exchange(cfg["venue"], {"apiKey": None, "secret": None}, enable_rate_limit=True)
        t = ex.fetch_ticker(cfg["symbol"])
        bid = t.get("bid")
        ask = t.get("ask")
        last = t.get("last")
        if bid is not None and ask is not None:
            m = (float(bid) + float(ask)) / 2.0
        elif last is not None:
            m = float(last)
        else:
            return None
        ts_ms = int(t.get("timestamp") or (time.time() * 1000))
        return m, ts_ms
    except Exception:
        return None
    finally:
        try:
            if ex is not None and hasattr(ex, "close"):
                ex.close()
        except Exception:
            pass


def _resolve_venue_candidates(cfg: dict) -> list[str]:
    candidates = cfg.get("venue_candidates")
    if not isinstance(candidates, list) or not candidates:
        base_cfg = load_user_yaml(strict=True)
        pf = base_cfg.get("preflight") if isinstance(base_cfg.get("preflight"), dict) else {}
        candidates = pf.get("venues") if isinstance(pf.get("venues"), list) else [cfg["venue"]]
    out: list[str] = []
    for venue in candidates:
        normalized = normalize_venue(str(venue))
        if normalized and normalized not in out:
            out.append(normalized)
    current = normalize_venue(cfg["venue"])
    if current and current not in out:
        out.append(current)
    return out


def _choose_venue_for_symbol(cfg: dict, symbol: str, *, candidates: Optional[list[str]] = None) -> str:
    current_venue = normalize_venue(cfg["venue"])
    if not bool(cfg.get("auto_select_best_venue")):
        return current_venue
    resolved_candidates = candidates or _resolve_venue_candidates(cfg)
    if bool(cfg.get("switch_only_when_blocked", True)):
        gate = mq_check(current_venue, symbol)
        if not gate.get("ok"):
            best = best_venue(resolved_candidates, symbol, require_ok=True)
            if best and best.get("venue"):
                return normalize_venue(str(best["venue"]))
        return current_venue
    best = best_venue(resolved_candidates, symbol, require_ok=True)
    if best and best.get("venue"):
        return normalize_venue(str(best["venue"]))
    return current_venue


def _execution_identity_meta(*, cfg, strategy, venue, symbol, provenance):
    if os.environ.get("CBP_CAPTURE_EXECUTION_IDENTITY") != "1":
        return {}
    try:
        from services.strategies import es_daily_trend
        from services.strategies.runtime_execution_identity import (
            capture_intent_identity, loaded_functions_digest,
        )
        from services.execution import paper_engine
        from services.risk import exit_controls

        raw = load_user_yaml(strict=True)
        paper = raw.get("paper_trading") or {}
        if not isinstance(paper, dict) or not isinstance(strategy, dict):
            raise ValueError("identity_unresolved_config")
        sizing_functions = {}
        if "paper_entry_sizing" in cfg:
            from services.execution import paper_cash_entry
            sizing_functions = {
                "paper_cash_quantity": paper_cash_entry.cash_quantity,
                "paper_cash_inputs": paper_cash_entry.size_paper_entry,
                "paper_cash_number": paper_cash_entry._number,
                "paper_cash_rules": paper_cash_entry._cached_rules,
                "paper_cash_snapshot": PaperTradingSQLite.entry_cash_snapshot,
            }
        implementation = {
            "signal": loaded_functions_digest({
                **{name: fn for name, fn in vars(es_daily_trend).items()
                   if callable(fn) and getattr(fn, "__module__", None) == es_daily_trend.__name__},
                "registry": compute_signal,
            }),
            "resolver": loaded_functions_digest({
                "cfg": _cfg, "strategy_block": _strategy_block_from_runner_cfg,
                "exit_controls": _resolved_exit_controls, "strategy_builder": build_strategy_block,
                **sizing_functions,
            }),
            "exits": loaded_functions_digest({
                name: fn for name, fn in vars(exit_controls).items()
                if callable(fn) and getattr(fn, "__module__", None) == exit_controls.__name__
            }),
            "paper_engine": loaded_functions_digest({
                "cfg": paper_engine._cfg, "apply_fill": paper_engine.PaperEngine._apply_fill,
                "store_apply_fill": PaperTradingSQLite.apply_fill,
            }),
        }
        return capture_intent_identity(
            cfg=cfg, strategy=strategy,
            market={"venue": venue, "symbol": symbol,
                    "timeframe": provenance.get("ohlcv_timeframe"),
                    "source": provenance.get("market_data_source"),
                    "sample_mode": provenance.get("ohlcv_sample_mode")},
            paper_config=paper, implementation=implementation,
        )
    except Exception as exc:
        return {"execution_identity_capture_status": "failed",
                "execution_identity_error_type": type(exc).__name__}


def run_forever() -> None:
    # Runner emission contract:
    # - emits at most one intent per position transition (flat->long, long->exit)
    # - suppresses repeated emissions of the same action via last_emitted_action
    # - latch resets only when the signal/exit condition no longer requests that action
    # - a neutral hold does not force an exit; exits come from opposite signals or explicit exit controls
    # - runner does not own order lifecycle; paper/live engines resolve queued intents
    # - source of truth for current position is PaperTradingSQLite.get_position()
    ensure_dirs()
    try:
        cfg = _cfg()
    except ConfigLoadError as exc:
        _write_config_load_failed_status(exc, status="stopped")
        return
    symbols = list(cfg.get("symbols") or [cfg.get("symbol")])
    symbols = [str(x).strip() for x in symbols if str(x).strip()]
    if not cfg["enabled"]:
        _write_status({"ok": False, "reason": "disabled", "ts": _now()})
        return
    try:
        if STOP_FILE.exists():
            STOP_FILE.unlink()
    except Exception:
        pass
    if not _acquire_lock():
        _write_status({"ok": False, "reason": "lock_exists", "lock_file": str(LOCK_FILE), "ts": _now()})
        return
    qdb = IntentQueueSQLite()
    pdb = PaperTradingSQLite()
    sdb = StrategyStateSQLite()
    exit_accounting = PaperExitAccounting(sdb, qdb)
    risk_limits = build_risk_limits(cfg)
    kill_limits = build_kill_limits(cfg)
    scaling_limits = build_scaling_limits(cfg)
    performance_limits = build_performance_limits(cfg)

    # Breakout/post-entry exit defaults.
    # These are runner-level controls and should be explicitly versioned in strategy config
    # before governed evidence runs.
    risk_cfg = cfg.get("risk") if isinstance(cfg.get("risk"), dict) else {}
    cfg.setdefault("stop_loss_pct", risk_cfg.get("stop_loss_pct", 0.03))
    cfg.setdefault("take_profit_pct", risk_cfg.get("take_profit_pct", 0.06))
    cfg.setdefault("trailing_stop_pct", risk_cfg.get("trailing_stop_pct", 0.02))
    cfg.setdefault("max_bars_hold", risk_cfg.get("max_bars_hold", 60))

    # ema_cross_v2 post-entry invalidation defaults
    cfg.setdefault("ema_invalidate_on_low_vol", True)
    cfg.setdefault("ema_invalidate_on_chop", True)
    cfg.setdefault("ema_invalidate_on_cross_gap_loss", True)

    loops = 0
    enqueued = 0
    checked_startup_pairs: set[tuple[str, str]] = set()
    startup_precheck_complete = False
    public_clients = _PublicOHLCVClients()
    fetch_health = None
    fetch_writer = None
    observed_attempt = None
    if os.environ.get("CBP_CAPTURE_GROUP_A_FETCH_HEALTH") == "1" and len(symbols) == 1:
        from services.alerts.group_a_fetch_health import CandleFetchHealth, FILENAME

        fetch_writer = uuid.uuid4().hex
        fetch_health = CandleFetchHealth(FLAGS / FILENAME, symbols[0], writer_id=fetch_writer)

    def write_run_status(payload):
        if fetch_writer is not None:
            payload = {**payload, "group_a_fetch_writer": fetch_writer}
            if payload.get("status") == "running" and observed_attempt is not None:
                payload["group_a_fetch_attempt"] = observed_attempt
        _write_status(payload)

    write_run_status({"ok": True, "status": "running", "pid": os.getpid(), "cfg": cfg, "ts": _now()})
    context_capture = start_capture(cfg)
    recording_enabled = os.environ.get("CBP_CAPTURE_RUNNER_DECISIONS") == "1"
    recording_session = uuid.uuid4().hex if recording_enabled else None
    recording_counts = {"written": 0, "failed": 0}
    try:
        while True:
            loops += 1
            observed_attempt = None
            if STOP_FILE.exists():
                write_run_status(
                    {
                        "ok": True,
                        "status": "stopping",
                        "pid": os.getpid(),
                        "ts": _now(),
                        "loops": loops,
                        "enqueued": enqueued,
                    }
                )
                break
            try:
                venue_candidates = (
                    _resolve_venue_candidates(cfg)
                    if bool(cfg.get("auto_select_best_venue"))
                    else []
                )
            except ConfigLoadError as exc:
                _write_config_load_failed_status(
                    exc,
                    status="running",
                    loops=loops,
                    enqueued=enqueued,
                    cfg=cfg,
                )
                time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                continue

            slot_decision = None
            if "group_b_selection" in cfg:
                from services.execution.paper_weekly_slot import resolve_slot
                slot_decision = resolve_slot(cfg=cfg, sdb=sdb, qdb=qdb, pdb=pdb,
                                            accounting=exit_accounting, limits=performance_limits, now=_now())
                symbols = slot_decision["symbols"]
                if not symbols:
                    write_run_status({"ok": False, "status": "running", "ts": _now(),
                                      "note": "group_b_ownership_unknown", "group_b": slot_decision})
                    time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                    continue

            if len(symbols) > 1 and not startup_precheck_complete:
                # Preserve patch 0004's all-symbol startup check and round-robin
                # service; no symbol trades before these checks have passed.
                for startup_symbol in symbols:
                    startup_pair = (_choose_venue_for_symbol(cfg, startup_symbol, candidates=venue_candidates), startup_symbol)
                    if startup_pair not in checked_startup_pairs:
                        require_known_flat_or_override(venue=startup_pair[0], symbol=startup_symbol)
                        checked_startup_pairs.add(startup_pair)
                startup_precheck_complete = True
            symbol_turn = (loops - 1) % max(1, len(symbols))
            persist_prices = ((loops - 1) // max(1, len(symbols)) + 1) % 5 == 0

            turn_state_ready = False
            prices_loaded = False
            pending_exit_serviced = False
            record = None
            try:
                for symbol in symbols[symbol_turn:symbol_turn + 1]:
                    if recording_enabled:
                        record = {
                            "version": 2, "session_id": recording_session, "loop": loops,
                            "symbol": symbol, "venue": str(cfg["venue"]), "observed_at": _now(),
                            "kind": "skipped", "pipeline_stage": "venue_selection",
                            "settings": {"runner": dict(cfg), "strategy": dict(cfg.get("strategy") or {})},
                            "ohlcv": [], "signal_computed": False, "raw_signal": {},
                            "actual": {"outcome": "not_evaluated"},
                        }
                    fresh_market = None
                    selected_venue = _choose_venue_for_symbol(cfg, symbol, candidates=venue_candidates)
                    if record is not None:
                        record["venue"] = selected_venue
                        record["pipeline_stage"] = "load_state"
                        record["quote_quality"] = observe_paper_quote(selected_venue, symbol, clock=_now)
                    startup_pair = (selected_venue, symbol)
                    if startup_pair not in checked_startup_pairs:
                        require_known_flat_or_override(venue=selected_venue, symbol=symbol)
                        checked_startup_pairs.add(startup_pair)

                    signal = {"ok": True, "action": "hold", "reason": "no_signal"}
                    selection = {}
                    # Evidence label only. Empty means explicitly invalid identity;
                    # do not invent an executable/reporting fallback.
                    selected_strategy = str(cfg.get("strategy_id") or "")
                    identity_strategy = None

                    k_prices = f"prices:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_last_action = f"last_action:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_last_emitted_action = f"last_emitted_action:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_warm = f"warmed:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_entry_price = f"entry_price:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_trailing_peak = f"trailing_peak:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_bars_held = f"bars_held:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_last_held_bar_ts = f"last_held_bar_ts:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_kill_until = f"kill_until:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_kill_remaining = f"kill_remaining:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_risk_block_count = f"risk_block_count:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_scale_count = f"scale_count:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_loss_streak = f"loss_streak:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_cum_pnl = f"cum_pnl:{selected_venue}:{symbol}:{cfg['strategy_id']}"
                    k_peak_pnl = f"peak_pnl:{selected_venue}:{symbol}:{cfg['strategy_id']}"

                    try:
                        prices = json.loads(sdb.get(k_prices) or "[]")
                        if not isinstance(prices, list):
                            prices = []
                        prices = [float(x) for x in prices if isinstance(x, (int, float)) and math.isfinite(float(x))]
                        prices_loaded = True
                    except Exception:
                        prices = []

                    warmed = (sdb.get(k_warm) or "") == "1"
                    last_action = str(sdb.get(k_last_action) or "hold").strip().lower()
                    if last_action not in ("buy", "sell", "hold"):
                        last_action = "hold"
                    last_emitted_action = str(sdb.get(k_last_emitted_action) or "hold").strip().lower()
                    if last_emitted_action not in ("buy", "sell", "hold"):
                        last_emitted_action = "hold"

                    turn_state_ready = True

                    sym_cfg = dict(cfg)
                    sym_cfg["symbol"] = symbol
                    if slot_decision is not None:
                        # Cash sizing remains a single-coin account contract.
                        sym_cfg["symbols"] = [symbol]
                    sym_cfg["venue"] = selected_venue
                    evidence_extra: dict[str, object] = {}

                    accounting_report = exit_accounting.refresh(
                        venue=selected_venue, symbol=symbol, strategy=str(cfg["strategy_id"]),
                        limits=performance_limits,
                    )
                    if accounting_report["unsettled"]:
                        _LOG.warning("paper_exit_accounting_unsettled symbol=%s error_type=%s", symbol,
                                     accounting_report.get("error_type", "pending_evidence"))

                    if service_pending_paper_exits(qdb, pdb, symbol=symbol):
                        if record is not None:
                            record.update(pipeline_stage="pending_exit", reason="pending_paper_exit")
                        pending_exit_serviced = True
                        write_run_status({"ok": True, "status": "running", "ts": _now(),
                                       "note": "pending_paper_exit", "symbol": symbol,
                                       "venue": selected_venue, "loops": loops})
                        time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                        continue

                    timeframe = _public_ohlcv_timeframe(sym_cfg)
                    if record is not None:
                        record["pipeline_stage"] = "market_input"
                        record["timeframe"] = timeframe or "synthetic_ticks_1s"
                    _LOG.debug(
                        "signal_branch strategy=%s signal_source=%s using=%s",
                        sym_cfg.get("name"), sym_cfg.get("signal_source"),
                        f"public_ohlcv:{timeframe}" if timeframe else "tick_based",
                    )
                    rotation_requested = slot_decision is not None and symbol in slot_decision["rotation_symbols"]
                    if rotation_requested:
                        # Rotation is a portfolio instruction, not a strategy
                        # signal; don't wait for candle warm-up or a new cross.
                        from services.market_data.paper_snapshot_quote import read_paper_quote
                        quote, reason = read_paper_quote(selected_venue, symbol, clock=_now)
                        if quote is not None and normalize_symbol(quote["symbol_mapped"]) != normalize_symbol(symbol):
                            quote, reason = None, "wrong_mapped_market"
                        if quote is None:
                            write_run_status({"ok": False, "status": "running", "ts": _now(),
                                              "note": "rotation_quote_unavailable", "symbol": symbol,
                                              "quote_reason": reason})
                            time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                            continue
                        m = quote["bid"] + (quote["ask"] - quote["bid"]) / 2
                        ts_ms, bars = quote["ts_ms"], 0
                        fresh_market = (m, ts_ms, bars)
                        evidence_extra = {"market_data_source": "public_ticker", "rotation_quote": quote}
                        signal = {"ok": True, "action": "hold", "reason": "rotation"}
                    elif timeframe:
                        if fetch_health is not None and selected_venue == "coinbase" and timeframe == "1h":
                            before_attempt = fetch_health.attempt_seq
                            ohlcv, ohlcv_source = _fetch_public_ohlcv(sym_cfg, clients=public_clients, health=fetch_health)
                            if fetch_health.attempt_seq > before_attempt:
                                observed_attempt = fetch_health.attempt_seq
                        else:
                            ohlcv, ohlcv_source = _fetch_public_ohlcv(sym_cfg, clients=public_clients)
                        ohlcv = ohlcv or []
                        if record is not None:
                            record["ohlcv"] = ohlcv[-int(cfg["min_bars"]):]
                            record["reason"] = "no_public_ohlcv" if not ohlcv else "warming"
                            record["candle_quality"] = assess_hourly_candles(ohlcv, now=_now(), timeframe=timeframe)
                            if isinstance(ohlcv_source, dict):
                                record["observed_ohlcv_source"] = ohlcv_source.get("source")
                        if not ohlcv:
                            write_run_status({"ok": True, "status": "running", "pid": os.getpid(), "ts": _now(), "note": "no_public_ohlcv", "loops": loops, "enqueued": enqueued})
                            _LOG.warning(
                                "ohlcv_fetch_empty strategy=%s symbol=%s timeframe=%s "
                                "— signal evidence will not be written this loop. "
                                "Check exchange connectivity.",
                                sym_cfg.get("name"), sym_cfg.get("symbol"), timeframe,
                            )
                            time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                            continue
                        prices = [float(row[4]) for row in ohlcv[-int(cfg["max_bars"]):]]
                        fresh_market = (
                            float(ohlcv[-1][4]),
                            int(ohlcv[-1][0] or (time.time() * 1000)),
                            len(ohlcv),
                        )
                        if persist_prices and (len(symbols) == 1 or prices_loaded):
                            sdb.set(k_prices, json.dumps(prices))

                        if len(ohlcv) < int(cfg["min_bars"]):
                            write_run_status(
                                {
                                    "ok": True,
                                    "status": "running",
                                    "pid": os.getpid(),
                                    "ts": _now(),
                                    "mid": float(ohlcv[-1][4]),
                                    "bars": len(ohlcv),
                                    "note": "warming",
                                    "enqueued": enqueued,
                                    "strategy_id": selected_strategy if 'selected_strategy' in locals() else cfg["strategy_id"],
                                    "strategy_source": cfg["signal_source"],
                                }
                            )
                            time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                            continue
                        ts_ms = int(ohlcv[-1][0] or (time.time() * 1000))
                        m = float(ohlcv[-1][4])
                        selection = select_strategy(
                            default_strategy=str(cfg.get("strategy_id") or "ema_cross"),
                            ohlcv=ohlcv[-int(cfg["min_bars"]):],
                        )
                        # Authority boundary: selector output is advisory, not an
                        # executable fallback. Missing names already default in
                        # _cfg(); empty here means explicitly invalid identity.
                        selected_strategy = str(cfg.get("strategy_id") or "")
                        try:
                            raw_cfg = load_user_yaml(strict=True)
                        except ConfigLoadError as exc:
                            if record is not None:
                                record.update(pipeline_stage="configuration", reason="config_load_failed")
                            _write_config_load_failed_status(
                                exc,
                                status="running",
                                loops=loops,
                                enqueued=enqueued,
                                cfg=cfg,
                                venue=selected_venue,
                                symbol=symbol,
                            )
                            time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                            continue
                        raw_runner = raw_cfg.get("strategy_runner") if isinstance(raw_cfg.get("strategy_runner"), dict) else {}
                        # Apply the same ownership rules as startup configuration.
                        raw_strategy, _ = _strategy_block_from_runner_cfg(raw_runner)

                        selected_block = _signal_strategy_block_from_selected_name(selected_strategy, raw_strategy)
                        if record is not None:
                            record["settings"]["strategy"] = dict(selected_block)
                            record["pipeline_stage"] = "signal"
                        identity_strategy = selected_block
                        evidence_extra = _public_ohlcv_evidence_extra(sym_cfg, timeframe, ohlcv_source)
                        if bool(evidence_extra.get("ohlcv_source_mismatch")):
                            if record is not None:
                                record.update(pipeline_stage="provenance", reason="sample_mode_provenance_mismatch")
                            mismatch_note = (
                                f"env_sample_mode={evidence_extra.get('ohlcv_sample_mode_env')} "
                                f"actual_source={evidence_extra.get('market_data_source')}"
                            )
                            _LOG.error(
                                "sample_mode_provenance_mismatch strategy=%s symbol=%s %s — holding signal fail-closed",
                                sym_cfg.get("name"), sym_cfg.get("symbol"), mismatch_note,
                            )
                            write_run_status({
                                "ok": True,
                                "status": "running",
                                "pid": os.getpid(),
                                "ts": _now(),
                                "note": "sample_mode_provenance_mismatch",
                                "detail": mismatch_note,
                                "loops": loops,
                                "enqueued": enqueued,
                            })
                            time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                            continue
                        evidence_extra.update(_market_quality_evidence_extra(selected_venue, symbol))
                        selected_block["evidence_extra"] = evidence_extra
                        if record is not None:
                            record["pipeline_stage"] = "signal"
                        signal = _registry_signal_with_context(
                            **({"observer": record["raw_signal"].update} if record is not None else {}),
                            cfg=cfg,
                            strategy_block=selected_block,
                            symbol=symbol,
                            venue=selected_venue,
                            ohlcv=ohlcv[-int(cfg["min_bars"]):],
                        )
                        if record is not None:
                            record["signal_computed"] = True
                            record["signal"] = dict(signal)
                        bars = len(ohlcv)
                    else:
                        tick = _fetch_mid(sym_cfg)
                        if not tick:
                            if record is not None:
                                record["reason"] = _no_fresh_tick_note()
                            write_run_status(
                                {
                                    "ok": True,
                                    "status": "running",
                                    "pid": os.getpid(),
                                    "ts": _now(),
                                    "note": _no_fresh_tick_note(),
                                    "loops": loops,
                                    "enqueued": enqueued,
                                }
                            )
                            time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                            continue
                        m, ts_ms = tick
                        prices.append(float(m))
                        if len(prices) > int(cfg["max_bars"]):
                            prices = prices[-int(cfg["max_bars"]):]
                        fresh_market = (float(m), ts_ms, len(prices))
                        if record is not None:
                            record["ohlcv"] = _synth_ohlcv(prices, ts_ms=ts_ms)
                            record["reason"] = "warming"
                        if persist_prices and (len(symbols) == 1 or prices_loaded):
                            sdb.set(k_prices, json.dumps(prices))
                        if len(prices) < int(cfg["min_bars"]):
                            write_run_status(
                                {
                                    "ok": True,
                                    "status": "running",
                                    "pid": os.getpid(),
                                    "ts": _now(),
                                    "mid": m,
                                    "bars": len(prices),
                                    "note": "warming",
                                    "enqueued": enqueued,
                                    "strategy_id": cfg["strategy_id"],
                                    "strategy_source": cfg["signal_source"],
                                }
                            )
                            time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
                            continue
                        if record is not None:
                            record["pipeline_stage"] = "signal"
                        signal = _strategy_signal(sym_cfg, prices, ts_ms=ts_ms,
                                                  **({"observer": record["raw_signal"].update,
                                                      "input_observer": lambda rows: record.update(ohlcv=rows)}
                                                     if record is not None else {}))
                        if record is not None:
                            record["signal_computed"] = True
                            record["signal"] = dict(signal)
                        bars = len(prices)
                if pending_exit_serviced:
                    continue
                # Only this turn's market input can authorize price-based evaluation.
                if fresh_market is None:
                    m, ts_ms, bars = None, None, 0
                    continue
                m, ts_ms, bars = fresh_market
                context_quote_id = None
                if context_capture is not None:
                    context_quote_id = capture_call(context_capture, "quote", selected_venue, symbol, evidence_extra)
                pos = pdb.get_position(symbol) or {"qty": 0.0, "avg_price": 0.0}
                decision = _position_aware_signal_action(
                    signal, strategy_id=str(cfg["strategy_id"]),
                    position_qty=float(pos.get("qty") or 0.0),
                )
                changed = False
                note = None
                transition_inputs = dict(strategy_id=cfg["strategy_id"], decision=decision,
                                         pos_qty=float(pos.get("qty") or 0.0), warmed=warmed,
                                         last_action=last_action, allow_first_signal_trade=cfg["allow_first_signal_trade"])
                transition = signal_transition(**transition_inputs)
                changed, note = transition["changed"], transition["note"]
                if warmed and transition["write_last_action"]:
                    # Preserve the existing checkpoint value if the following write fails.
                    last_action = decision
                if transition["write_last_action"]:
                    sdb.set(k_last_action, decision)
                if transition["write_warm"]:
                    sdb.set(k_warm, "1")
                warmed, last_action = transition["warmed"], transition["last_action"]
                if record is not None:
                    record.update(signal=dict(signal), transition_inputs=transition_inputs,
                                  decision={"transition": transition}, pipeline_stage="exit_state")
                action = None
                scale_count = int(str(sdb.get(k_scale_count) or "0").strip() or 0)

                all_positions = []
                try:
                    if hasattr(pdb, "list_positions"):
                        all_positions = list(pdb.list_positions() or [])
                    elif hasattr(pdb, "get_all_positions"):
                        all_positions = list(pdb.get_all_positions() or [])
                    elif hasattr(pdb, "positions"):
                        all_positions = list(pdb.positions() or [])
                except Exception:
                    all_positions = []

                all_positions, all_intents = collect_runtime_rows(
                    paper_db=pdb,
                    intent_db=qdb,
                )

                exposure = summarize_exposure(
                    positions=all_positions,
                    strategy_name=str(cfg.get("strategy_id") or ""),
                )

                multi_symbol_validation = validate_multi_symbol_state(
                    positions=all_positions,
                    intents=all_intents,
                    max_open_intents_per_symbol=int(risk_limits.get("max_open_intents_per_symbol", 1)),
                )
                pos_qty = float(pos.get("qty") or 0.0)

                # Track entry/hold state for strategy-aware exit controls.
                entry_price = float(sdb.get(k_entry_price) or 0.0)
                trailing_peak_price = float(sdb.get(k_trailing_peak) or 0.0)
                bars_held = int(sdb.get(k_bars_held) or 0)
                last_held_bar_ts = int(sdb.get(k_last_held_bar_ts) or 0)

                if pos_qty <= 0.0:
                    # No open position: clear runner-side exit state.
                    for k in (k_entry_price, k_trailing_peak, k_bars_held, k_last_held_bar_ts):
                        try:
                            sdb.delete(k)
                        except Exception:
                            pass
                    entry_price = 0.0
                    trailing_peak_price = 0.0
                    bars_held = 0
                    last_held_bar_ts = 0
                else:
                    # Seed entry state from live paper position if missing.
                    if entry_price <= 0.0:
                        avg_price = float(pos.get("avg_price") or 0.0)
                        if avg_price > 0.0:
                            entry_price = avg_price
                            sdb.set(k_entry_price, str(entry_price))
                    # Public OHLCV repeats the latest candle between closes; count its
                    # timestamp once instead of treating every poll loop as a held bar.
                    bars_held, last_held_bar_ts, bar_advanced = _advance_held_bar_counter(
                        bars_held=bars_held,
                        last_bar_ts=last_held_bar_ts,
                        current_bar_ts=int(ts_ms or 0),
                    )
                    sdb.set(k_last_held_bar_ts, str(last_held_bar_ts))
                    if bar_advanced:
                        sdb.set(k_bars_held, str(bars_held))

                    cur_px = float(m)
                    if cur_px > 0.0:
                        trailing_peak_price = max(float(trailing_peak_price or 0.0), cur_px)
                        sdb.set(k_trailing_peak, str(trailing_peak_price))

                exit_inputs = dict(cfg=cfg, signal=signal, decision=decision, changed=changed,
                                   pos_qty=pos_qty, entry_price=entry_price,
                                   trailing_peak_price=trailing_peak_price, bars_held=bars_held,
                                   current_price=float(m))
                exit_selection = select_exit_decision(**exit_inputs, exit_evaluator=evaluate_strategy_exit_stack)
                action, changed = exit_selection["action"], exit_selection["changed"]
                exit_action, exit_reason = exit_selection["exit_action"], exit_selection["exit_reason"]
                exit_out = exit_selection["exit_out"]
                if rotation_requested and pos_qty > 0:
                    action, changed, exit_action, exit_reason = "sell", True, True, "rotation"
                    exit_out = {"stack_rule": "group_b_rotation"}
                if exit_action:
                    note = exit_reason
                if record is not None:
                    record.update(kind="decision", pipeline_stage="gates", reason=None,
                                  exit_inputs=exit_inputs)
                    try:
                        record["decision"]["exit"] = select_exit_decision(
                            **exit_inputs, observe=True, raw_signal=record["raw_signal"],
                            exit_evaluator=evaluate_strategy_exit_stack)
                    except Exception as capture_exc:
                        record["decision"]["exit"] = exit_selection
                        record["observation_error"] = type(capture_exc).__name__
                    record["actual"] = {"intended_action": action, "outcome": "no_intent", "gates": {}}
                kill_remaining = _kill_remaining_loops(
                    sdb, k_kill_remaining, k_kill_until,
                    max_cooldown_loops=max(
                        int(kill_limits.get("kill_cooldown_loops", 0) or 0),
                        int(performance_limits.get("performance_kill_cooldown_loops", 0) or 0),
                    ),
                )
                kill_gate = should_block_symbol(loops=0, kill_until_loop=kill_remaining)
                if record is not None:
                    record["actual"]["gates"]["kill"] = dict(kill_gate)
                cooldown_exit_qty = None
                if not bool(kill_gate.get("ok")):
                    sdb.set(k_kill_remaining, str(kill_remaining - 1))
                    cooldown_exit_qty = _cooldown_exit_quantity(cfg, pos.get("qty"))
                    protective_exit = (
                        action == "sell" and pos_qty > 0.0
                        and cooldown_exit_qty is not None
                        and (rotation_requested or action != last_emitted_action)
                        and _open_strategy_intent_state(qdb, symbol) == "none"
                    )
                    if record is not None:
                        record["actual"]["gates"]["cooldown_protective_exit"] = protective_exit
                    if not protective_exit:
                        if record is not None:
                            record["actual"]["outcome"] = "kill_cooldown"
                        write_run_status(
                            {
                                "ok": True,
                                "status": "running",
                                "pid": os.getpid(),
                                "ts": _now(),
                                "venue": selected_venue,
                                "symbol": symbol,
                                "symbols": symbols,
                                "strategy_id": cfg.get("strategy_id"),
                                "note": "kill_cooldown",
                                "kill_reason": kill_gate.get("reason"),
                                "kill_remaining_loops": kill_gate.get("remaining_loops"),
                            }
                        )
                        continue

                if action and action == last_emitted_action and not rotation_requested:
                    if record is not None:
                        record["actual"]["outcome"] = "emission_latch"
                    action = None
                if action == "buy" and accounting_report["unsettled"]:
                    if record is not None:
                        record["actual"]["outcome"] = "exit_accounting_unsettled"
                    write_run_status({"ok": True, "status": "running", "ts": _now(),
                                   "symbol": symbol, "venue": selected_venue,
                                   "note": "exit_accounting_unsettled", "loops": loops})
                    continue
                if action and slot_decision is not None:
                    # Recheck ownership/current week after market/signal work;
                    # snapshots from the start of a turn are not reservations.
                    check = resolve_slot(cfg=cfg, sdb=sdb, qdb=qdb, pdb=pdb,
                                         accounting=exit_accounting, limits=performance_limits, now=_now())
                    if ((action == "buy" and (not check["allow_buy"] or check["symbols"] != [symbol]))
                            or (rotation_requested and symbol not in check["rotation_symbols"])):
                        write_run_status({"ok": False, "status": "running", "ts": _now(),
                                          "symbol": symbol, "note": "group_b_entry_or_rotation_wait",
                                          "group_b": check})
                        continue
                    slot_decision = check
                if action:
                    intent_id = str(uuid.uuid4())
                    exit_event = None
                    entry_sizing = None
                    intent_created_ts = _now()
                    qty = cooldown_exit_qty if cooldown_exit_qty is not None else float(cfg["qty"])
                    if action == "sell" and bool(cfg["sell_full_position"]) and pos_qty > 0.0:
                        qty = pos_qty

                    # Keep exit-state in sync with newly emitted intents.
                    if action == "buy":
                        position_summary = summarize_position_for_scaling(pos, float(m))
                        scale_check = evaluate_scale_in(
                            position_summary=position_summary,
                            adds_used=scale_count,
                            limits=scaling_limits,
                        )
                        if record is not None:
                            record["actual"]["gates"]["scaling"] = dict(scale_check)
                        if bool(scale_check.get("is_scale")) and not bool(scale_check.get("ok")):
                            if record is not None:
                                record["actual"].update(outcome="scale_blocked_entry")
                                record["actual"]["gates"]["scaling"] = dict(scale_check)
                            write_run_status(
                                {
                                    "ok": True,
                                    "status": "running",
                                    "pid": os.getpid(),
                                    "ts": _now(),
                                    "venue": selected_venue,
                                    "symbol": symbol,
                                    "symbols": symbols,
                                    "strategy_id": cfg.get("strategy_id"),
                                    "signal_action": action,
                                    "signal_reason": signal.get("reason") if isinstance(signal, dict) else None,
                                    "scale_reason": scale_check.get("reason"),
                                    "scale_count": scale_count,
                                    "position_summary": position_summary,
                                    "note": "scale_blocked_entry",
                                }
                            )
                            continue

                        risk_check = evaluate_entry(
                            symbol=symbol,
                            strategy_name=str(cfg.get("strategy_id") or ""),
                            limits=risk_limits,
                            exposure=exposure,
                            open_intents_for_symbol=0,
                        )
                        if record is not None:
                            record["actual"]["gates"]["risk"] = dict(risk_check)
                        if not bool(risk_check.get("ok")):
                            if record is not None:
                                record["actual"].update(outcome="risk_blocked_entry")
                                record["actual"]["gates"]["risk"] = dict(risk_check)
                            risk_block_count = int(str(sdb.get(k_risk_block_count) or "0").strip() or 0) + 1
                            sdb.set(k_risk_block_count, str(risk_block_count))

                            kill_eval = evaluate_risk_block_kill(
                                loops=loops,
                                consecutive_risk_blocks=risk_block_count,
                                limits=kill_limits,
                            )
                            if bool(kill_eval.get("triggered")):
                                sdb.set(k_kill_remaining, str(max(0, int(kill_eval.get("kill_until_loop", 0)) - loops - 1)))
                                write_run_status(
                                    {
                                        "ok": True,
                                        "status": "running",
                                        "pid": os.getpid(),
                                        "ts": _now(),
                                        "venue": selected_venue,
                                        "symbol": symbol,
                                        "symbols": symbols,
                                        "strategy_id": cfg.get("strategy_id"),
                                        "signal_action": action,
                                        "signal_reason": signal.get("reason") if isinstance(signal, dict) else None,
                                        "risk_reason": risk_check.get("reason"),
                                        "risk_exposure": exposure,
                                        "paper_validation": multi_symbol_validation,
                                        "risk_block_count": risk_block_count,
                                        "kill_reason": kill_eval.get("reason"),
                                        "kill_until_loop": kill_eval.get("kill_until_loop"),
                                        "note": "kill_triggered_risk_blocks",
                                    }
                                )
                            else:
                                write_run_status(
                                    {
                                        "ok": True,
                                        "status": "running",
                                        "pid": os.getpid(),
                                        "ts": _now(),
                                        "venue": selected_venue,
                                        "symbol": symbol,
                                        "symbols": symbols,
                                        "strategy_id": cfg.get("strategy_id"),
                                        "signal_action": action,
                                        "signal_reason": signal.get("reason") if isinstance(signal, dict) else None,
                                        "risk_reason": risk_check.get("reason"),
                                        "risk_exposure": exposure,
                                        "paper_validation": multi_symbol_validation,
                                        "risk_block_count": risk_block_count,
                                        "note": "risk_blocked_entry",
                                    }
                                )
                            continue

                        if "paper_entry_sizing" in cfg:
                            from services.execution.paper_cash_entry import size_paper_entry
                            sized = size_paper_entry(cfg=sym_cfg, qdb=qdb, pdb=pdb,
                                                     venue=selected_venue, symbol=symbol, now=intent_created_ts)
                            if not sized["ok"]:
                                if record is not None:
                                    record["actual"].update(outcome="paper_entry_sizing_refused", sizing=sized)
                                write_run_status({"ok": True, "status": "running", "ts": _now(),
                                                  "venue": selected_venue, "symbol": symbol,
                                                  "note": "paper_entry_sizing_refused", "sizing_reason": sized["reason"]})
                                continue
                            qty, entry_sizing = sized["qty"], sized["evidence"]

                        sdb.set(k_risk_block_count, "0")
                        sdb.set(k_kill_until, "0")
                        sdb.set(k_kill_remaining, "0")
                        if bool(position_summary.get("has_position")):
                            sdb.set(k_scale_count, str(scale_count + 1))
                        sdb.set(k_entry_price, str(float(m)))
                        sdb.set(k_trailing_peak, str(float(m)))
                        sdb.set(k_bars_held, "0")
                        sdb.set(k_last_held_bar_ts, str(int(ts_ms or 0)))
                    elif action == "sell":
                        entry_price_val = float(str(sdb.get(k_entry_price) or "0").strip() or 0.0)
                        exit_event = make_event(
                            scope=scope_for(selected_venue, symbol, str(cfg["strategy_id"])),
                            entry_price=entry_price_val, current_price=float(m), created_ts=intent_created_ts,
                        )
                        # Preserve the existing stop-reset basis and point. This
                        # repair changes accounting, not the unresolved stop policy.
                        for k in (k_entry_price, k_trailing_peak, k_bars_held, k_last_held_bar_ts):
                            try:
                                sdb.delete(k)
                            except Exception:
                                pass

                    open_strategy_intent_exists = False
                    try:
                        if slot_decision is not None:
                            # No capped/fail-open duplicate fence for slot rotation.
                            open_strategy_intent_exists = bool(qdb.slot_open_intents() or qdb.list_paper_exits())
                        for row in qdb.list_intents(limit=200):
                            if (
                                row.get("source") == "strategy"
                                and row.get("symbol") == symbol
                                and row.get("status") in ("queued", "submitted")
                            ):
                                open_strategy_intent_exists = True
                                break
                    except Exception:
                        if record is not None:
                            record["actual"]["gates"]["open_intent_lookup"] = "unknown_existing_fail_open"
                        open_strategy_intent_exists = slot_decision is not None

                    if record is not None and "open_intent_lookup" not in record["actual"]["gates"]:
                        record["actual"]["gates"]["open_intent_lookup"] = "open" if open_strategy_intent_exists else "none"

                    if open_strategy_intent_exists:
                        if record is not None:
                            record["actual"]["outcome"] = "open_strategy_intent_exists"
                        write_run_status({
                            "ok": True,
                            "status": "running",
                            "pid": os.getpid(),
                            "ts": _now(),
                            "loops": loops,
                            "enqueued_total": enqueued,
                            "mid": m if 'm' in locals() else None,
                            "venue": selected_venue,
                            "symbol": symbol,
                            "symbols": symbols,
                            "strategy_id": cfg.get("strategy_id"),
                            "selected_strategy": selected_strategy if 'selected_strategy' in locals() else cfg.get("strategy_id"),
                            "selected_strategy_reason": selection.get("selected_strategy_reason") if 'selection' in locals() and isinstance(selection, dict) else None,
                            "regime": selection.get("regime") if 'selection' in locals() and isinstance(selection, dict) else None,
                            "signal_ok": signal.get("ok") if isinstance(signal, dict) else None,
                            "signal_action": action,
                            "signal_reason": signal.get("reason") if isinstance(signal, dict) else None,
                            "signal_changed": bool(changed) if 'changed' in locals() else None,
                            "note": "open_strategy_intent_exists",
                        })
                    else:
                        if record is not None:
                            record["actual"].update(outcome="write_attempted", intent_id=intent_id,
                                                    side=action, qty=float(qty))
                        qdb.upsert_intent({
                            "intent_id": intent_id,
                            "created_ts": intent_created_ts,
                            "ts": _now(),
                            "source": "strategy",
                            "strategy_id": selected_strategy if 'selected_strategy' in locals() else cfg["strategy_id"],
                            "venue": selected_venue,
                            "symbol": symbol,
                            "side": action,
                            "order_type": cfg["order_type"],
                            "qty": float(qty),
                            "limit_price": None,
                            "status": "queued",
                            "last_error": None,
                            "client_order_id": None,
                            "linked_order_id": None,
                            "meta": {
                                **({"group_b_selection": slot_decision} if slot_decision is not None else {}),
                                **({"paper_entry_sizing": entry_sizing} if entry_sizing is not None else {}),
                                **({"exit_event": exit_event} if exit_event is not None else {}),
                                **({"paper_exit_policy": PAPER_EXIT_POLICY,
                                    "paper_exit_id": intent_id} if action == "sell" else {}),
                                "selected_strategy": selected_strategy if 'selected_strategy' in locals() else cfg["strategy_id"],
                                "strategy_preset": cfg.get("strategy_preset"),
                                "selected_strategy_reason": selection.get("selected_strategy_reason") if 'selection' in locals() and isinstance(selection, dict) else None,
                                "regime": selection.get("regime") if 'selection' in locals() and isinstance(selection, dict) else None,
                                "volume_surge": selection.get("volume_surge") if 'selection' in locals() and isinstance(selection, dict) else None,
                                "volume_ratio": selection.get("volume_ratio") if 'selection' in locals() and isinstance(selection, dict) else None,
                                "reference_price": float(m),
                                "reference_price_source": "strategy_runner_signal_price",
                                "signal_reason": signal.get("reason") if isinstance(signal, dict) else None,
                                "strategy_context_ok": signal.get("strategy_context_ok") if isinstance(signal, dict) else None,
                                "strategy_context_reason": signal.get("strategy_context_reason") if isinstance(signal, dict) else None,
                                "strategy_context_source": signal.get("strategy_context_source") if isinstance(signal, dict) else None,
                                "strategy_context_symbol": signal.get("strategy_context_symbol") if isinstance(signal, dict) else None,
                                "strategy_context_venue": signal.get("strategy_context_venue") if isinstance(signal, dict) else None,
                                "strategy_context_capture_ts": signal.get("strategy_context_capture_ts") if isinstance(signal, dict) else None,
                                "strategy_context_snapshot_id": signal.get("strategy_context_snapshot_id") if isinstance(signal, dict) else None,
                                **({"exit_reason": exit_reason} if exit_reason else {}),
                                **(
                                    {"exit_stack_rule": exit_out.get("stack_rule")}
                                    if exit_action and isinstance(exit_out, dict) and exit_out.get("stack_rule")
                                    else {}
                                ),
                                "ranked_candidates": selection.get("ranked_candidates") if 'selection' in locals() and isinstance(selection, dict) else None,
                                "candidate_scores": selection.get("candidate_scores") if 'selection' in locals() and isinstance(selection, dict) else None,
                                **evidence_extra,
                                **_execution_identity_meta(
                                    cfg=cfg, strategy=identity_strategy, venue=selected_venue,
                                    symbol=symbol, provenance=evidence_extra,
                                ),
                            },
                        })
                        if record is not None:
                            record["actual"]["outcome"] = "written"
                        if exit_event is not None:
                            accounting_report = exit_accounting.refresh(
                                venue=selected_venue, symbol=symbol, strategy=str(cfg["strategy_id"]),
                                limits=performance_limits,
                            )
                            for applied in accounting_report["applied"]:
                                if applied["kill"]["triggered"]:
                                    write_run_status({"ok": True, "status": "running", "ts": _now(),
                                        "symbol": symbol, "venue": selected_venue, "loops": loops,
                                        "note": "kill_triggered_performance", "exit_accounting_basis": applied["performance_exit"]["basis"],
                                        "loss_streak": applied["loss_streak"], "performance_state": applied["performance_state"],
                                        "kill_reason": applied["kill"]["reason"]})
                        enqueued += 1
                        if context_capture is not None:
                            capture_call(context_capture, "entry",
                                side=action, intent_id=intent_id, venue=selected_venue,
                                symbol=symbol, strategy=selected_strategy if 'selected_strategy' in locals() else cfg["strategy_id"],
                                qty=float(qty), quote_event_id=context_quote_id,
                            )
                        last_emitted_action = action
                        sdb.set(k_last_emitted_action, last_emitted_action)
                elif not exit_action and decision == "hold" and last_emitted_action != "hold":
                    last_emitted_action = "hold"
                    sdb.set(k_last_emitted_action, last_emitted_action)
                write_run_status({
                    "ok": True,
                    "status": "running",
                    "pid": os.getpid(),
                    "ts": _now(),
                    "loops": loops,
                    "enqueued_total": enqueued,
                    "market_context_capture": capture_call(context_capture, "status") if context_capture is not None else None,
                    "mid": m if 'm' in locals() else None,
                    "ts_ms": ts_ms if 'ts_ms' in locals() else None,
                    "bars": bars if 'bars' in locals() else len(prices),
                    "strategy_id": cfg["strategy_id"] if 'cfg' in locals() else None,
                    "selected_strategy": selected_strategy if 'selected_strategy' in locals() else None,
                    "selected_strategy_reason": selection.get("selected_strategy_reason") if 'selection' in locals() and isinstance(selection, dict) else None,
                    "regime": selection.get("regime") if 'selection' in locals() and isinstance(selection, dict) else None,
                    "volume_surge": selection.get("volume_surge") if 'selection' in locals() and isinstance(selection, dict) else None,
                    "volume_ratio": selection.get("volume_ratio") if 'selection' in locals() and isinstance(selection, dict) else None,
                    "strategy_preset": cfg["strategy_preset"] if 'cfg' in locals() else None,
                    "signal_source": cfg["signal_source"] if 'cfg' in locals() else None,
                    "signal_action": decision if 'decision' in locals() else None,
                    "signal_reason": signal.get("reason") if 'signal' in locals() and isinstance(signal, dict) else None,
                    "strategy_context_ok": signal.get("strategy_context_ok") if 'signal' in locals() and isinstance(signal, dict) else None,
                    "strategy_context_reason": signal.get("strategy_context_reason") if 'signal' in locals() and isinstance(signal, dict) else None,
                    "strategy_context_source": signal.get("strategy_context_source") if 'signal' in locals() and isinstance(signal, dict) else None,
                    "strategy_context_symbol": signal.get("strategy_context_symbol") if 'signal' in locals() and isinstance(signal, dict) else None,
                    "strategy_context_venue": signal.get("strategy_context_venue") if 'signal' in locals() and isinstance(signal, dict) else None,
                    "strategy_context_capture_ts": signal.get("strategy_context_capture_ts") if 'signal' in locals() and isinstance(signal, dict) else None,
                    "strategy_context_snapshot_id": signal.get("strategy_context_snapshot_id") if 'signal' in locals() and isinstance(signal, dict) else None,
                    "symbols": symbols,
                    "symbol": symbol,
                    "signal_ok": bool(signal.get("ok", False)) if 'signal' in locals() and isinstance(signal, dict) else None,
                    "signal_changed": bool(changed) if 'changed' in locals() else None,
                    "signal_indicators": signal.get("ind") if 'signal' in locals() and isinstance(signal, dict) else None,
                    "pos_qty": pos_qty if 'pos_qty' in locals() else None,
                    "entry_price": entry_price if 'entry_price' in locals() else None,
                    "trailing_peak_price": trailing_peak_price if 'trailing_peak_price' in locals() else None,
                    "bars_held": bars_held if 'bars_held' in locals() else None,
                    "last_held_bar_ts": last_held_bar_ts if 'last_held_bar_ts' in locals() else None,
                    "exit_action": exit_action if 'exit_action' in locals() else None,
                    "exit_reason": exit_reason if 'exit_reason' in locals() else None,
                    "exit_stack_rule": exit_out.get("stack_rule") if 'exit_out' in locals() and isinstance(exit_out, dict) else None,
                    "exit_stack_action": exit_out.get("action") if 'exit_out' in locals() and isinstance(exit_out, dict) else None,
                    "action": action if 'action' in locals() else None,
                    "note": note if 'note' in locals() else None,
                })
                time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
            except StartupGuardError:
                if record is not None:
                    record.update(kind="error", reason="startup_guard")
                # Newly selected venues retain the same fail-closed startup gate.
                raise
            except Exception as exc:
                if record is not None:
                    record.update(kind="error", error_type=type(exc).__name__)
                    if record["actual"].get("outcome") == "write_attempted":
                        record["actual"]["outcome"] = "write_failed_or_unknown"
                if len(symbols) == 1:
                    raise
                # A symbol-local failure must not strand other symbols' exits.
                _LOG.warning("symbol_turn_failed symbol=%s error_type=%s", symbol, type(exc).__name__)
                write_run_status({
                    "ok": False, "status": "running", "ts": _now(),
                    "note": "symbol_turn_failed", "symbol": symbol,
                    "error_type": type(exc).__name__, "loops": loops,
                    "enqueued": enqueued,
                })
                time.sleep(max(0.2, float(cfg["loop_interval_sec"])))
            finally:
                if record is not None:
                    try:
                        from services.strategies.signal_input_capture import capture_runner_decision
                        receipt = capture_runner_decision(record, runner_bindings={
                            name: globals()[name] for name in (
                                "run_forever", "_strategy_signal", "_registry_signal_with_context", "_synth_ohlcv",
                                "_position_aware_signal_action", "position_aware_signal_action", "signal_transition",
                                "select_exit_decision", "evaluate_strategy_exit_stack", "compute_signal",
                                "PaperExitAccounting", "make_event", "scope_for", "assess_hourly_candles",
                                "observe_paper_quote",
                            )
                        })
                        recording_counts["written" if receipt.get("ok") else "failed"] += 1
                        if not receipt.get("ok"):
                            _LOG.warning("runner_decision_capture_failed error_type=%s", receipt.get("error_type", "unknown"))
                    except Exception as capture_exc:
                        recording_counts["failed"] += 1
                        _LOG.warning("runner_decision_capture_failed error_type=%s", type(capture_exc).__name__)
                if len(symbols) > 1 and turn_state_ready:
                    # These keys and values all belong to this loaded turn.
                    # Checkpoint even early-continue/error turns, never stale locals.
                    try:
                        if prices_loaded:
                            sdb.set(k_prices, json.dumps(prices))
                        sdb.set(k_last_action, last_action)
                        sdb.set(k_last_emitted_action, last_emitted_action)
                    except Exception as exc:
                        _LOG.warning("symbol_checkpoint_failed symbol=%s error_type=%s",
                                     symbol, type(exc).__name__)

    finally:
        public_clients.close()
        context_capture_status = capture_call(context_capture, "close") if context_capture is not None else {
            "enabled": False, "requested": os.environ.get("CBP_CAPTURE_MARKET_CONTEXT") == "1"
        }
        if len(symbols) == 1:
            try:
                sdb.set(k_prices, json.dumps(prices))
                sdb.set(k_last_action, last_action)
                sdb.set(k_last_emitted_action, last_emitted_action)
            except Exception:
                pass
        _release_lock()
        write_run_status({
            "ok": True,
            "status": "stopped",
            "runner_decision_capture": {"enabled": recording_enabled, **recording_counts},
            "pid": os.getpid(),
            "ts": _now(),
            "loops": loops,
            "market_context_capture": context_capture_status,
            "enqueued_total": enqueued,
            "mid": m if 'm' in locals() else None,
            "ts_ms": ts_ms if 'ts_ms' in locals() else None,
            "bars": bars if 'bars' in locals() else len(prices) if 'prices' in locals() else 0,
            "strategy_id": cfg["strategy_id"] if 'cfg' in locals() else None,
            "strategy_preset": cfg["strategy_preset"] if 'cfg' in locals() else None,
            "signal_source": cfg["signal_source"] if 'cfg' in locals() else None,
            "signal_action": decision if 'decision' in locals() else None,
            "signal_reason": signal.get("reason") if 'signal' in locals() and isinstance(signal, dict) else None,
            "strategy_context_ok": signal.get("strategy_context_ok") if 'signal' in locals() and isinstance(signal, dict) else None,
            "strategy_context_reason": signal.get("strategy_context_reason") if 'signal' in locals() and isinstance(signal, dict) else None,
            "strategy_context_source": signal.get("strategy_context_source") if 'signal' in locals() and isinstance(signal, dict) else None,
            "strategy_context_symbol": signal.get("strategy_context_symbol") if 'signal' in locals() and isinstance(signal, dict) else None,
            "strategy_context_venue": signal.get("strategy_context_venue") if 'signal' in locals() and isinstance(signal, dict) else None,
            "strategy_context_capture_ts": signal.get("strategy_context_capture_ts") if 'signal' in locals() and isinstance(signal, dict) else None,
            "strategy_context_snapshot_id": signal.get("strategy_context_snapshot_id") if 'signal' in locals() and isinstance(signal, dict) else None,
            "signal_ok": bool(signal.get("ok", False)) if 'signal' in locals() and isinstance(signal, dict) else None,
            "signal_changed": bool(changed) if 'changed' in locals() else None,
            "signal_indicators": signal.get("ind") if 'signal' in locals() and isinstance(signal, dict) else None,
            "pos_qty": pos_qty if 'pos_qty' in locals() else None,
            "entry_price": entry_price if 'entry_price' in locals() else None,
            "trailing_peak_price": trailing_peak_price if 'trailing_peak_price' in locals() else None,
            "bars_held": bars_held if 'bars_held' in locals() else None,
            "last_held_bar_ts": last_held_bar_ts if 'last_held_bar_ts' in locals() else None,
            "exit_action": exit_action if 'exit_action' in locals() else None,
            "exit_reason": exit_reason if 'exit_reason' in locals() else None,
            "exit_stack_rule": exit_out.get("stack_rule") if 'exit_out' in locals() and isinstance(exit_out, dict) else None,
            "exit_stack_action": exit_out.get("action") if 'exit_out' in locals() and isinstance(exit_out, dict) else None,
            "action": action if 'action' in locals() else None,
            "note": note if 'note' in locals() else None,
        })


# ---- runtime defaults (override by env set from scripts/bot_ctl.py) ----
DEFAULT_SYMBOL = "BTC/USD"
