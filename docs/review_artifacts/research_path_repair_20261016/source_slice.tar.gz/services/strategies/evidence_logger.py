"""
services/strategies/evidence_logger.py

Evidence logger for es_daily_trend_v1.

Writes structured JSONL logs for every signal, order, fill, session, and drawdown
event. These logs are the primary input to check_promotion_gates.py.

Log schema matches configs/strategies/es_daily_trend_v1.yaml evidence section.

Usage:
    logger = EvidenceLogger("es_daily_trend_v1")
    logger.log_signal(timestamp=..., price=..., sma_200=..., ...)
    logger.log_session(regime_at_open=..., halts_triggered=..., ...)
"""
from __future__ import annotations

import json
import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from services.os.app_paths import data_dir, runtime_dir
from services.os.file_utils import atomic_write
from services.logging.app_logger import get_logger
from services.events.platform_event_journal import append_platform_event

_LOG = get_logger("strategy.evidence_logger")

DEFAULT_EVIDENCE_WRITE_REFUSAL_THRESHOLD = 3


def evidence_writer_status_file() -> Path:
    return runtime_dir() / "health" / "evidence_writer.status.json"


def _evidence_write_refusal_threshold() -> int:
    raw = str(os.environ.get("CBP_EVIDENCE_WRITE_REFUSAL_THRESHOLD") or "").strip()
    try:
        value = int(raw)
    except (TypeError, ValueError):
        return DEFAULT_EVIDENCE_WRITE_REFUSAL_THRESHOLD
    return value if value > 0 else DEFAULT_EVIDENCE_WRITE_REFUSAL_THRESHOLD


def _empty_evidence_writer_status() -> dict[str, Any]:
    return {
        "ok": True,
        "evidence_writer_status": "ok",
        "evidence_write_failures_total": 0,
        "evidence_write_failures_consecutive": 0,
        "last_evidence_write_error_type": "",
        "last_evidence_write_error_ts": "",
        "last_successful_evidence_write_ts": "",
        "evidence_refusal_reason": "",
        "last_record_type": "",
        "last_strategy_id": "",
        "last_path_name": "",
        "threshold": _evidence_write_refusal_threshold(),
        "updated_ts": "",
    }


def load_evidence_writer_status() -> dict[str, Any]:
    path = evidence_writer_status_file()
    status = _empty_evidence_writer_status()
    try:
        if path.exists():
            loaded = json.loads(path.read_text(encoding="utf-8") or "{}")
            if isinstance(loaded, dict):
                status.update(loaded)
    except Exception as exc:
        status.update(
            {
                "ok": False,
                "evidence_writer_status": "degraded",
                "last_evidence_write_error_type": type(exc).__name__,
                "last_evidence_write_error_ts": _now_iso(),
                "evidence_refusal_reason": "evidence writer status unreadable",
                "updated_ts": _now_iso(),
            }
        )
    status["threshold"] = _evidence_write_refusal_threshold()
    return status


def _persist_evidence_writer_status(status: dict[str, Any]) -> None:
    path = evidence_writer_status_file()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(status, sort_keys=True) + "\n", encoding="utf-8")
    except Exception as exc:
        _LOG.error("evidence writer status persist failed err=%s", exc)


def _record_evidence_write_success(strategy_id: str, record_type: str, path: Path) -> None:
    status = load_evidence_writer_status()
    _prev_writer_status = str(status.get("evidence_writer_status") or "ok")
    status.update(
        {
            "ok": True,
            "evidence_writer_status": "ok",
            "evidence_write_failures_consecutive": 0,
            "last_successful_evidence_write_ts": _now_iso(),
            "evidence_refusal_reason": "",
            "last_record_type": record_type,
            "last_strategy_id": strategy_id,
            "last_path_name": path.name,
            "threshold": _evidence_write_refusal_threshold(),
            "updated_ts": _now_iso(),
        }
    )
    _persist_evidence_writer_status(status)
    try:  # notification-only; must never affect the evidence path
        from services.alerts.paper_gate_events import alert_evidence_writer_transition

        alert_evidence_writer_transition(
            _prev_writer_status, "ok", {"strategy_id": strategy_id, "record_type": record_type}
        )
    except Exception:
        pass


def _record_evidence_write_failure(
    strategy_id: str,
    record_type: str,
    path: Path,
    exc: Exception,
) -> None:
    status = load_evidence_writer_status()
    _prev_writer_status = str(status.get("evidence_writer_status") or "ok")
    threshold = _evidence_write_refusal_threshold()
    total = int(status.get("evidence_write_failures_total") or 0) + 1
    consecutive = int(status.get("evidence_write_failures_consecutive") or 0) + 1
    refusing = consecutive >= threshold
    status.update(
        {
            "ok": not refusing,
            "evidence_writer_status": "refusing" if refusing else "degraded",
            "evidence_write_failures_total": total,
            "evidence_write_failures_consecutive": consecutive,
            "last_evidence_write_error_type": type(exc).__name__,
            "last_evidence_write_error_ts": _now_iso(),
            "evidence_refusal_reason": (
                f"{consecutive} consecutive evidence write failures"
                if refusing
                else ""
            ),
            "last_record_type": record_type,
            "last_strategy_id": strategy_id,
            "last_path_name": path.name,
            "threshold": threshold,
            "updated_ts": _now_iso(),
        }
    )
    _persist_evidence_writer_status(status)
    try:  # notification-only; must never affect the evidence path
        from services.alerts.paper_gate_events import alert_evidence_writer_transition

        alert_evidence_writer_transition(
            _prev_writer_status,
            str(status.get("evidence_writer_status") or ""),
            {
                "strategy_id": strategy_id,
                "record_type": record_type,
                "consecutive": status.get("evidence_write_failures_consecutive"),
                "threshold": status.get("threshold"),
                "error_type": status.get("last_evidence_write_error_type"),
            },
        )
    except Exception:
        pass


def _emit_platform_evidence_event(
    *,
    strategy_id: str,
    record_type: str,
    path: Path,
    record: dict[str, Any],
) -> None:
    try:
        append_platform_event(
            event_type="EvidenceArtifactGenerated",
            producer="services.strategies.evidence_logger",
            source="evidence_logger",
            strategy_id=strategy_id,
            strategy_version=str(record.get("_strategy_version") or record.get("strategy_version") or ""),
            config_hash=str(record.get("config_hash") or record.get("_config_hash") or ""),
            dataset_id=str(record.get("dataset_id") or record.get("archive_dataset_id") or ""),
            evidence_artifact_id=f"{strategy_id}:{record_type}:{path.name}",
            run_id=str(record.get("run_id") or record.get("session_id") or ""),
            commit_sha=str(record.get("_commit") or ""),
            payload={
                "record_type": record_type,
                "record_subtype": record.get("record_subtype") or "",
                "path_name": path.name,
                "record_timestamp": record.get("timestamp") or record.get("_logged_at") or "",
                "stage": record.get("_stage") or "",
                "market_data_source": record.get("market_data_source") or "",
                "ohlcv_sample_mode": record.get("ohlcv_sample_mode"),
            },
        )
    except Exception as exc:
        _LOG.warning(
            "platform evidence event append failed strategy_id=%s record_type=%s err=%s",
            strategy_id,
            record_type,
            exc,
        )


def _emit_platform_signal_event(
    *,
    strategy_id: str,
    path: Path,
    record: dict[str, Any],
) -> None:
    try:
        append_platform_event(
            event_type="StrategySignalProduced",
            producer="services.strategies.evidence_logger",
            source="evidence_logger",
            strategy_id=strategy_id,
            strategy_version=str(record.get("_strategy_version") or record.get("strategy_version") or ""),
            config_hash=str(record.get("config_hash") or record.get("_config_hash") or ""),
            dataset_id=str(record.get("dataset_id") or record.get("archive_dataset_id") or ""),
            evidence_artifact_id=f"{strategy_id}:signal:{path.name}",
            run_id=str(record.get("run_id") or record.get("session_id") or ""),
            commit_sha=str(record.get("_commit") or ""),
            payload={
                "timestamp": record.get("timestamp") or "",
                "signal_direction": record.get("signal_direction") or "",
                "kernel_action": record.get("kernel_action") or "",
                "entry_allowed": record.get("entry_allowed"),
                "regime_flag": record.get("regime_flag") or "",
                "price": record.get("price"),
                "sma_200": record.get("sma_200"),
                "atr_ratio": record.get("atr_ratio"),
                "market_data_source": record.get("market_data_source") or "",
                "ohlcv_sample_mode": record.get("ohlcv_sample_mode"),
                "path_name": path.name,
            },
        )
    except Exception as exc:
        _LOG.warning(
            "platform signal event append failed strategy_id=%s err=%s",
            strategy_id,
            exc,
        )


def _trace_enabled() -> bool:
    raw = str(os.environ.get("CBP_DEBUG_CHILD_IO") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _sample_provenance_stamp() -> dict[str, Any]:
    raw = str(os.environ.get("CBP_USE_SAMPLE_OHLCV") or "").strip().lower()
    if raw not in {"1", "true", "yes", "on"}:
        return {}
    return {
        "market_data_source": "sample_ohlcv",
        "ohlcv_sample_mode": True,
        "ohlcv_sample_mode_origin": "env",
    }


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _version_stamp(strategy_id: str, stage: str | None = None) -> dict:
    """Return version identity fields for every evidence record."""
    try:
        from services.control.deployment_stage import get_current_stage
        _stage = stage or get_current_stage(strategy_id).value
    except Exception:
        _stage = stage or "unknown"

    try:
        commit = subprocess.check_output(
            ["git", "rev-parse", "--short", "HEAD"],
            cwd=Path(__file__).parents[2],
            stderr=subprocess.DEVNULL,
        ).decode().strip()
    except Exception:
        commit = "unknown"

    return {
        "_strategy_id": strategy_id,
        "_stage":       _stage,
        "_commit":      commit,
    }


class EvidenceLogger:
    """Writes structured evidence logs for one strategy."""

    def __init__(self, strategy_id: str, log_dir: Path | None = None) -> None:
        self.strategy_id = strategy_id
        self.log_dir = log_dir or (data_dir() / "evidence" / strategy_id)
        self.log_dir.mkdir(parents=True, exist_ok=True)

    def _log_dir_for(self, record_type: str) -> Path:
        return self.log_dir

    def _append(self, record_type: str, record: dict) -> None:
        date = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        path = self.log_dir / f"{record_type}_{date}.jsonl"
        record.setdefault("_logged_at", _now_iso())
        record.setdefault("strategy_id", self.strategy_id)
        for k, v in _sample_provenance_stamp().items():
            record.setdefault(k, v)
        # Stamp with version identity so every record is attributable
        stamp = _version_stamp(self.strategy_id)
        for k, v in stamp.items():
            record.setdefault(k, v)
        try:
            existing = path.read_text(encoding="utf-8") if path.exists() else ""
            atomic_write(path, existing + json.dumps(record) + "\n")
            _record_evidence_write_success(self.strategy_id, record_type, path)
            _emit_platform_evidence_event(
                strategy_id=self.strategy_id,
                record_type=record_type,
                path=path,
                record=record,
            )
            if record_type == "signal":
                _emit_platform_signal_event(
                    strategy_id=self.strategy_id,
                    path=path,
                    record=record,
                )
            if record_type == "signal" and _trace_enabled():
                _LOG.debug("evidence_logger signal write path=%s", path)
        except Exception as e:
            _record_evidence_write_failure(self.strategy_id, record_type, path, e)
            _LOG.error("evidence_logger write failed type=%s err=%s", record_type, e)
            if record_type == "signal" and _trace_enabled():
                _LOG.debug("evidence_logger signal write failed path=%s err=%s", path, e)

    # ------------------------------------------------------------------
    # Signal log — one record per bar evaluated
    # ------------------------------------------------------------------

    def log_signal(
        self,
        *,
        timestamp: str,
        price: float,
        sma_200: float | None,
        atr_ratio: float | None,
        signal_direction: str,       # "long" | "flat"
        regime_flag: str,            # "trending" | "chop" | "high_vol" | "borderline"
        kernel_action: str | None = None,
        entry_allowed: bool | None = None,
        extra: dict | None = None,
    ) -> None:
        record: dict[str, Any] = {
            "record_type":      "signal",
            "timestamp":        timestamp,
            "price":            price,
            "sma_200":          sma_200,
            "atr_ratio":        atr_ratio,
            "signal_direction": signal_direction,
            "regime_flag":      regime_flag,
            "kernel_action":    kernel_action,
            "entry_allowed":    entry_allowed,
        }
        if extra:
            record.update(extra)
        self._append("signal", record)

    # ------------------------------------------------------------------
    # Order log — one record per order sent
    # ------------------------------------------------------------------

    def log_order(
        self,
        *,
        timestamp: str,
        order_type: str,             # "market" | "limit"
        size: float,
        intended_price: float,
        stop_level: float,
        capital_at_risk_usd: float,
        side: str = "buy",
        order_id: str | None = None,
        extra: dict | None = None,
    ) -> None:
        record: dict[str, Any] = {
            "record_type":        "order",
            "timestamp":          timestamp,
            "order_type":         order_type,
            "side":               side,
            "size":               size,
            "intended_price":     intended_price,
            "stop_level":         stop_level,
            "capital_at_risk_usd": capital_at_risk_usd,
            "order_id":           order_id,
        }
        if extra:
            record.update(extra)
        self._append("order", record)

    # ------------------------------------------------------------------
    # Fill log — one record per confirmed fill
    # ------------------------------------------------------------------

    def log_fill(
        self,
        *,
        timestamp: str,
        fill_price: float,
        slippage_points: float,
        slippage_pct: float,
        fees_paid: float,
        side: str = "buy",
        size: float | None = None,
        pnl_usd: float | None = None,
        order_id: str | None = None,
        extra: dict | None = None,
    ) -> None:
        record: dict[str, Any] = {
            "record_type":      "fill",
            "timestamp":        timestamp,
            "side":             side,
            "size":             size,
            "fill_price":       fill_price,
            "slippage_points":  slippage_points,
            "slippage_pct":     slippage_pct,
            "fees_paid":        fees_paid,
            "pnl_usd":          pnl_usd,
            "order_id":         order_id,
        }
        if extra:
            record.update(extra)
        self._append("fill", record)

    # ------------------------------------------------------------------
    # Session log — one record per trading session (daily)
    # ------------------------------------------------------------------

    def log_session(
        self,
        *,
        regime_at_open: str,
        halts_triggered: list[str],
        manual_overrides: list[str],
        reconciliation_result: str,   # "pass" | "mismatch:..."
        drawdown_from_peak: float,
        kill_switch_tested: bool = False,
        recovery_tested: bool = False,
        ops_checks_passed: bool = True,
        infra_halt: bool = False,
        critical_error: bool = False,
        session_start: str | None = None,
        extra: dict | None = None,
    ) -> None:
        record: dict[str, Any] = {
            "record_type":           "session",
            "timestamp":             session_start or _now_iso(),
            "regime_at_open":        regime_at_open,
            "halts_triggered":       halts_triggered,
            "manual_overrides":      manual_overrides,
            "reconciliation_result": reconciliation_result,
            "drawdown_from_peak":    drawdown_from_peak,
            "kill_switch_tested":    kill_switch_tested,
            "recovery_tested":       recovery_tested,
            "ops_checks_passed":     ops_checks_passed,
            "infra_halt":            infra_halt,
            "critical_error":        critical_error,
        }
        if extra:
            record.update(extra)
        self._append("session", record)

    # ------------------------------------------------------------------
    # Drawdown log — one record per drawdown event
    # ------------------------------------------------------------------

    def log_drawdown(
        self,
        *,
        peak_equity: float,
        trough_equity: float,
        duration_days: int,
        action_taken: str,           # "held" | "halved" | "paused"
        recovery_date: str | None = None,
        drawdown_pct: float | None = None,
        extra: dict | None = None,
    ) -> None:
        dd_pct = drawdown_pct
        if dd_pct is None and peak_equity > 0:
            dd_pct = (peak_equity - trough_equity) / peak_equity * 100
        record: dict[str, Any] = {
            "record_type":   "drawdown",
            "timestamp":     _now_iso(),
            "peak_equity":   peak_equity,
            "trough_equity": trough_equity,
            "drawdown_pct":  dd_pct,
            "duration_days": duration_days,
            "action_taken":  action_taken,
            "recovery_date": recovery_date,
        }
        if extra:
            record.update(extra)
        self._append("drawdown", record)
