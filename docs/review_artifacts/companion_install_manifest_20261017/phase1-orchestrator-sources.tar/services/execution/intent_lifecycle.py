from __future__ import annotations

from typing import Any


LIVE_QUEUE_TERMINAL_STATUSES = {"filled", "canceled", "cancelled", "rejected", "error", "expired"}
RECONCILER_LIVE_QUEUE_TARGETS = {"submitted", "filled", "canceled", "rejected", "error"}
RECONCILER_LIVE_QUEUE_SOURCES = {"submitted", "submit_unknown"}
SUBMIT_OWNER_LIVE_QUEUE_TARGETS = {"queued", "submitting", "submitted", "rejected", "submit_unknown", "expired"}
SUBMIT_OWNER_LIVE_QUEUE_SOURCES = {"queued", "submitting"}
LIVE_QUEUE_STATUS_TRANSITIONS = {
    "queued": {"queued", "submitting", "submitted", "rejected", "held", "submit_unknown", "expired"},
    "submitting": {"submitted", "rejected", "submit_unknown", "expired"},
    "submitted": {"submitted", "filled", "canceled", "cancelled", "rejected", "error", "held"},
    "filled": set(),
    "canceled": set(),
    "cancelled": set(),
    "rejected": set(),
    "error": set(),
    "expired": set(),
    "submit_unknown": {"submitted", "rejected", "error"},
    "held": {"queued", "rejected"},
}
EXECUTION_STORE_STATUS_TRANSITIONS = {
    "pending": {"submitted", "canceled", "error"},
    "submitted": {"filled", "canceled", "error", "partially_filled"},
    "partially_filled": {"filled", "canceled", "error"},
    "filled": set(),
    "canceled": set(),
    "error": set(),
}


class IntentLifecycleViolation(Exception):
    pass


def normalize_live_queue_status(status: Any) -> str:
    return str(status or "").strip().lower()


def live_queue_transition_allowed(current_status: Any, next_status: Any) -> bool:
    current = normalize_live_queue_status(current_status)
    nxt = normalize_live_queue_status(next_status)
    if current == nxt:
        return True
    return nxt in LIVE_QUEUE_STATUS_TRANSITIONS.get(current, set())


def normalize_execution_store_status(status: Any) -> str:
    return str(status or "").strip().lower()


def execution_store_transition_allowed(current_status: Any, next_status: Any) -> bool:
    current = normalize_execution_store_status(current_status)
    nxt = normalize_execution_store_status(next_status)
    if current == nxt:
        return True
    return nxt in EXECUTION_STORE_STATUS_TRANSITIONS.get(current, set())


def validate_reconciler_live_queue_transition(
    *,
    current_status: Any,
    next_status: Any,
) -> str:
    current = normalize_live_queue_status(current_status)
    nxt = normalize_live_queue_status(next_status)
    if nxt not in RECONCILER_LIVE_QUEUE_TARGETS:
        raise IntentLifecycleViolation(
            f"blocked live queue transition: unsupported reconciler target {nxt!r}"
        )
    if current in LIVE_QUEUE_TERMINAL_STATUSES:
        raise IntentLifecycleViolation(
            f"blocked live queue transition: terminal status {current!r} is immutable"
        )
    if current == "submit_unknown" and nxt not in {"submitted", "error"}:
        # Deliberate contract: the reconciler may only CONFIRM ambiguous
        # submits (-> submitted) or terminally dispose them (-> error) under
        # the bounded venue-not-found policy in live_reconciler; premature
        # rejection remains blocked.
        raise IntentLifecycleViolation(
            f"blocked live queue transition: invalid submit_unknown target {nxt!r}"
        )
    if current == "submitted" and nxt == "submitted":
        return nxt
    if current == "submitted" and nxt not in {"filled", "canceled", "rejected", "error"}:
        raise IntentLifecycleViolation(
            f"blocked live queue transition: invalid submitted target {nxt!r}"
        )
    if current not in RECONCILER_LIVE_QUEUE_SOURCES:
        raise IntentLifecycleViolation(
            f"blocked live queue transition: invalid source {current!r} for {nxt!r}"
        )
    return nxt


def validate_submit_owner_live_queue_transition(
    *,
    current_status: Any,
    next_status: Any,
) -> str:
    current = normalize_live_queue_status(current_status)
    nxt = normalize_live_queue_status(next_status)
    if nxt not in SUBMIT_OWNER_LIVE_QUEUE_TARGETS:
        raise IntentLifecycleViolation(
            f"blocked live queue transition: unsupported submit-owner target {nxt!r}"
        )
    if current in LIVE_QUEUE_TERMINAL_STATUSES:
        raise IntentLifecycleViolation(
            f"blocked live queue transition: terminal status {current!r} is immutable"
        )
    if current not in SUBMIT_OWNER_LIVE_QUEUE_SOURCES:
        raise IntentLifecycleViolation(
            f"blocked live queue transition: invalid source {current!r} for {nxt!r}"
        )
    return nxt
