from __future__ import annotations
import sqlite3
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, List, Dict, Any
from services.os.app_paths import data_dir

DB_PATH = data_dir() / "paper_trading.sqlite"
FLOAT_CASH_EPSILON = 1e-9

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS paper_state (
  k TEXT PRIMARY KEY,
  v TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS paper_orders (
  order_id TEXT PRIMARY KEY,
  client_order_id TEXT NOT NULL UNIQUE, -- idempotency key
  created_ts TEXT NOT NULL,
  ts TEXT NOT NULL, -- intended timestamp
  venue TEXT NOT NULL,
  symbol TEXT NOT NULL,
  side TEXT NOT NULL,
  order_type TEXT NOT NULL,
  qty REAL NOT NULL,
  limit_price REAL,
  status TEXT NOT NULL,
  reject_reason TEXT,
  strategy_id TEXT,
  meta_json TEXT
);
CREATE INDEX IF NOT EXISTS idx_po_ts ON paper_orders(ts);
CREATE INDEX IF NOT EXISTS idx_po_symbol ON paper_orders(symbol);
CREATE INDEX IF NOT EXISTS idx_po_status ON paper_orders(status);
CREATE TABLE IF NOT EXISTS paper_fills (
  fill_id TEXT PRIMARY KEY,
  order_id TEXT NOT NULL,
  ts TEXT NOT NULL,
  price REAL NOT NULL,
  qty REAL NOT NULL,
  fee REAL NOT NULL,
  fee_currency TEXT NOT NULL,
  FOREIGN KEY(order_id) REFERENCES paper_orders(order_id)
);
CREATE INDEX IF NOT EXISTS idx_pf_order ON paper_fills(order_id);
CREATE INDEX IF NOT EXISTS idx_pf_ts ON paper_fills(ts);
CREATE TABLE IF NOT EXISTS paper_positions (
  symbol TEXT PRIMARY KEY,
  qty REAL NOT NULL,
  avg_price REAL NOT NULL,
  realized_pnl REAL NOT NULL,
  updated_ts TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS paper_equity (
  ts TEXT PRIMARY KEY,
  cash_quote REAL NOT NULL,
  equity_quote REAL NOT NULL,
  unrealized_pnl REAL NOT NULL,
  realized_pnl REAL NOT NULL
);
"""

def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _paper_fill_id(order_id: Any, price: Any, qty: Any) -> str:
    return f"paper:{str(order_id)}:{float(price):.12f}:{float(qty):.12f}"

def _connect() -> sqlite3.Connection:
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, isolation_level=None, check_same_thread=False)
    con.execute("PRAGMA journal_mode=WAL;")
    con.execute("PRAGMA synchronous=NORMAL;")
    for stmt in SCHEMA.strip().split(";"):
        s = stmt.strip()
        if s:
            con.execute(s)

    cols = [r[1] for r in con.execute("PRAGMA table_info(paper_orders)").fetchall()]
    if "strategy_id" not in cols:
        con.execute("ALTER TABLE paper_orders ADD COLUMN strategy_id TEXT")
    if "meta_json" not in cols:
        con.execute("ALTER TABLE paper_orders ADD COLUMN meta_json TEXT")
    return con

class PaperTradingSQLite:
    def __init__(self) -> None:
        _connect().close()

    def get_state(self, k: str) -> Optional[str]:
        con = _connect()
        try:
            r = con.execute("SELECT v FROM paper_state WHERE k=?", (str(k),)).fetchone()
            return r[0] if r else None
        finally:
            con.close()

    def set_state(self, k: str, v: str) -> None:
        con = _connect()
        try:
            con.execute("INSERT OR REPLACE INTO paper_state(k,v) VALUES(?,?)", (str(k), str(v)))
        finally:
            con.close()

    def _get_state_conn(self, con: sqlite3.Connection, k: str) -> Optional[str]:
        r = con.execute("SELECT v FROM paper_state WHERE k=?", (str(k),)).fetchone()
        return r[0] if r else None

    def _set_state_conn(self, con: sqlite3.Connection, k: str, v: str) -> None:
        con.execute("INSERT OR REPLACE INTO paper_state(k,v) VALUES(?,?)", (str(k), str(v)))

    def insert_order(self, row: Dict[str, Any]) -> None:
        con = _connect()
        try:
            con.execute(
                "INSERT OR IGNORE INTO paper_orders(order_id, client_order_id, created_ts, ts, venue, symbol, side, order_type, qty, limit_price, status, reject_reason, strategy_id, meta_json) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    str(row["order_id"]),
                    str(row["client_order_id"]),
                    _now(),
                    str(row["ts"]),
                    str(row["venue"]),
                    str(row["symbol"]),
                    str(row["side"]),
                    str(row["order_type"]),
                    float(row["qty"]),
                    row.get("limit_price"),
                    str(row["status"]),
                    row.get("reject_reason"),
                    row.get("strategy_id"),
                    json.dumps(row.get("meta")) if row.get("meta") is not None else None,
                ),
            )
        finally:
            con.close()

    def get_order_by_client_id(self, client_order_id: str) -> Optional[Dict[str, Any]]:
        con = _connect()
        try:
            r = con.execute(
                "SELECT order_id, client_order_id, created_ts, ts, venue, symbol, side, order_type, qty, limit_price, status, reject_reason, strategy_id, meta_json "
                "FROM paper_orders WHERE client_order_id=?",
                (str(client_order_id),),
            ).fetchone()
            if not r:
                return None
            return {
                "order_id": r[0], "client_order_id": r[1], "created_ts": r[2], "ts": r[3],
                "venue": r[4], "symbol": r[5], "side": r[6], "order_type": r[7],
                "qty": r[8], "limit_price": r[9], "status": r[10], "reject_reason": r[11],
                "strategy_id": r[12], "meta": json.loads(r[13]) if r[13] else None,
            }
        finally:
            con.close()

    def update_order_status(self, order_id: str, status: str, reject_reason: str | None = None) -> None:
        con = _connect()
        try:
            con.execute("UPDATE paper_orders SET status=?, reject_reason=? WHERE order_id=?", (str(status), reject_reason, str(order_id)))
        finally:
            con.close()

    def _update_order_status_conn(self, con: sqlite3.Connection, order_id: str, status: str, reject_reason: str | None = None) -> None:
        con.execute(
            "UPDATE paper_orders SET status=?, reject_reason=? WHERE order_id=?",
            (str(status), reject_reason, str(order_id)),
        )

    def list_orders(self, limit: int = 500, status: str | None = None) -> List[Dict[str, Any]]:
        con = _connect()
        try:
            q = ("SELECT order_id, client_order_id, created_ts, ts, venue, symbol, side, order_type, qty, limit_price, status, reject_reason, strategy_id, meta_json "
                 "FROM paper_orders")
            args = []
            if status:
                q += " WHERE status=?"
                args.append(str(status))
            q += " ORDER BY created_ts DESC LIMIT ?"
            args.append(int(limit))
            rows = con.execute(q, tuple(args)).fetchall()
            return [
                {
                    "order_id": r[0], "client_order_id": r[1], "created_ts": r[2], "ts": r[3],
                    "venue": r[4], "symbol": r[5], "side": r[6], "order_type": r[7],
                    "qty": r[8], "limit_price": r[9], "status": r[10], "reject_reason": r[11],
                    "strategy_id": r[12], "meta": json.loads(r[13]) if r[13] else None,
                }
                for r in rows
            ]
        finally:
            con.close()

    def insert_fill(self, row: Dict[str, Any]) -> None:
        con = _connect()
        try:
            con.execute(
                "INSERT OR IGNORE INTO paper_fills(fill_id, order_id, ts, price, qty, fee, fee_currency) VALUES(?,?,?,?,?,?,?)",
                (str(row["fill_id"]), str(row["order_id"]), str(row["ts"]), float(row["price"]), float(row["qty"]), float(row["fee"]), str(row["fee_currency"])),
            )
        finally:
            con.close()

    def _insert_fill_conn(self, con: sqlite3.Connection, row: Dict[str, Any]) -> int:
        cur = con.execute(
            "INSERT OR IGNORE INTO paper_fills(fill_id, order_id, ts, price, qty, fee, fee_currency) VALUES(?,?,?,?,?,?,?)",
            (
                str(row["fill_id"]),
                str(row["order_id"]),
                str(row["ts"]),
                float(row["price"]),
                float(row["qty"]),
                float(row["fee"]),
                str(row["fee_currency"]),
            ),
        )
        return int(cur.rowcount or 0)

    def list_fills(self, limit: int = 500) -> List[Dict[str, Any]]:
        con = _connect()
        try:
            rows = con.execute(
                "SELECT fill_id, order_id, ts, price, qty, fee, fee_currency FROM paper_fills ORDER BY ts DESC LIMIT ?",
                (int(limit),),
            ).fetchall()
            return [{"fill_id": r[0], "order_id": r[1], "ts": r[2], "price": r[3], "qty": r[4], "fee": r[5], "fee_currency": r[6]} for r in rows]
        finally:
            con.close()

    def upsert_position(self, symbol: str, qty: float, avg_price: float, realized_pnl: float) -> None:
        con = _connect()
        try:
            con.execute(
                "INSERT OR REPLACE INTO paper_positions(symbol, qty, avg_price, realized_pnl, updated_ts) VALUES(?,?,?,?,?)",
                (str(symbol), float(qty), float(avg_price), float(realized_pnl), _now()),
            )
        finally:
            con.close()

    def _upsert_position_conn(self, con: sqlite3.Connection, symbol: str, qty: float, avg_price: float, realized_pnl: float, *, updated_ts: str) -> None:
        con.execute(
            "INSERT OR REPLACE INTO paper_positions(symbol, qty, avg_price, realized_pnl, updated_ts) VALUES(?,?,?,?,?)",
            (str(symbol), float(qty), float(avg_price), float(realized_pnl), str(updated_ts)),
        )

    def get_position(self, symbol: str) -> Optional[Dict[str, Any]]:
        con = _connect()
        try:
            r = con.execute("SELECT symbol, qty, avg_price, realized_pnl, updated_ts FROM paper_positions WHERE symbol=?", (str(symbol),)).fetchone()
            if not r:
                return None
            return {"symbol": r[0], "qty": r[1], "avg_price": r[2], "realized_pnl": r[3], "updated_ts": r[4]}
        finally:
            con.close()

    def _get_position_conn(self, con: sqlite3.Connection, symbol: str) -> Optional[Dict[str, Any]]:
        r = con.execute(
            "SELECT symbol, qty, avg_price, realized_pnl, updated_ts FROM paper_positions WHERE symbol=?",
            (str(symbol),),
        ).fetchone()
        if not r:
            return None
        return {"symbol": r[0], "qty": r[1], "avg_price": r[2], "realized_pnl": r[3], "updated_ts": r[4]}

    def list_positions(self, limit: int = 200) -> List[Dict[str, Any]]:
        con = _connect()
        try:
            rows = con.execute(
                "SELECT symbol, qty, avg_price, realized_pnl, updated_ts FROM paper_positions ORDER BY updated_ts DESC LIMIT ?",
                (int(limit),),
            ).fetchall()
            return [{"symbol": r[0], "qty": r[1], "avg_price": r[2], "realized_pnl": r[3], "updated_ts": r[4]} for r in rows]
        finally:
            con.close()

    def insert_equity(self, ts: str, cash_quote: float, equity_quote: float, unrealized_pnl: float, realized_pnl: float) -> None:
        con = _connect()
        try:
            con.execute(
                "INSERT OR REPLACE INTO paper_equity(ts, cash_quote, equity_quote, unrealized_pnl, realized_pnl) VALUES(?,?,?,?,?)",
                (str(ts), float(cash_quote), float(equity_quote), float(unrealized_pnl), float(realized_pnl)),
            )
        finally:
            con.close()

    def apply_fill(
        self,
        *,
        order: Dict[str, Any],
        ts: str,
        price: float,
        qty: float,
        fee: float,
        fee_currency: str,
        execution_identity_evidence: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        con = _connect()
        try:
            con.execute("BEGIN IMMEDIATE")
            order_row = con.execute(
                "SELECT order_id, symbol, side, status, reject_reason FROM paper_orders WHERE order_id=?",
                (str(order["order_id"]),),
            ).fetchone()
            if not order_row:
                con.execute("ROLLBACK")
                return {"ok": False, "reason": "order_not_found"}

            order_id = str(order_row[0])
            symbol = str(order_row[1])
            side = str(order_row[2]).strip().lower()
            status = str(order_row[3]).strip().lower()
            fill_id = _paper_fill_id(order_id, price, qty)

            if status == "filled":
                con.execute("COMMIT")
                return {"ok": True, "fill_id": fill_id, "fee": float(fee), "idempotent": True}
            if status in {"rejected", "canceled", "cancelled"}:
                con.execute("COMMIT")
                return {"ok": False, "reason": status}

            pos = self._get_position_conn(con, symbol) or {
                "symbol": symbol,
                "qty": 0.0,
                "avg_price": 0.0,
                "realized_pnl": 0.0,
            }
            pos_qty = float(pos["qty"])
            avg = float(pos["avg_price"])
            realized_pos = float(pos["realized_pnl"])
            cash = float(self._get_state_conn(con, "cash_quote") or "0.0")
            realized_total = float(self._get_state_conn(con, "realized_pnl") or "0.0")
            fill_realized_pnl = 0.0

            if side == "buy":
                cost = float(price) * float(qty) + float(fee)
                if cash + FLOAT_CASH_EPSILON < cost:
                    self._update_order_status_conn(con, order_id, "rejected", "insufficient_cash")
                    con.execute("COMMIT")
                    return {"ok": False, "reason": "insufficient_cash"}
                new_qty = pos_qty + float(qty)
                # Store fee-inclusive cost basis so later sell PnL is net of both legs.
                new_avg = ((avg * pos_qty) + (float(price) * float(qty)) + float(fee)) / new_qty if new_qty > 0 else 0.0
                new_cash = cash - cost
                if new_cash < 0.0 and abs(new_cash) <= FLOAT_CASH_EPSILON:
                    new_cash = 0.0
                new_realized_total = realized_total
                new_pos_realized = realized_pos
            else:
                if pos_qty < float(qty):
                    self._update_order_status_conn(con, order_id, "rejected", "insufficient_position")
                    con.execute("COMMIT")
                    return {"ok": False, "reason": "insufficient_position"}
                proceeds = float(price) * float(qty) - float(fee)
                fill_realized_pnl = proceeds - (avg * float(qty))
                new_qty = pos_qty - float(qty)
                new_avg = avg if new_qty > 0 else 0.0
                new_cash = cash + proceeds
                new_realized_total = realized_total + fill_realized_pnl
                new_pos_realized = realized_pos + fill_realized_pnl

            self._upsert_position_conn(
                con,
                symbol,
                new_qty,
                new_avg,
                new_pos_realized,
                updated_ts=str(ts),
            )
            self._set_state_conn(con, "cash_quote", str(float(new_cash)))
            self._set_state_conn(con, "realized_pnl", str(float(new_realized_total)))
            inserted = self._insert_fill_conn(
                con,
                {
                    "fill_id": fill_id,
                    "order_id": order_id,
                    "ts": str(ts),
                    "price": float(price),
                    "qty": float(qty),
                    "fee": float(fee),
                    "fee_currency": str(fee_currency),
                },
            )
            if inserted != 1:
                raise RuntimeError("paper_fill_insert_failed")
            if execution_identity_evidence is not None:
                # Commit fill-time evidence with accounting, never backfill on retry.
                self._set_state_conn(
                    con, "fill_execution_identity:" + fill_id,
                    json.dumps(execution_identity_evidence, sort_keys=True, allow_nan=False),
                )
            self._update_order_status_conn(con, order_id, "filled", None)
            con.execute("COMMIT")
            return {
                "ok": True,
                "fill_id": fill_id,
                "fee": float(fee),
                "realized_pnl_usd": float(fill_realized_pnl),
                "pnl_usd_semantics": "net_of_fees",
                "idempotent": False,
            }
        except Exception:
            try:
                con.execute("ROLLBACK")
            except Exception:
                pass
            raise
        finally:
            con.close()

    def get_fill_execution_identity(self, fill_id: str) -> Optional[Dict[str, Any]]:
        raw = self.get_state("fill_execution_identity:" + str(fill_id))
        if raw is None:
            return None
        try:
            evidence = json.loads(raw)
            if not isinstance(evidence, dict):
                raise ValueError("invalid evidence shape")
            return evidence
        except (TypeError, ValueError):
            return {"execution_identity_fill_status": "invalid_storage"}

   
    def get_order_by_order_id(self, order_id: str) -> Optional[dict]:
        con = _connect()
        try:
            r = con.execute(
                "SELECT order_id, client_order_id, created_ts, ts, venue, symbol, side, order_type, qty, limit_price, status, reject_reason, strategy_id, meta_json "
                "FROM paper_orders WHERE order_id=?",
                (str(order_id),),
            ).fetchone()
            if not r:
                return None
            return {
                "order_id": r[0], "client_order_id": r[1], "created_ts": r[2], "ts": r[3],
                "venue": r[4], "symbol": r[5], "side": r[6], "order_type": r[7],
                "qty": r[8], "limit_price": r[9], "status": r[10], "reject_reason": r[11],
                "strategy_id": r[12], "meta": json.loads(r[13]) if r[13] else None,
            }
        finally:
            con.close()

    def list_fills_for_order(self, order_id: str, limit: int = 2000) -> list[dict]:
        con = _connect()
        try:
            rows = con.execute(
                "SELECT fill_id, order_id, ts, price, qty, fee, fee_currency FROM paper_fills WHERE order_id=? ORDER BY ts ASC LIMIT ?",
                (str(order_id), int(limit)),
            ).fetchall()
            out = []
            for r in rows:
                out.append({"fill_id": r[0], "order_id": r[1], "ts": r[2], "price": r[3], "qty": r[4], "fee": r[5], "fee_currency": r[6]})
            return out
        finally:
            con.close()

    def list_equity(self, limit: int = 2000) -> List[Dict[str, Any]]:
        con = _connect()
        try:
            rows = con.execute(
                "SELECT ts, cash_quote, equity_quote, unrealized_pnl, realized_pnl FROM paper_equity ORDER BY ts DESC LIMIT ?",
                (int(limit),),
            ).fetchall()
            return [{"ts": r[0], "cash_quote": r[1], "equity_quote": r[2], "unrealized_pnl": r[3], "realized_pnl": r[4]} for r in rows]
        finally:
            con.close()
