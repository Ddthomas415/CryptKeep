# Strict-Probe Market Diagnosis, October 26

Role: ENGINEER. Risk: HIGH. READY_FOR_INDEPENDENT_REVIEW, diagnosis only.
Runtime INCOMPLETE. No implementation or additional live operation.

## Actual producer path

Saved-result review V6H-DIAG-01 correctly found the standalone default snapshot
is not used by the strict probe. That counterexample stays preserved, not
promoted to a historical cause or used to widen the verifier whitelist.

Actual path: orchestrator.explain -> get_probe_tool_results -> memory.retrieve_context
-> _compute_market_summary -> _build_evidence_bundle -> verifier. The strict
branch never calls get_market_snapshot/_default_market_snapshot or ordinary
reasoning. Memory still reads market_ticks and attaches its summary, alongside
the frozen document evidence.

SHOWN with real handlers and synthetic in-process HTTP/DB seams:
- No market rows: market ok false/reason no_market_data, market_snapshot empty;
  all five verifier checks pass in the controlled archived-document fixture.
- One positive-price row: market ok true/latest_price/row timestamp and source;
  market_snapshot stays empty; verifier rejects bundle_market.
- One zero-price row: summary still ok true with row provenance; likewise
  rejected. Zero price alone is not no-market evidence.

Each case exercises real strict orchestrator/tools/memory/risk handlers and
bundle/verifier. Exactly two synthetic tool requests (memory POST/risk GET), one
synthetic market query and zero standalone snapshot/default/ordinary calls.
Reused fixtures bypass real Settings readers, SDK/storage constructors and
startup lifespans. All credentials/rows are synthetic. The first harness failed
to stub risk audit: review blocked three non-ASGI audit POST attempts, which
production swallowed. No external request completed in that guarded review;
the original run's exact attempt count was not measured. Its zero-attempt claim
is withdrawn. Preserved version: actual_runtime_v6h/strict_path_harness_v1.tar.

The corrected harness stubs risk audit, asserts both expected synthetic audit
hooks, blocks non-ASGI transport before I/O and counts every forbidden attempt.
A teardown assertion now fails even when production code swallows its error.
This proves reachability with controlled inputs, not actual live row availability,
the precise rejected field or historical causation. Current health is unknown.

## Verification

```sh
env -i PATH=/usr/bin:/bin PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 ./.venv/bin/python -B -m pytest --noconftest -c /dev/null -p no:cacheprovider -q tests/test_companion_v6h_strict_probe_contract.py
```

SHOWN corrected run: 3 passed in 0.78 seconds with zero counted forbidden
attempts, six existing FastAPI deprecation warnings. Prior guarded review passed
3 in 0.71 seconds with three blocked audit attempts; it accepted diagnosis only,
not a wholly in-process/no-attempt harness. That review is preserved as
actual_runtime_v6h/strict_path_independent_review.json.
Diagnosis only, no production change, relaxed criterion, full suite or live replay.

## Proposed Disposition, Not Implemented

Do not fix the unrelated fallback or accept populated prices merely to pass.
Instead make the special archival probe explicitly exclude market evidence,
using a truthful fixed exclusion marker checked narrowly by its verifier.
Preserve ordinary research market retrieval; no system-wide feature removal.
Keep prices absent, identity/protocol guards, archive/witness/citation checks,
all-five-true acceptance and timeouts intact.

Excluded by the archival probe must not be falsely described as no market data
in the database. This is a small producer/consumer contract decision, requiring
offline implementation, empty/populated/ordinary-path tests and independent
review before any new operation. No repair or operational authority here.
