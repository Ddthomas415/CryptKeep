import sqlite3
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace

import pytest

from storage.execution_account_binding import AccountContext, ExecutionAccountBinding


CONTEXT = AccountContext("coinbase", "production", "account-a", "portfolio-a")


def test_binding_persists_and_same_account_rotation_is_independent_of_keys(tmp_path):
    path = tmp_path / "execution.sqlite"
    binding = ExecutionAccountBinding(path)
    assert binding.initialize(CONTEXT)
    assert not ExecutionAccountBinding(path).initialize(CONTEXT)
    ExecutionAccountBinding(path).require(CONTEXT)


@pytest.mark.parametrize("field,value", [("venue","other"),("environment","sandbox"),
    ("account_id","account-b"),("portfolio_id","portfolio-b")])
def test_rebinding_or_wrong_context_refused(tmp_path,field,value):
    binding = ExecutionAccountBinding(tmp_path / "execution.sqlite")
    binding.initialize(CONTEXT)
    wrong = replace(CONTEXT, **{field:value})
    with pytest.raises(ValueError): binding.initialize(wrong)
    with pytest.raises(ValueError): binding.require(wrong)
    binding.require(CONTEXT)


def test_existing_history_not_adopted_or_changed(tmp_path):
    path = tmp_path / "execution.sqlite"
    with sqlite3.connect(path) as con:
        con.execute('CREATE TABLE "unknown history" (value TEXT)')
        con.execute('INSERT INTO "unknown history" VALUES ("old")')
    with pytest.raises(ValueError): ExecutionAccountBinding(path).initialize(CONTEXT)
    with sqlite3.connect(path) as con:
        assert con.execute('SELECT value FROM "unknown history"').fetchall() == [("old",)]
        assert not con.execute("SELECT 1 FROM sqlite_master WHERE name='execution_account_binding'").fetchone()


def test_missing_database_require_does_not_create(tmp_path):
    path = tmp_path / "missing.sqlite"
    with pytest.raises(sqlite3.OperationalError): ExecutionAccountBinding(path).require(CONTEXT)
    assert not path.exists()


def test_direct_mutation_refused(tmp_path):
    path = tmp_path / "execution.sqlite"
    ExecutionAccountBinding(path).initialize(CONTEXT)
    for statement in ("DELETE FROM execution_account_binding", "UPDATE execution_account_binding SET account_id='b'",
        "INSERT OR REPLACE INTO execution_account_binding VALUES(1,'coinbase','production','b','portfolio-a')"):
        with sqlite3.connect(path) as con:
            with pytest.raises(sqlite3.IntegrityError): con.execute(statement)
    ExecutionAccountBinding(path).require(CONTEXT)


def test_concurrent_different_accounts_only_one_binds(tmp_path):
    path = tmp_path / "execution.sqlite"
    def attempt(context):
        try:
            return ExecutionAccountBinding(path).initialize(context)
        except ValueError:
            return False
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(attempt, [CONTEXT, replace(CONTEXT,account_id="b")]))
    assert sorted(results) == [False,True]


@pytest.mark.parametrize("context", [replace(CONTEXT,account_id=""),replace(CONTEXT,portfolio_id=" "),replace(CONTEXT,environment="unknown")])
def test_incomplete_context_refused(tmp_path,context):
    path = tmp_path / "execution.sqlite"
    with pytest.raises(ValueError): ExecutionAccountBinding(path).initialize(context)
    assert not path.exists()
