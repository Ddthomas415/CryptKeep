import sqlite3
from dataclasses import replace

import pytest

from storage.spot_exit_reservations import SpotExitReservations
from services.execution.spot_exit_receipt_probe import capture_terminal_receipt
from tests.test_execution_account_binding import CONTEXT
from tests.test_spot_exit_real_schema import fixture


def test_wrong_account_constructor_leaves_evidence_unchanged(tmp_path):
    path, _, _ = fixture(tmp_path)
    with pytest.raises(ValueError):
        SpotExitReservations(path, account_context=replace(CONTEXT, account_id="other"))
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 1


def test_unbound_database_is_not_adopted(tmp_path):
    path = tmp_path / "unbound.sqlite"
    with sqlite3.connect(path) as con:
        con.execute("CREATE TABLE old_history(value TEXT)")
    with pytest.raises(sqlite3.OperationalError):
        SpotExitReservations(path, account_context=CONTEXT)
    with sqlite3.connect(path) as con:
        assert not con.execute("SELECT 1 FROM sqlite_master WHERE name='spot_exit_evidence'").fetchone()


@pytest.mark.parametrize("operation", ["reconciliation", "reserve", "receipt", "settle", "fetch"])
def test_each_operation_rechecks_binding(tmp_path, operation):
    path, r, _ = fixture(tmp_path)
    r.account_context = replace(CONTEXT, portfolio_id="other")
    class NeverFetch:
        def fetch_order(self, **kwargs):
            raise AssertionError("account mismatch must refuse before transport")
    actions = {
        "reconciliation": lambda: r.record_reconciliation(venue="coinbase",symbol="BTC/USD",evidence_id="r2",exchange_qty=0.8,observed_ms=200,now_ms=200),
        "reserve": lambda: r.reserve(intent_id="exit1",now_ms=110,max_age_ms=20),
        "receipt": lambda: r.record_terminal_receipt(intent_id="exit1",venue="coinbase",symbol="BTC/USD",remote_id="order1",status="canceled",filled_qty=0.2),
        "settle": lambda: r.settle(intent_id="exit1"),
        "fetch": lambda: capture_terminal_receipt(reservations=r,intent_id="exit1",client=NeverFetch()),
    }
    with pytest.raises(ValueError): actions[operation]()
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 1
        assert con.execute("SELECT count(*) FROM spot_exit_settlements").fetchone()[0] == 0


def test_bound_account_cannot_record_another_venue(tmp_path):
    _, r, _ = fixture(tmp_path)
    with pytest.raises(ValueError, match="venue"):
        r.record_reconciliation(venue="other",symbol="BTC/USD",evidence_id="r2",exchange_qty=0.8,observed_ms=200,now_ms=200)


def test_cross_venue_intent_refused_before_transport(tmp_path):
    path, r, _ = fixture(tmp_path)
    with sqlite3.connect(path) as con:
        con.execute("UPDATE intents SET exchange='other'")
        con.execute("UPDATE order_dedupe SET exchange_id='other'")
    class NeverFetch:
        def fetch_order(self, **kwargs):
            raise AssertionError("cross-venue intent must not reach transport")
    with pytest.raises(ValueError, match="venue"):
        capture_terminal_receipt(reservations=r,intent_id="exit1",client=NeverFetch())
