import pytest

from services.execution.coinbase_portfolio_scope import observe_portfolio_scope


PORTFOLIO = "892e8c7c-e979-4cad-b61b-55a197932cf1"


class Session:
    id = "coinbase"

    def __init__(self, response):
        self.response = response
        self.calls = 0

    def v3PrivateGetBrokerageKeyPermissions(self):
        self.calls += 1
        return self.response


def valid(**changes):
    return dict(can_view=True,can_trade=True,portfolio_uuid=PORTFOLIO,
        portfolio_type="DEFAULT",**changes)


def test_scope_uses_endpoint_not_operator_label_or_key():
    session = Session(valid())
    observed = observe_portfolio_scope(session)
    assert observed.portfolio_uuid == PORTFOLIO
    assert observed.portfolio_type == "DEFAULT"
    assert observed.can_trade is True
    assert session.calls == 1


@pytest.mark.parametrize("field,value", [("portfolio_uuid",None),("portfolio_uuid","label"),
    ("portfolio_uuid","00000000-0000-0000-0000-000000000000"),
    ("can_view",False),("can_view",1),("can_trade","true"),
    ("portfolio_type","UNDEFINED"),("portfolio_type","INTX")])
def test_malformed_or_unsupported_scope_rejected(field,value):
    response = valid(); response[field] = value
    with pytest.raises(ValueError): observe_portfolio_scope(Session(response))


def test_read_only_key_does_not_claim_trade_permission():
    response = valid(); response["can_trade"] = False
    assert observe_portfolio_scope(Session(response)).can_trade is False


def test_wrong_venue_never_calls_endpoint():
    session = Session(valid()); session.id = "other"
    with pytest.raises(ValueError): observe_portfolio_scope(session)
    assert session.calls == 0


def test_transport_failure_is_not_scope_evidence():
    class Broken(Session):
        def v3PrivateGetBrokerageKeyPermissions(self):
            raise OSError("offline")
    with pytest.raises(OSError): observe_portfolio_scope(Broken(valid()))
