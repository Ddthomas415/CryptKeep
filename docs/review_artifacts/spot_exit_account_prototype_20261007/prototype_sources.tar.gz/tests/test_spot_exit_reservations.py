import sqlite3
import pytest
from storage.spot_exit_reservations import SpotExitReservations
from storage.execution_account_binding import ExecutionAccountBinding
from tests.test_execution_account_binding import CONTEXT


def setup(tmp_path):
    path = tmp_path / "execution.sqlite"
    ExecutionAccountBinding(path).initialize(CONTEXT)
    with sqlite3.connect(path) as con:
        con.executescript("""
          CREATE TABLE live_positions(venue TEXT,symbol TEXT,qty REAL,updated_ts TEXT);
          INSERT INTO live_positions VALUES('coinbase','BTC/USD',1,'v1');
          CREATE TABLE intents(intent_id TEXT PRIMARY KEY,exchange TEXT,symbol TEXT,side TEXT,qty REAL,mode TEXT,status TEXT);
        """)
    store = SpotExitReservations(path, account_context=CONTEXT)
    store.record_reconciliation(venue="coinbase",symbol="BTC/USD",evidence_id="recon1",exchange_qty=1,observed_ms=100,now_ms=100)
    return path,store


def intent(path, name="a", qty=0.4, side="sell", status="pending"):
    with sqlite3.connect(path) as con:
        con.execute("INSERT INTO intents VALUES(?,?,?,?,?,?,?)", (name,"coinbase","BTC/USD",side,qty,"live",status))


def test_reservation_persists_and_is_idempotent(tmp_path):
    path,s = setup(tmp_path); intent(path)
    assert s.reserve(intent_id="a",now_ms=110,max_age_ms=20) == 0.4
    assert SpotExitReservations(path, account_context=CONTEXT).reserve(intent_id="a",now_ms=110,max_age_ms=20) == 0.4
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 1


@pytest.mark.parametrize("side,qty,status", [("buy",0.4,"pending"),("sell",2,"pending"),("sell",0,"pending"),("sell",-1,"pending"),("sell",0.4,"submitted")])
def test_invalid_request_refused(tmp_path,side,qty,status):
    path,s = setup(tmp_path); intent(path,side=side,qty=qty,status=status)
    with pytest.raises(ValueError): s.reserve(intent_id="a",now_ms=110,max_age_ms=20)


def test_changed_position_refused(tmp_path):
    path,s=setup(tmp_path); intent(path)
    with sqlite3.connect(path) as con: con.execute("UPDATE live_positions SET updated_ts='v2'")
    with pytest.raises(ValueError): s.reserve(intent_id="a",now_ms=110,max_age_ms=20)


def test_stale_evidence_refused(tmp_path):
    path,s=setup(tmp_path); intent(path)
    with pytest.raises(ValueError): s.reserve(intent_id="a",now_ms=121,max_age_ms=20)


def test_unknown_submission_consumes_capacity(tmp_path):
    path,s=setup(tmp_path); intent(path,qty=0.6); intent(path,"other",qty=0.5,status="error")
    with pytest.raises(ValueError): s.reserve(intent_id="a",now_ms=110,max_age_ms=20)


def test_two_connections_do_not_overreserve(tmp_path):
    from concurrent.futures import ThreadPoolExecutor
    path,s=setup(tmp_path); intent(path,"a",0.6); intent(path,"b",0.6)
    def claim(name):
        try: SpotExitReservations(path, account_context=CONTEXT).reserve(intent_id=name,now_ms=110,max_age_ms=20); return True
        except ValueError: return False
    with ThreadPoolExecutor(2) as pool: assert list(pool.map(claim,["a","b"])) == [False,False]
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 0


def test_retry_rechecks_outstanding_capacity(tmp_path):
    path,s=setup(tmp_path); intent(path,"a",0.4)
    s.reserve(intent_id="a",now_ms=110,max_age_ms=20)
    intent(path,"b",0.8)
    with pytest.raises(ValueError): s.reserve(intent_id="a",now_ms=110,max_age_ms=20)


@pytest.mark.parametrize("bad", [float("inf"),float("nan"),True,1.5,"20",-1])
def test_invalid_times_refused(tmp_path,bad):
    path,s=setup(tmp_path); intent(path)
    with pytest.raises(ValueError): s.reserve(intent_id="a",now_ms=110,max_age_ms=bad)
    with pytest.raises(ValueError): s.reserve(intent_id="a",now_ms=bad,max_age_ms=20)
    with pytest.raises(ValueError): s.record_reconciliation(venue="coinbase",symbol="BTC/USD",evidence_id="r2",exchange_qty=1,observed_ms=bad,now_ms=200)


def terminal_setup(tmp_path, *, status="canceled", filled=0):
    from storage.order_dedupe_store_sqlite import OrderDedupeStore
    path,s=setup(tmp_path); intent(path)
    dedupe = OrderDedupeStore(exec_db=str(path))
    dedupe.claim(exchange_id="coinbase",intent_id="a",symbol="BTC/USD",client_order_id="client1")
    dedupe.mark_submitted(exchange_id="coinbase",intent_id="a",remote_order_id="remote1")
    s.reserve(intent_id="a",now_ms=110,max_age_ms=20)
    with sqlite3.connect(path) as con:
        con.executescript("CREATE TABLE fills(intent_id TEXT,qty REAL,trade_id TEXT); CREATE TABLE reconcile_fill_deliveries(intent_id TEXT,venue TEXT,fill_id TEXT,completed INTEGER); CREATE TABLE live_position_fills(venue TEXT,fill_id TEXT,symbol TEXT,side TEXT,qty REAL);")
        con.execute("UPDATE intents SET status=?", (status,))
        con.execute("INSERT INTO spot_exit_terminal_receipts VALUES('a','coinbase','BTC/USD',?,?,'remote1')", (status,filled))
    return path,s


def test_zero_fill_cancellation_releases_once(tmp_path):
    path,s=terminal_setup(tmp_path)
    assert s.settle(intent_id="a")
    assert not SpotExitReservations(path, account_context=CONTEXT).settle(intent_id="a")
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 0
        con.execute("UPDATE intents SET status='pending'")
    with pytest.raises(ValueError): s.reserve(intent_id="a",now_ms=110,max_age_ms=20)


def test_status_without_receipt_keeps_reservation(tmp_path):
    path,s=terminal_setup(tmp_path)
    with sqlite3.connect(path) as con: con.execute("DELETE FROM spot_exit_terminal_receipts")
    with pytest.raises(ValueError): s.settle(intent_id="a")


def test_partial_fill_requires_accounting_before_release(tmp_path):
    path,s=terminal_setup(tmp_path,filled=0.2)
    with sqlite3.connect(path) as con:
        con.execute("INSERT INTO fills VALUES('a',0.2,'f1')")
        con.execute("INSERT INTO reconcile_fill_deliveries VALUES('a','coinbase','f1',0)")
    with pytest.raises(ValueError): s.settle(intent_id="a")
    with sqlite3.connect(path) as con:
        con.execute("UPDATE reconcile_fill_deliveries SET completed=1")
        con.execute("INSERT INTO live_position_fills VALUES('coinbase','f1','BTC/USD','sell',0.2)")
    assert s.settle(intent_id="a")
