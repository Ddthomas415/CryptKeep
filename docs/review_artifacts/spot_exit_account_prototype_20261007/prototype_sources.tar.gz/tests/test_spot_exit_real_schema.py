import sqlite3
import pytest
from storage.execution_store_sqlite import ExecutionStore
from storage.live_position_store_sqlite import LivePositionStore
from storage.spot_exit_reservations import SpotExitReservations
from storage.order_dedupe_store_sqlite import OrderDedupeStore
from storage.execution_account_binding import ExecutionAccountBinding
from tests.test_execution_account_binding import CONTEXT


def fixture(tmp_path, *, delivered=True, account_context=CONTEXT):
    path = str(tmp_path / "execution.sqlite")
    ExecutionAccountBinding(path).initialize(account_context)
    orders = ExecutionStore(path=path)
    positions = LivePositionStore(exec_db=path)
    positions.apply_fill(venue="coinbase",symbol="BTC/USD",fill_id="buy1",side="buy",qty=1,price=100)
    orders.upsert_intent({"intent_id":"exit1","mode":"live","exchange":"coinbase",
        "symbol":"BTC/USD","side":"sell","qty":0.4,"status":"pending"})
    reservations=SpotExitReservations(path, account_context=account_context)
    reservations.record_reconciliation(venue="coinbase",symbol="BTC/USD",evidence_id="r1",exchange_qty=1,observed_ms=100,now_ms=100)
    reservations.reserve(intent_id="exit1",now_ms=110,max_age_ms=20)
    orders.set_intent_status(intent_id="exit1",status="submitted",reason="remote_id=order1")
    orders.add_fill(intent_id="exit1",ts_ms=120,price=90,qty=0.2,fee=0,fee_ccy="USD",
        meta={"trade_id":"sell1"},canonical_fill={"fill_id":"sell1","venue":"coinbase","symbol":"BTC/USD","side":"sell","qty":0.2,"price":90})
    if delivered:
        positions.apply_fill(venue="coinbase",symbol="BTC/USD",fill_id="sell1",side="sell",qty=0.2,price=90)
        orders.complete_reconcile_fill(venue="coinbase",fill_id="sell1")
    orders.set_intent_status(intent_id="exit1",status="canceled",reason="remote_id=order1:canceled")
    dedupe = OrderDedupeStore(exec_db=path)
    dedupe.claim(exchange_id="coinbase",intent_id="exit1",symbol="BTC/USD",client_order_id="client1")
    dedupe.mark_submitted(exchange_id="coinbase",intent_id="exit1",remote_order_id="order1")
    reservations.record_terminal_receipt(intent_id="exit1",venue="coinbase",symbol="BTC/USD",status="canceled",filled_qty=0.2,remote_id="order1")
    return path,reservations,positions


def test_real_schema_partial_cancel_settlement(tmp_path):
    path,r,p=fixture(tmp_path)
    assert r.settle(intent_id="exit1")
    assert p.get_position("coinbase","BTC/USD")["qty"] == 0.8
    assert not SpotExitReservations(path, account_context=CONTEXT).settle(intent_id="exit1")
    assert not r.record_terminal_receipt(intent_id="exit1",venue="coinbase",symbol="BTC/USD",status="canceled",filled_qty=0.2,remote_id="order1")


def test_real_schema_unapplied_fill_retains_capacity(tmp_path):
    path,r,_=fixture(tmp_path,delivered=False)
    with pytest.raises(ValueError): r.settle(intent_id="exit1")
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 1
        assert con.execute("SELECT count(*) FROM spot_exit_settlements").fetchone()[0] == 0


def test_failure_after_tombstone_rolls_back_both_changes(tmp_path):
    path,r,_=fixture(tmp_path)
    with sqlite3.connect(path) as con:
        con.execute("CREATE TRIGGER fail_release BEFORE DELETE ON spot_exit_reservations BEGIN SELECT RAISE(ABORT,'injected release failure'); END")
    with pytest.raises(sqlite3.IntegrityError): r.settle(intent_id="exit1")
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 1
        assert con.execute("SELECT count(*) FROM spot_exit_settlements").fetchone()[0] == 0
        con.execute("DROP TRIGGER fail_release")
    assert SpotExitReservations(path, account_context=CONTEXT).settle(intent_id="exit1")


@pytest.mark.parametrize("column,value", [("remote_order_id","unrelated"),("symbol","ETH/USD"),("exchange_id","other")])
def test_identity_drift_retains_reservation(tmp_path,column,value):
    path,r,_=fixture(tmp_path)
    with sqlite3.connect(path) as con:
        con.execute(f"UPDATE order_dedupe SET {column}=?", (value,))
    with pytest.raises(ValueError): r.settle(intent_id="exit1")
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 1


def test_receipt_conflict_and_unrelated_order_rejected(tmp_path):
    path,r,_=fixture(tmp_path)
    args=dict(intent_id="exit1",venue="coinbase",symbol="BTC/USD",status="canceled",filled_qty=0.2,remote_id="order1")
    assert not r.record_terminal_receipt(**args)
    with pytest.raises(ValueError): r.record_terminal_receipt(**{**args,"remote_id":"unrelated"})
    with pytest.raises(ValueError): r.record_terminal_receipt(**{**args,"filled_qty":0.1})


def test_ambiguous_remote_order_rejected(tmp_path):
    path,r,_=fixture(tmp_path)
    d=OrderDedupeStore(exec_db=path)
    d.claim(exchange_id="coinbase",intent_id="other",symbol="BTC/USD",client_order_id="client2")
    d.mark_submitted(exchange_id="coinbase",intent_id="other",remote_order_id="order1")
    with pytest.raises(ValueError): r.settle(intent_id="exit1")
