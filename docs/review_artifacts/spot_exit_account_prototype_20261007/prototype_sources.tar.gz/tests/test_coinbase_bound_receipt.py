import sqlite3

import pytest

from services.execution import lifecycle_boundary
from services.execution.coinbase_bound_receipt import capture_bound_coinbase_receipt, portfolio_context
from services.execution.coinbase_portfolio_scope import CoinbasePortfolioScope
from tests.test_coinbase_portfolio_scope import PORTFOLIO
from tests.test_spot_exit_real_schema import fixture


class Session:
    id = "coinbase"
    hostname = None

    def __init__(self, portfolio=PORTFOLIO):
        self.urls = {"api":{"rest":"https://api.coinbase.com"}}
        self.portfolio = portfolio
        self.calls = []

    def v3PrivateGetBrokerageKeyPermissions(self):
        self.calls.append("permissions")
        return dict(can_view=True,can_trade=False,portfolio_uuid=self.portfolio,portfolio_type="DEFAULT")

    def fetch_order(self, order_id, symbol):
        self.calls.append((order_id,symbol))
        return dict(id=order_id,symbol=symbol,side="sell",status="canceled",filled=0.2,clientOrderId="client1")


def prepare(tmp_path, monkeypatch):
    context = portfolio_context(CoinbasePortfolioScope(PORTFOLIO,"DEFAULT",False))
    path,r,_=fixture(tmp_path, account_context=context)
    with sqlite3.connect(path) as con:
        con.execute("DELETE FROM spot_exit_terminal_receipts")
    monkeypatch.setattr(lifecycle_boundary,"log_event",lambda *args,**kwargs:None)
    return path,r


def test_same_session_read_only_scope_to_receipt(tmp_path,monkeypatch):
    _,r=prepare(tmp_path,monkeypatch)
    session=Session()
    assert capture_bound_coinbase_receipt(reservations=r,intent_id="exit1",session=session)
    assert session.calls == ["permissions",("order1","BTC/USD")]
    assert r.settle(intent_id="exit1")


def test_different_portfolio_never_fetches_order(tmp_path,monkeypatch):
    path,r=prepare(tmp_path,monkeypatch)
    session=Session("992e8c7c-e979-4cad-b61b-55a197932cf1")
    with pytest.raises(ValueError,match="scope"):
        capture_bound_coinbase_receipt(reservations=r,intent_id="exit1",session=session)
    assert session.calls == ["permissions"]
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_terminal_receipts").fetchone()[0] == 0


@pytest.mark.parametrize("override", ["endpoint","hostname"])
def test_endpoint_override_refused_before_requests(tmp_path,monkeypatch,override):
    _,r=prepare(tmp_path,monkeypatch)
    session=Session()
    if override == "endpoint": session.urls["api"]["rest"]="https://example.invalid"
    else: session.hostname="example.invalid"
    with pytest.raises(ValueError): capture_bound_coinbase_receipt(reservations=r,intent_id="exit1",session=session)
    assert session.calls == []
