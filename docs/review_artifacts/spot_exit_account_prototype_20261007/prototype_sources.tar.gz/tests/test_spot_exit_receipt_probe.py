import sqlite3

import pytest

from services.execution.spot_exit_receipt_probe import capture_terminal_receipt
from tests.test_spot_exit_real_schema import fixture


class VenueDouble:
    def __init__(self, order):
        self.order = order
        self.calls = []

    def fetch_order(self, *, order_id, symbol):
        self.calls.append((order_id,symbol))
        return self.order


def setup_probe(tmp_path):
    path,r,p = fixture(tmp_path)
    with sqlite3.connect(path) as con:
        con.execute("DELETE FROM spot_exit_terminal_receipts")
    order = dict(id="order1",symbol="BTC/USD",side="sell",
        clientOrderId="client1",status="canceled",filled=0.2)
    return path,r,p,order


def test_actual_fetch_helper_to_bound_receipt_and_settlement(tmp_path):
    path,r,p,order = setup_probe(tmp_path)
    client = VenueDouble(order)
    assert capture_terminal_receipt(reservations=r,intent_id="exit1",client=client)
    assert client.calls == [("order1","BTC/USD")]
    assert r.settle(intent_id="exit1")
    assert p.get_position("coinbase","BTC/USD")["qty"] == 0.8
    assert not capture_terminal_receipt(reservations=r,intent_id="exit1",client=client)


@pytest.mark.parametrize("field,value", [("id","wrong"),("symbol","ETH/USD"),
    ("side","buy"),("clientOrderId","wrong"),("status","open"),
    ("filled",None),("filled",True),("filled",float("nan")),("filled",0.5)])
def test_bad_remote_observation_never_releases(tmp_path,field,value):
    path,r,_,order = setup_probe(tmp_path)
    order[field] = value
    with pytest.raises((ValueError,TypeError)):
        capture_terminal_receipt(reservations=r,intent_id="exit1",client=VenueDouble(order))
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_terminal_receipts").fetchone()[0] == 0
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 1


def test_transport_failure_keeps_reservation(tmp_path):
    path,r,_,order = setup_probe(tmp_path)
    class Broken(VenueDouble):
        def fetch_order(self, **kwargs):
            raise OSError("venue unreachable")
    with pytest.raises(OSError):
        capture_terminal_receipt(reservations=r,intent_id="exit1",client=Broken(order))
    with sqlite3.connect(path) as con:
        assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 1
