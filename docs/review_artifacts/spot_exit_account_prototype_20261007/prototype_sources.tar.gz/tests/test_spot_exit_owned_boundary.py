import sqlite3

import pytest

from services.execution import lifecycle_boundary
from services.execution._executor_shared import _open_reconcile_session, _close_reconcile_session
from services.execution.spot_exit_receipt_probe import capture_terminal_receipt
from tests.test_spot_exit_receipt_probe import setup_probe


class SessionDouble:
    def __init__(self, order, *, fail=False):
        self.order = order
        self.fail = fail
        self.calls = []
        self.closed = False

    def fetch_order(self, order_id, symbol):
        self.calls.append((order_id, symbol))
        if self.fail:
            raise OSError("simulated transport failure")
        return self.order

    def close(self):
        self.closed = True


class BuilderDouble:
    def __init__(self, session):
        self.session = session
        self.builds = 0

    def build(self):
        self.builds += 1
        return self.session

    def fetch_order(self, **kwargs):
        raise AssertionError("owned path must use built session")


@pytest.mark.parametrize("case", ["valid", "wrong_id", "wrong_symbol", "wrong_side", "transport_failure"])
def test_owned_session_boundary_contract(tmp_path, monkeypatch, case):
    path, reservations, positions, order = setup_probe(tmp_path)
    if case == "wrong_id":
        order["id"] = "another-order"
    elif case == "wrong_symbol":
        order["symbol"] = "ETH/USD"
    elif case == "wrong_side":
        order["side"] = "buy"
    events = []
    # Capture only the log sink; use the real session and fetch routing helpers.
    monkeypatch.setattr(lifecycle_boundary, "log_event",
        lambda *args, **kwargs: events.append((args, kwargs)))
    raw = SessionDouble(order, fail=case == "transport_failure")
    client = BuilderDouble(raw)
    session, owned = _open_reconcile_session(client)
    assert owned and session is raw and client.builds == 1
    try:
        if case == "valid":
            assert capture_terminal_receipt(reservations=reservations,
                intent_id="exit1", client=client, session=session, owned=owned)
            assert reservations.settle(intent_id="exit1")
            assert positions.get_position("coinbase", "BTC/USD")["qty"] == 0.8
        else:
            with pytest.raises(OSError if case == "transport_failure" else ValueError):
                capture_terminal_receipt(reservations=reservations,
                    intent_id="exit1", client=client, session=session, owned=owned)
            with sqlite3.connect(path) as con:
                assert con.execute("SELECT count(*) FROM spot_exit_terminal_receipts").fetchone()[0] == 0
                assert con.execute("SELECT count(*) FROM spot_exit_reservations").fetchone()[0] == 1
    finally:
        _close_reconcile_session(session, owned=owned)
    assert raw.closed
    assert raw.calls == [("order1", "BTC/USD")]
    assert [args[2] for args, _ in events] == [
        "lifecycle_fetch_order_requested", "lifecycle_fetch_order_result"]
    for args, kwargs in events:
        assert args[:2] == ("coinbase", "BTC/USD")
        assert kwargs["ref_id"] == "order1"
        assert kwargs["payload"]["source"] == "live_executor.reconcile_live"
    assert events[-1][1]["payload"]["ok"] is (case != "transport_failure")
