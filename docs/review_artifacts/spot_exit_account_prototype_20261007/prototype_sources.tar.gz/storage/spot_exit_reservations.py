"""Unwired storage primitive; callers must supply trusted reconciliation evidence."""
import math
import sqlite3
from storage.execution_account_binding import ExecutionAccountBinding


def _number(value):
    if isinstance(value, bool):
        raise ValueError("boolean quantity")
    out = float(value)
    if not math.isfinite(out) or out < 0:
        raise ValueError("invalid quantity")
    return out


class SpotExitReservations:
    def __init__(self, path, *, account_context):
        self.path = str(path)
        self.account_context = account_context
        ExecutionAccountBinding(self.path).require(account_context)
        with sqlite3.connect(self.path) as con:
            con.executescript("""
                CREATE TABLE IF NOT EXISTS spot_exit_evidence (
                    venue TEXT NOT NULL, symbol TEXT NOT NULL,
                    evidence_id TEXT NOT NULL, qty REAL NOT NULL,
                    position_version TEXT NOT NULL, observed_ms INTEGER NOT NULL,
                    PRIMARY KEY(venue,symbol)
                );
                CREATE TABLE IF NOT EXISTS spot_exit_reservations (
                    intent_id TEXT PRIMARY KEY, venue TEXT NOT NULL,
                    symbol TEXT NOT NULL, qty REAL NOT NULL,
                    evidence_id TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS spot_exit_terminal_receipts (
                    intent_id TEXT PRIMARY KEY, venue TEXT NOT NULL,
                    symbol TEXT NOT NULL, status TEXT NOT NULL,
                    filled_qty REAL NOT NULL, remote_id TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS spot_exit_settlements (
                    intent_id TEXT PRIMARY KEY, venue TEXT NOT NULL,
                    symbol TEXT NOT NULL, filled_qty REAL NOT NULL
                );
            """)

    def require_account(self):
        ExecutionAccountBinding(self.path).require(self.account_context)

    def _require_account(self, con, venue=None):
        values = self.account_context.values()
        ExecutionAccountBinding._require(con, values)
        if venue is not None and venue != self.account_context.venue:
            raise ValueError("venue does not belong to bound account")

    def record_reconciliation(self, *, venue, symbol, evidence_id, exchange_qty, observed_ms, now_ms):
        """Only a trusted reconciler may call this; not an operator metadata API."""
        qty = _number(exchange_qty)
        _milliseconds(observed_ms)
        _milliseconds(now_ms)
        if not evidence_id or not venue or not symbol or not 0 <= observed_ms <= now_ms:
            raise ValueError("invalid evidence")
        with sqlite3.connect(self.path) as con:
            con.execute("BEGIN IMMEDIATE")
            self._require_account(con, venue)
            position = con.execute("SELECT qty,updated_ts FROM live_positions WHERE venue=? AND symbol=?", (venue,symbol)).fetchone()
            if position is None or _number(position[0]) != qty:
                raise ValueError("position mismatch")
            prior = con.execute("SELECT observed_ms FROM spot_exit_evidence WHERE venue=? AND symbol=?", (venue,symbol)).fetchone()
            if prior and observed_ms <= prior[0]:
                raise ValueError("nonmonotonic evidence")
            con.execute("INSERT OR REPLACE INTO spot_exit_evidence VALUES(?,?,?,?,?,?)",
                (venue,symbol,str(evidence_id),qty,str(position[1]),observed_ms))

    def reserve(self, *, intent_id, now_ms, max_age_ms):
        """Reserve a pending live spot sell; missing/unreadable proof raises."""
        _milliseconds(now_ms)
        _milliseconds(max_age_ms)
        if not intent_id or max_age_ms <= 0:
            raise ValueError("invalid reservation request")
        with sqlite3.connect(self.path) as con:
            con.execute("BEGIN IMMEDIATE")
            self._require_account(con)
            if con.execute("SELECT 1 FROM spot_exit_settlements WHERE intent_id=?", (intent_id,)).fetchone():
                raise ValueError("exit already settled")
            intent = con.execute("SELECT exchange,symbol,side,qty,mode,status FROM intents WHERE intent_id=?", (intent_id,)).fetchone()
            if not intent or intent[2] != "sell" or intent[4] != "live" or intent[5] != "pending":
                raise ValueError("ineligible intent")
            venue,symbol = intent[:2]
            self._require_account(con, venue)
            qty = _number(intent[3])
            if qty == 0:
                raise ValueError("zero exit")
            proof = con.execute("SELECT evidence_id,qty,position_version,observed_ms FROM spot_exit_evidence WHERE venue=? AND symbol=?", (venue,symbol)).fetchone()
            position = con.execute("SELECT qty,updated_ts FROM live_positions WHERE venue=? AND symbol=?", (venue,symbol)).fetchone()
            if not proof or not position or not 0 <= now_ms-proof[3] <= max_age_ms:
                raise ValueError("missing or stale reconciliation")
            held = _number(position[0])
            if held != _number(proof[1]) or str(position[1]) != proof[2]:
                raise ValueError("position changed after reconciliation")
            existing = con.execute("SELECT venue,symbol,qty FROM spot_exit_reservations WHERE intent_id=?", (intent_id,)).fetchone()
            if existing:
                if existing != (venue,symbol,qty):
                    raise ValueError("reservation identity changed")
            reserved = sum(_number(r[0]) for r in con.execute("SELECT qty FROM spot_exit_reservations WHERE venue=? AND symbol=?", (venue,symbol)))
            # Unreserved nonterminal sells also consume capacity. Unknown/error
            # submission states remain outstanding, never implicitly released.
            other = con.execute("""SELECT i.qty FROM intents i WHERE i.exchange=?
                AND i.symbol=? AND i.mode='live' AND i.side='sell'
                AND i.status NOT IN ('filled','canceled') AND i.intent_id<>?
                AND NOT EXISTS (SELECT 1 FROM spot_exit_reservations r WHERE r.intent_id=i.intent_id)""",
                (venue,symbol,intent_id)).fetchall()
            outstanding = sum(_number(r[0]) for r in other)
            if (0 if existing else qty) + reserved + outstanding > held:
                raise ValueError("insufficient unreserved holdings")
            if existing:
                return qty
            con.execute("INSERT INTO spot_exit_reservations VALUES(?,?,?,?,?)", (intent_id,venue,symbol,qty,proof[0]))
            return qty

    def record_terminal_receipt(self, *, intent_id, venue, symbol, remote_id, status, filled_qty):
        """Internal trusted-reconciler API; identity binding is not venue proof."""
        filled = _number(filled_qty)
        if status not in ("filled", "canceled") or not isinstance(remote_id, str) or not remote_id.strip():
            raise ValueError("invalid terminal observation")
        with sqlite3.connect(self.path) as con:
            con.execute("BEGIN IMMEDIATE")
            self._require_account(con, venue)
            self._bind_order(con, intent_id, venue, symbol, remote_id)
            receipt = (venue, symbol, status, filled, remote_id)
            prior = con.execute("SELECT venue,symbol,status,filled_qty,remote_id FROM spot_exit_terminal_receipts WHERE intent_id=?", (intent_id,)).fetchone()
            if prior:
                if prior != receipt:
                    raise ValueError("conflicting terminal receipt")
                return False
            reservation = con.execute("SELECT venue,symbol,qty FROM spot_exit_reservations WHERE intent_id=?", (intent_id,)).fetchone()
            if not reservation or reservation[:2] != (venue, symbol) or filled > _number(reservation[2]):
                raise ValueError("terminal reservation mismatch")
            con.execute("INSERT INTO spot_exit_terminal_receipts VALUES(?,?,?,?,?,?)", (intent_id, *receipt))
            return True

    @staticmethod
    def _bind_order(con, intent_id, venue, symbol, remote_id):
        mapping = con.execute("SELECT symbol,remote_order_id FROM order_dedupe WHERE exchange_id=? AND intent_id=?", (venue, intent_id)).fetchone()
        owners = con.execute("SELECT intent_id FROM order_dedupe WHERE exchange_id=? AND remote_order_id=?", (venue, remote_id)).fetchall()
        if mapping != (symbol, remote_id) or owners != [(intent_id,)]:
            raise ValueError("missing or ambiguous exchange order identity")

    def settle(self, *, intent_id):
        """Trusted terminal receipt plus fully delivered fills, never status alone.

        Receipt producer is deliberately unwired. Partial/unknown orders retain
        their entire reservation until authoritative terminal evidence exists.
        """
        with sqlite3.connect(self.path) as con:
            con.execute("BEGIN IMMEDIATE")
            self._require_account(con)
            if con.execute("SELECT 1 FROM spot_exit_settlements WHERE intent_id=?", (intent_id,)).fetchone():
                return False
            reservation = con.execute("SELECT venue,symbol,qty FROM spot_exit_reservations WHERE intent_id=?", (intent_id,)).fetchone()
            receipt = con.execute("SELECT venue,symbol,status,filled_qty,remote_id FROM spot_exit_terminal_receipts WHERE intent_id=?", (intent_id,)).fetchone()
            if not reservation or not receipt or receipt[:2] != reservation[:2] or receipt[2] not in ("filled","canceled") or not receipt[4]:
                raise ValueError("missing authoritative terminal receipt")
            filled = _number(receipt[3])
            self._require_account(con, receipt[0])
            self._bind_order(con, intent_id, receipt[0], receipt[1], receipt[4])
            if filled > _number(reservation[2]):
                raise ValueError("terminal quantity exceeds reservation")
            intent = con.execute("SELECT exchange,symbol,side,status FROM intents WHERE intent_id=?", (intent_id,)).fetchone()
            if not intent or intent != (receipt[0],receipt[1],"sell",receipt[2]):
                raise ValueError("terminal intent mismatch")
            rows = con.execute("SELECT qty,trade_id FROM fills WHERE intent_id=?", (intent_id,)).fetchall()
            total = 0.0
            for qty,fill_id in rows:
                qty = _number(qty)
                delivery = con.execute("SELECT completed FROM reconcile_fill_deliveries WHERE intent_id=? AND venue=? AND fill_id=?", (intent_id,receipt[0],fill_id)).fetchone()
                applied = con.execute("SELECT symbol,side,qty FROM live_position_fills WHERE venue=? AND fill_id=?", (receipt[0],fill_id)).fetchone()
                if qty <= 0 or not fill_id or not delivery or delivery[0] != 1 or not applied or applied[:2] != (receipt[1],"sell") or _number(applied[2]) != qty:
                    raise ValueError("fill accounting incomplete")
                total += qty
            if total != filled:
                raise ValueError("terminal fill coverage mismatch")
            con.execute("INSERT INTO spot_exit_settlements VALUES(?,?,?,?)", (intent_id,receipt[0],receipt[1],filled))
            con.execute("DELETE FROM spot_exit_reservations WHERE intent_id=?", (intent_id,))
            return True


def _milliseconds(value):
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError("time must be nonnegative integer milliseconds")
