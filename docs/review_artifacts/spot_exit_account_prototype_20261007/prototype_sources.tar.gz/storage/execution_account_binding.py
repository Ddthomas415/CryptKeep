"""Unwired account binding primitive; only a trusted verifier supplies context."""
import sqlite3
from dataclasses import dataclass


@dataclass(frozen=True)
class AccountContext:
    venue: str
    environment: str
    account_id: str
    portfolio_id: str

    def values(self):
        values = (self.venue, self.environment, self.account_id, self.portfolio_id)
        if any(not isinstance(v, str) or not v or v != v.strip() for v in values):
            raise ValueError("explicit account context required")
        if self.environment not in ("sandbox", "production"):
            raise ValueError("invalid account environment")
        return values


class ExecutionAccountBinding:
    """No credential loading, network verification or legacy writer enforcement."""

    def __init__(self, path):
        self.path = str(path)

    def initialize(self, context):
        """Bind a new/empty database; never infer ownership of historical rows."""
        values = context.values()
        with sqlite3.connect(self.path) as con:
            con.execute("BEGIN IMMEDIATE")
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if "execution_account_binding" in tables:
                self._require(con, values)
                return False
            # Fail closed on any existing application rows, including unknown
            # tables, rather than maintaining an incomplete history allowlist.
            for table in tables - {"sqlite_sequence"}:
                quoted = '"' + table.replace('"', '""') + '"'
                if con.execute(f"SELECT 1 FROM {quoted} LIMIT 1").fetchone():
                    raise ValueError("unbound database contains historical rows")
            con.execute("""CREATE TABLE execution_account_binding (
                singleton INTEGER PRIMARY KEY CHECK(singleton=1),
                venue TEXT NOT NULL,environment TEXT NOT NULL,
                account_id TEXT NOT NULL,portfolio_id TEXT NOT NULL)""")
            con.execute("INSERT INTO execution_account_binding VALUES(1,?,?,?,?)", values)
            con.execute("""CREATE TRIGGER account_binding_no_insert BEFORE INSERT
                ON execution_account_binding WHEN EXISTS
                (SELECT 1 FROM execution_account_binding)
                BEGIN SELECT RAISE(ABORT,'immutable account binding'); END""")
            con.execute("""CREATE TRIGGER account_binding_no_update BEFORE UPDATE
                ON execution_account_binding BEGIN SELECT RAISE(ABORT,'immutable account binding'); END""")
            con.execute("""CREATE TRIGGER account_binding_no_delete BEFORE DELETE
                ON execution_account_binding BEGIN SELECT RAISE(ABORT,'immutable account binding'); END""")
            return True

    def require(self, context):
        values = context.values()
        # Read-only inspection must not create an absent database.
        from pathlib import Path
        uri = Path(self.path).resolve().as_uri() + "?mode=ro"
        with sqlite3.connect(uri, uri=True) as con:
            self._require(con, values)

    @staticmethod
    def _require(con, values):
        rows = con.execute("SELECT singleton,venue,environment,account_id,portfolio_id FROM execution_account_binding").fetchall()
        if rows != [(1, *values)]:
            raise ValueError("execution account binding mismatch")
