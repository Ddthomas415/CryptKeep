"""Unwired coordinator for a trusted, stable Coinbase production session."""
from services.execution.coinbase_portfolio_scope import observe_portfolio_scope
from services.execution.spot_exit_receipt_probe import capture_terminal_receipt
from storage.execution_account_binding import AccountContext


def portfolio_context(scope):
    """Trading-scope namespace, not legal/global user identity."""
    return AccountContext("coinbase", "production",
        "coinbase-portfolio:" + scope.portfolio_uuid, scope.portfolio_uuid)


def capture_bound_coinbase_receipt(*, reservations, intent_id, session):
    """No binding creation or credential access; caller owns session lifetime.

    Caller must supply a trusted session whose credentials/config cannot be
    mutated concurrently. Endpoint inspection is not TLS or account proof.
    """
    if getattr(session, "urls", {}).get("api") != {"rest": "https://api.coinbase.com"}:
        raise ValueError("production Coinbase endpoint required")
    if getattr(session, "hostname", None) is not None:
        raise ValueError("hostname override unsupported")
    scope = observe_portfolio_scope(session)
    context = portfolio_context(scope)
    if context != reservations.account_context:
        raise ValueError("authenticated portfolio scope does not match database")
    reservations.require_account()
    # Both permissions and order calls use this same trusted session object.
    return capture_terminal_receipt(reservations=reservations,intent_id=intent_id,
        client=session,session=session,owned=True)
