"""Unwired receipt adapter. Not imported by the production reconciler."""
import sqlite3

from services.execution._executor_shared import _fetch_order_for_reconcile


def capture_terminal_receipt(*, reservations, intent_id, client, session=None, owned=False):
    """Fetch the mapped order through the existing reconciliation transport.

    The caller owns authenticated-session provenance. Explicit returned identity
    is required; a transport success alone cannot release reserved holdings.
    """
    reservations.require_account()
    with sqlite3.connect(reservations.path) as con:
        row = con.execute("""SELECT i.exchange,i.symbol,i.side,i.mode,
            d.remote_order_id,d.client_order_id FROM intents i
            JOIN order_dedupe d ON d.intent_id=i.intent_id
                AND d.exchange_id=i.exchange
            WHERE i.intent_id=?""", (intent_id,)).fetchone()
    if not row or row[2:4] != ("sell", "live") or not row[4]:
        raise ValueError("missing live sell order identity")
    venue,symbol,_,_,remote_id,client_id = row
    if venue != reservations.account_context.venue:
        raise ValueError("intent venue does not belong to bound account")
    order = _fetch_order_for_reconcile(client,session,owned=owned,
        venue=venue,symbol=symbol,order_id=remote_id)
    if not isinstance(order, dict) or (order.get("id"),order.get("symbol"),order.get("side")) != (remote_id,symbol,"sell"):
        raise ValueError("returned order identity mismatch")
    if order.get("clientOrderId") is not None and order["clientOrderId"] != client_id:
        raise ValueError("returned client order identity mismatch")
    statuses = {"closed":"filled","filled":"filled","canceled":"canceled",
        "cancelled":"canceled","rejected":"canceled","expired":"canceled"}
    status = statuses.get(order.get("status"))
    if status is None:
        raise ValueError("order is not terminal")
    return reservations.record_terminal_receipt(intent_id=intent_id,venue=venue,
        symbol=symbol,remote_id=remote_id,status=status,filled_qty=order.get("filled"))
