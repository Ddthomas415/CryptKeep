"""Unwired portfolio-scope observation; not global account or environment proof."""
from dataclasses import dataclass
from uuid import UUID


@dataclass(frozen=True)
class CoinbasePortfolioScope:
    portfolio_uuid: str
    portfolio_type: str
    can_trade: bool


def observe_portfolio_scope(session):
    """Use the supplied trusted session; never load or modify credentials.

    Caller must establish session authentication and endpoint/environment. This
    result must not be converted into AccountContext without that contract.
    """
    if getattr(session, "id", None) != "coinbase":
        raise ValueError("Coinbase session required")
    fetch = getattr(session, "v3PrivateGetBrokerageKeyPermissions", None)
    if not callable(fetch):
        raise ValueError("portfolio permissions endpoint unavailable")
    response = fetch()
    if not isinstance(response, dict) or "error" in response:
        raise ValueError("invalid portfolio permissions response")
    if response.get("can_view") is not True or not isinstance(response.get("can_trade"), bool):
        raise ValueError("explicit view and trade permissions required")
    raw = response.get("portfolio_uuid")
    if not isinstance(raw, str) or raw != raw.strip():
        raise ValueError("portfolio UUID required")
    try:
        portfolio = UUID(raw)
    except (ValueError, AttributeError) as exc:
        raise ValueError("invalid portfolio UUID") from exc
    if portfolio.int == 0:
        raise ValueError("nil portfolio UUID")
    kind = response.get("portfolio_type")
    if kind not in ("DEFAULT", "CONSUMER"):
        raise ValueError("unsupported spot portfolio type")
    return CoinbasePortfolioScope(str(portfolio), kind, response["can_trade"])
