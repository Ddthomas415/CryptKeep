from dataclasses import replace

import pytest

from services.execution import coinbase_receipt_lifecycle as lifecycle
from tests.test_coinbase_bound_receipt import Session, prepare


class OwnedSession(Session):
    verify = True
    verbose = False

    def __init__(self):
        super().__init__()
        self.closed = False

    def close(self):
        self.closed = True


def install(monkeypatch, session):
    calls=[]
    def factory(venue, **kwargs):
        calls.append((venue,kwargs))
        return session
    monkeypatch.setattr(lifecycle,"make_private_exchange",factory)
    return calls


def test_one_shot_factory_session_scope_and_close(tmp_path,monkeypatch):
    _,r=prepare(tmp_path,monkeypatch)
    session=OwnedSession(); calls=install(monkeypatch,session)
    assert lifecycle.capture_owned_coinbase_receipt(reservations=r,intent_id="exit1")
    assert calls == [("coinbase",{"enable_rate_limit":True})]
    assert session.closed and session.timeout == 20000
    assert session.calls == ["permissions",("order1","BTC/USD")]


@pytest.mark.parametrize("stage", ["permissions","order"])
def test_transport_failure_still_closes(tmp_path,monkeypatch,stage):
    _,r=prepare(tmp_path,monkeypatch)
    session=OwnedSession(); install(monkeypatch,session)
    def fail(*args): raise OSError("simulated failure")
    if stage == "permissions": session.v3PrivateGetBrokerageKeyPermissions=fail
    else: session.fetch_order=fail
    with pytest.raises(OSError): lifecycle.capture_owned_coinbase_receipt(reservations=r,intent_id="exit1")
    assert session.closed


@pytest.mark.parametrize("field,value", [("verify",False),("verbose",True),("httpsProxy","proxy")])
def test_unsupported_transport_closes_before_requests(tmp_path,monkeypatch,field,value):
    _,r=prepare(tmp_path,monkeypatch)
    session=OwnedSession(); setattr(session,field,value); install(monkeypatch,session)
    with pytest.raises(ValueError): lifecycle.capture_owned_coinbase_receipt(reservations=r,intent_id="exit1")
    assert session.closed and session.calls == []


def test_wrong_context_never_constructs_session(tmp_path,monkeypatch):
    _,r=prepare(tmp_path,monkeypatch)
    r.account_context=replace(r.account_context,environment="sandbox")
    calls=install(monkeypatch,OwnedSession())
    with pytest.raises(ValueError): lifecycle.capture_owned_coinbase_receipt(reservations=r,intent_id="exit1")
    assert calls == []


def test_cleanup_failure_is_reported_without_raw_error(tmp_path,monkeypatch):
    _,r=prepare(tmp_path,monkeypatch)
    session=OwnedSession(); install(monkeypatch,session)
    def fail(): raise OSError("sensitive transport detail")
    session.close=fail
    with pytest.raises(RuntimeError,match="^private session cleanup failed$"):
        lifecycle.capture_owned_coinbase_receipt(reservations=r,intent_id="exit1")
