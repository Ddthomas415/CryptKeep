"""Unwired one-shot authenticated receipt reader; never submits an order."""
from services.execution.ccxt_private_factory import make_private_exchange
from services.execution.coinbase_bound_receipt import capture_bound_coinbase_receipt


def capture_owned_coinbase_receipt(*, reservations, intent_id):
    """Own one fresh private session; no injected session or credential options.

    Shared factory is the trusted construction boundary. Session never escapes
    this synchronous operation. No database initialization or settlement here.
    """
    reservations.require_account()
    if reservations.account_context.venue != "coinbase" or reservations.account_context.environment != "production":
        raise ValueError("production Coinbase database context required")
    session = make_private_exchange("coinbase", enable_rate_limit=True)
    try:
        if getattr(session, "verify", None) is not True:
            raise ValueError("TLS verification required")
        if getattr(session, "verbose", None) is not False:
            raise ValueError("verbose private transport unsupported")
        if any(getattr(session, name, None) for name in
            ("proxyUrl", "httpProxy", "httpsProxy", "socksProxy")):
            raise ValueError("private proxy configuration unsupported")
        session.timeout = 20000
        return capture_bound_coinbase_receipt(reservations=reservations,
            intent_id=intent_id,session=session)
    finally:
        close = getattr(session, "close", None)
        if callable(close):
            try:
                close()
            except Exception:
                raise RuntimeError("private session cleanup failed") from None
