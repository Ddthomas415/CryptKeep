Patch 0076 - replaces patch 0059 on master be34a18a
====================================================
Status: READY_FOR_INDEPENDENT_REVIEW. Not pushed. HIGH risk (canonical fill accounting).

Base: master be34a18a (PR 605 dcf832e5, PR 606) + the 71 series commits that carry over.
Check branch (local only): claude/base-check-be34a18a, commit df6a1c26.
What it fixes (both SHOWN on master be34a18a by direct probe):
1. Consecutive-loss symbol lock could not trigger: a fill with realized PnL 0 (the opening
   buy) reset the count before every sell.
2. A failed daily-loss write was reported as accounted: sink returned ok, loss missing from
   the daily figures, no order-block flag.

Files: storage/execution_store_sqlite.py, services/journal/fill_sink.py,
services/risk/risk_daily.py, tests/test_symbol_loss_lock_counts_closing_fills.py (13 cases),
docs/work_log/review_stabilized_work_log.md.

Verification:
- Full suite on the check branch: 4989 passed, 33 skipped, 0 failed.
- Master be34a18a alone: 3877 passed, 33 skipped, 0 failed.
- Master + 71 commits without this patch: 5 failed (all need this patch).
- 7 of the 8 original 0059 cases fail on master be34a18a.

Decision carried over: a breakeven close (exactly 0) neither counts as a loss nor resets.
Withdrawn: patch 0058 (superseded by PR 605).
Not covered: venue, host, load-concurrency or power-loss proof.
